#!/bin/bash
set -e

if [ ! -f terraform/kube_dev/cae-local.tfvars ]; then
    echo "You must create terraform/kube_dev/cae-local.tfvars that stores your login info" >&2
    exit 1
fi

#Master count validation & should be minimum 3 and odd number!

if [ -f terraform/kube_dev/cae.tfvars ]; then
    master_counts=`cat terraform/kube_dev/cae.tfvars |awk '/^master_count/' | awk '{print $3}'`
    if [[ $master_counts != 3 ]]; then
     echo "master_count:$master_counts"
     echo "Master Count should be minimum 3 and odd number  or Kubernetes HA cluster => https://kubernetes.io/docs/setup/independent/high-availability/#before-you-begin" >&2
     exit 1
    fi
fi

# Include the Terraform library in the source
source ~/.bashrc
pushd terraform
pushd kube_dev

terraform init

# terraform apply to create the Openstack instances
#
# Example:
#     terraform apply --var-file=cae-local.tfvars --var-file=cae.tfvars
terraform apply -auto-approve --var-file=cae-local.tfvars --var-file=cae.tfvars

# get the output file and store in ansible/inventory directory
terraform output inventory > ../../ansible/inventory/kube_dev/inventory
terraform output eman_am_add > ../../scripts/file/eman-am-add
terraform output eman_am_del > ../../scripts/file/eman-am-del
terraform output eman_am_lb_cleanup > ../../scripts/file/eman-am-lb-cleanup

popd
popd

source scripts/eman-am-add.sh

echo "Waiting 60 seconds to allow DNS to propogate"
sleep 60

# start the ansible to deploy Kubernetes
pushd ansible
pushd scripts
./deploy-cluster.sh
