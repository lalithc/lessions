#!/bin/bash
set -e

# Include the Terraform library in the source
source ~/.bashrc

pushd scripts
echo "Deleting DNS entries. If prompted, please enter your eman-am username and password"

./eman-am -b=file/eman-am-del

popd

pushd terraform
pushd kube_dev

# terraform apply to create the Openstack instances
#
terraform destroy --var-file=cae-local.tfvars --var-file=cae.tfvars
rm -rf .terraform
rm -rf plan.tfout
popd
popd
