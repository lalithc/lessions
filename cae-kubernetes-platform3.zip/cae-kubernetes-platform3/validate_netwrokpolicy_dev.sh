#!/bin/bash
set -e

# start the ansible to deploy Kubernetes
pushd ansible
pushd scripts
./validate-networkpolicy.sh
