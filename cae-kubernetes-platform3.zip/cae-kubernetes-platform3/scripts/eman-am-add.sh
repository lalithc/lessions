#!/bin/bash
pushd scripts

echo "Delete default load balancer VIP DNS entries from eman for master api & Which are added by openstack while creating LB"

echo  "if a username/password prompt is given please enter the appropriate DNS CEC credentials."


./eman-am -b=file/eman-am-lb-cleanup

echo "Sleeping 5 seconds to allow delete actions to propogate"
sleep 5

echo "Adding DNS Entries to eman, if a username/password prompt is given please enter your CEC credentials"

./eman-am -b=file/eman-am-add

popd
