## Code validation through Jenkins

https://ci3.cisco.com/job/IT-GIS-ATS/job/Kube/job/cae-kubernetes-platform3/


## Kubernetes Standalone cluster
Jenkins Code validation (Ansible and Terraform) is at
https://ci3.cisco.com/job/IT-GIS-ATS/job/Kube/job/cae-python-utilities/

Steps to create the new env:
1. Check out the code: [cae-kubernetes-platform3.git](https://gitscm.cisco.com/users/poyang/repos/cae-kubernetes-platform3/browse)
2. Install Terraform on your local machine: https://www.terraform.io/intro/getting-started/install.html and include it in your `~/.bashrc` file
3. Generate the ssh key on your local machine: `ssh-keygen -t rsa`
4. Create `terraform/kube_dev/cae-local.tfvars`. Contact the team for user/pass.
5. Open `terraform/kube_dev/cae.tfvars` to make sure both master_count and work_count are not big numbers. Then modify this cluster name according to this format: `cluster_name = "<username>-cae-kube"`
6. Log in to Openstack to make sure we still have capacity for the new environment (use the account from step 4 to login): https://cloud-rtp-1.cisco.com/dashboard/project/
7. Init Terraform `cd terraform/kube_dev; terraform init`
8. Run `setup_kubernetes_dev.sh`


### Accessing your cluster
Via SSH: `ssh -i ~/.ssh/id_rsa root@64.102.178.85`, where the IP will vary depending on what host you want to access.

Via the dashboard:
  - Use kubectl proxy (only you can use this, access is limited by the `admin.conf` credentials):
    - Copy `/etc/kubeconfig/admin.conf` to a local directory.
    - Run `kubectl --kubeconfig <local admin.conf> proxy`
    - In a web browser, connect to [localhost:8001](http://localhost:8001/api/v1/namespaces/kube-system/services/https:kubernetes-dashboard:/proxy/#!/)
    - Click on "Skip", change the namespace to kube-system.

  - Using the NodePort ingress (note: anyone can use this):
    - Run the `get-dashboard-url` playbook: `ansible-playbook -i inventory/kube_dev/inventory playbooks/get-dashboard-url.yml`
    - Copy and paste the URL in to your browser.
    - Cick on "Skip", change the namespace to kube-system.

  - In the future: Using [ingress](https://kubernetes.io/docs/concepts/services-networking/ingress/) when DNS is set up correctly, [LDAP](https://medium.com/@pmvk/step-by-step-guide-to-integrate-ldap-with-kubernetes-1f3fe1ec644e) for auth, [TLS](https://blog.heptio.com/on-securing-the-kubernetes-dashboard-16b09b1b7aca) for encryption.

### Fixing a misbehaving pod
1. On the MASTER, identify the pod and its node:
  - List all pods `kubectl --kubeconfig=/etc/kubernetes/admin.conf get pods --namespace=kube-system`. Find the name of the pod (2nd column) that is malfunctioning (status is the 4th column), that is <pod_name> .
  - Get node that hosts malfunctioning pod `kubectl --kubeconfig=/etc/kubernetes/admin.conf describe pods/<pod_name> --namespace=kube-system | grep Node`
  This is your <node_name> .
2. On the MASTER, drain connections & delete <node_name>:
  - `kubectl --kubeconfig=/etc/kubernetes/admin.conf drain <node_name> --delete-local-data --force --ignore-daemonsets`
  - `kubectl --kubeconfig=/etc/kubernetes/admin.conf delete node <node_name>`
3. On <node_name> (NOT THE MASTER!), reset it:
  - `kubeadm reset`
  Note: If you did this on the master, look at the 'Destroying your cluster' section below.
4. On the MASTER, get your <kubeadm_token>:
  - `kubeadm token list | tail -1 | awk '{print $1}'`
5. On <node_name>, rejoin <node_name> to the cluster:
  - `kubeadm join --token <kubeadm_token> <master_ip>:6443 --discovery-token-unsafe-skip-ca-verification`

### Destroying your cluster
Run this from the `terrform/kube-dev` directory: `terraform destroy --var-file=cae-local.tfvars --var-file=cae.tfvars`

### To do list
LDAP for kube-dashboard. Here are a couple examples:
- https://medium.com/@pmvk/step-by-step-guide-to-integrate-ldap-with-kubernetes-1f3fe1ec644e
- https://github.com/apprenda-kismatic/kubernetes-ldap

We still need to do the HA clusters with Kubeadm by following this page:
https://kubernetes.io/docs/setup/independent/high-availability/

We still need to configure the openstack provider for dynamic storage allocation:
https://medium.com/@arthur.souzamiranda/kubernetes-with-openstack-cloud-provider-current-state-and-upcoming-changes-part-1-of-2-48b161ea449a
https://kubernetes.io/docs/concepts/cluster-administration/cloud-providers/

We need to have code to register DNS, SSL Cert and integration with Ping Federate. Please refer the code from Openshift Terraform and Ansible.
  - Arut developed python libraries to generate SSL certificate (PKI) and PMT integration for the ACC team to automate CAE route create workflow.  Let me know if this will be helpful in your automation, I can get more details and share with you.
    - SSL cert: https://gitscm.cisco.com/projects/CITEIS/repos/sslcert/browse
    - PMT: https://gitscm.cisco.com/projects/CITEIS/repos/ping3a/browse

### Add-on components

* Logging clusters
* System Metrics clusters
* [Dashboard](https://github.com/kubernetes/dashboard)
* Kafka
* Apache Storm

Dependencies can be found [here](https://github.com/kubernetes/contrib/tree/master/ansible).

### Notes

We might need to focus on this new repository since our development will be based on Kubernetes Standalone with NO Openshift.  I will also remove all the Non-Openshift code from kubernetes-platform3.git in the future
https://poyang@gitscm.cisco.com/scm/~poyang/cae-kubernetes-platform3.git

You can find the most of my Terraform code from the following site
Terraform Openstack APIs: https://www.terraform.io/docs/providers/openstack/

I used the following document for Kubernetes Standalone installation
Kubeadm installation: https://kubernetes.io/docs/setup/independent/install-kubeadm/

#Test branch push by Mahantesh
