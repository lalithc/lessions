#!/bin/bash

# Copyright 2018 Cisco System


CUR_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

INVENTORY_DIR="${CUR_DIR}/../inventory"
PLAYBOOKS_DIR="${CUR_DIR}/../playbooks"
PRIVATE_KEY_PATH="~/.ssh/id_rsa"

check_inventory() {
	inv_dir=$(dirname $1)
	if [ ! -e "${inv_dir}" ]; then
		echo "Inventory directory ${inv_dir} is missing group_vars directory"
		exit 1
	fi
}

ansible_playbook() {
	inventory=$1
	check_inventory ${inventory}
	ansible-playbook -i "$@" --private-key=${PRIVATE_KEY_PATH}
}
