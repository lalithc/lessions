#!/bin/bash

# Copyright 2018 Cisco System

. ./init.sh

inventory=${INVENTORY:-${INVENTORY_DIR}/kube_dev/inventory}
ansible_playbook ${inventory} ${PLAYBOOKS_DIR}/cluster-validation-dev.yml "$@"
