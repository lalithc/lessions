# CCRCAutomation #

This service enables DevOps automation tasks by exposing REST endpoints.

### Usage
##### Local Flask Standalone
```
$ pip install -r requirements.txt
$ export FLASK_APP=app/main.py
$ flask run
```

##### Local Docker Container
```
$ docker build --no-cache=true -t ccrcautomation .
$ docker run -d -p 5000:80 --name ccrcautomation ccrcautomation
```

##### Test Local
```
$ curl 'localhost:5000/modules'
```

### API
**Server: ccrc-build-5**

**POST /setup_module**

_Setup a module with all supported configurations including MySQL data and jenkins jobs._

_If one piece of the setup is already there, this api will skip and move to the next step, 
e.g. if module already exists in MySQL but it is just missing the deploy job, it will only create the deploy job.
It will setup everything for a all environments, separating nonprod and prod._

**Current environments that are supported: dev-main, dev-rel, stg-rel, stg1-main in openstack, stg2-main in cae**

**Current steps supported: MySQL insertion, Jenkins build job, Jenkins deploy job**

**TODO: Dockerfile setup, generic puppet, dev release, stg, and lt environments**
```
Default JSON values:
heap_min: [512]
heap_max: [1024]
service_name: [lowercase module_name]
project: [ServiceContract]
build_server: [ccrc-build-3]
deploy_server: [ccrc-build-5]


Setup a new [module] named CCRCProxy with [service_name] of ccrcproxy, [ext] zip, [type] nodejs
and assign it [hosts] ccrc-srv-dev2-01 and ccrc-srv-dev2-03. The MySQL data and Jenkins deploy job is already setup for this
module, so the API will only create the Jenkins build job.

$ curl -X POST -d \
'{"module":"CCRCProxy","ext":"zip","type":"nodejs","hosts":["ccrc-srv-dev2-01","ccrc-srv-dev2-03"]}' \
'ccrc-build-5:5000/setup_module'
Module CCRCProxy has been setup with following results: [Module CCRCProxy already exists!, Job CCRCProxy-main-Dev on server ccrc-build-docker-04 already exists!, Build job CCRCProxy-main for dev-main on server ccrc-build-3 created!]

Setup a new [module] named CCRCSaaSDownload with [service_name] of saasdownload (15 max char length limit), [ext] zip, [type] nodejs,
assign it [hosts] ccrc-srv-dev2-02 and ccrc-srv-dev2-12, and create the Jenkins deploy job in [deploy_server] ccrc-build-5. 
This module has not had anything previously setup, so all supported steps will be executed.
$ curl -X POST -d \
'{"module":"CCRCSaaSDownload","service_name":"saasdownload","deploy_server":"ccrc-build-5","ext":"zip","type":"nodejs","hosts":["ccrc-srv-dev2-02","ccrc-srv-dev2-12"]}' \
'ccrc-build-5:5000/setup_module'
Module CCRCSaaSDownload has been setup with following results: [Module CCRCSaaSDownload of type nodejs packaged as a zip has been created with service_name saasdownload, heap_min 512, heap_max 1024, and assigned the following hosts: [ccrc-srv-dev2-02, ccrc-srv-dev2-12]', 'Deploy job CCRCSaaSDownload-main-Dev for dev-main on server ccrc-build-5 created!', 'Build job CCRCSaaSDownload-main for dev-main on server ccrc-build-3 created!']
```

**PUT /reconfigure_module**
_Reconfigure a module with given inputs by updating all existing MySQL data and jenkins jobs._

_This endpoint acts similarly to /setup_module except for modifications to a module. For instance,
if changing a module from tomcat/war to springboot/jar, use this API to make the modification in the DB 
and apply the change to all Jenkins jobs supported by CCRCAutomation._
```
Reconfigure existing [module] CCRCDataServices and update its [ext] to jar and its [type] to springboot.
This module exists in MySQL, has a ccrc-build-3 build job, has a ccrc-build-docker-04 deploy job, but
has no ccrc-build-docker-04 CAE job. Thus all will be updated except the CAE job which will fail. /setup_module
must be used to resolve the missing CAE job.
$ curl -X PUT -d \
'{"module":"CCRCDataServices","ext":"jar","type":"springboot"}' \
'ccrc-build-5:5000/reconfigure_module'
Module CCRCDataServices has been reconfigured with following results: [Module CCRCDataServices has been updated to type springboot, ext jar, service_name <no change>, heap_min <no change>, heap_max <no change>, and has been assigned the following hosts: <no change>, Deploy job CCRCDataServices-main-Dev for dev-main on server ccrc-build-docker-04 updated!, Job CCRCDataServices_CAE-main-Stg on server ccrc-build-docker-04 does not exist!, Build job CCRCDataServices-main for dev-main on server ccrc-build-3 updated!]
```

**PUT /module/update_version**
_Update the version for a given module on a particular host to track which versions are deployed on which hosts._

```
Update the [version] of [module] QOTService to 1.3.6-3516 on [host] ccrc-srv-lt2-05.
$ curl -X PUT 'ccrc-build-5:5000/module/update_version' -d '{"module":"QOTService","host":"ccrc-srv-lt2-05","version":"1.3.6-3516"}'
Module QOTService on host ccrc-srv-lt2-05 has been updated to version 1.3.6-3516
```


**GET /modules**
_retrieve module data_
```
Get all module data
$ curl 'ccrc-build-5:5000/modules'

Get [module] QOTService data
$ curl 'ccrc-build-5:5000/modules?module=QOTService'

Get module data for all apps of [type] nodejs in [env] lt-main
$ curl 'ccrc-build-5:5000/modules?type=nodejs&env=lt-main'
```

**POST /modules**
_create a new module_
```
Create new [module] named CCRCQuoteLineEdit with [ext] jar of [type] springboot, 
and assign it [hosts] ccrc-srv-dev2-01 and ccrc-srv-dev2-03
$ curl -X POST \
-d '{"module":"CCRCQuoteLineEdit", "ext":"jar", "type":"springboot","hosts":["ccrc-srv-dev2-01","ccrc-srv-dev2-03"]}' \
'ccrc-build-5:5000/modules'
```

**PUT /module/:module** 
_modify module attributes or assign it new hosts_
```
Modify the [module] CCRCQuoteLineEdit to have an [ext] of jar, make no modification to its [type], 
and assign it two new [hosts] ccrc-srv-dev2-10 and ccrc-srv-dev2-12
$ curl -X PUT \
-d '{"ext":"jar","hosts":["ccrc-srv-dev2-10","ccrc-srv-dev2-12"]}' \
'ccrc-build-5:5000/module/CCRCQuoteLineEdit'
```

**POST /jenkins/create_deploy_job**
_create a new jenkins deploy job_
```
Create a new jenkins deploy job for [module] CCRCProxy on the jenkins [server] ccrc-build-docker-04 for [env] dev-main
of [type] os (openstack)
Supported types: os, cae
$ curl 'ccrc-build-5:5000/jenkins/create_deploy_job?server=ccrc-build-docker-04&module=CCRCProxy&env=dev-main&type=os'
```

**POST /jenkins/create_build_job**
_create a new jenkins build job_
```
Create a new jenkins build job for [module] CCRCProxy on the jenkins [server] ccrc-build-3 for [env] dev-main
$ curl 'ccrc-build-5:5000/jenkins/create_build_job?server=ccrc-build-3&module=CCRCProxy&env=dev-main'
```

**GET /hosts**
_retrieve environment and host data_
```
Get all hosts data
$ curl 'ccrc-build-5:5000/hosts

Get all hosts for [env] stage DC1 release
$ curl 'ccrc-build-5:5000/hosts?env=stg1-rel'

Get host information for single [host]
$ curl 'ccrc-build-5:5000/hosts?host=ccrc-srv-lt2-03'
```

### MySQL Database ###
All dynamic data is stored in a MySQL database. This data can be retrieved,
updated, or added via this service.

### Integrations ###
This service integrates with Jenkins using the python-jenkins module which is a wrapper on top of the Jenkins REST API