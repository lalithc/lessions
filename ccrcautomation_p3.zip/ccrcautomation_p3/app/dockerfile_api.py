import Logger
import config as conf

from pexpect import pxssh

def caedockerfilecreationsingle(moduleInfo,env,module_name):

    generic_basepath = ""


    project_name = namespace(env)
    rel_type = releasetype(env)

    print module_name

    module =  moduleInfo[module_name]
    module_type = module['type']
    service_name = module['service_name']
    min_heap = module['heap_min']
    max_heap = module['heap_max']

    if module_type == 'tomcat':
        generic_basepath = "/apps/automated-dockerfiles/tomcatmodule-cae/"
    if module_type == 'springboot':
        generic_basepath = "/apps/automated-dockerfiles/sbootmodule-cae/"
    if module_type == 'nodejs':
        generic_basepath = "/apps/automated-dockerfiles/nodemodule-cae/"
    if module_type == 'nginx':
        generic_basepath = "/apps/automated-dockerfiles/nginxmodule-cae/"
    if module_type == 'golang':
        generic_basepath = "/apps/automated-dockerfiles/golangmodule-cae/"

    generated_basepath = "/apps/automated-dockerfiles/generatedmodules/cae/%s-%s_CAE/" % (module_name,rel_type)

    print generated_basepath
    print generic_basepath

    s = pxssh.pxssh()
    if not s.login (conf.DOCKER_SERVER_NPRD, 'root', 'cisco999'):
        Logger.error('SSH session failed on login: %s' % str(s))
    else:
        s.sendline ('mkdir -p ' + generated_basepath)
        s.sendline ('rm -rf '+ generated_basepath + '/*')
        if module_name == 'CCRCUpload':
            s.sendline ('yes | cp -f ' + generic_basepath + 'Dockerfile-upload ' + generated_basepath+  '/Dockerfile')
        else:
            s.sendline ('yes | cp -f ' + generic_basepath + 'Dockerfile ' + generated_basepath+  '/Dockerfile')
            s.sendline ('yes | cp -Rf ' + generic_basepath + 'configs ' +  generated_basepath + '/configs')
            s.sendline ('sed -e "s/minheap/' + min_heap + 'M/" -e "s/maxheap/' + max_heap + 'M/" -e "s/appsrvname/' + service_name + '/" '+ generic_basepath + 'pre_start_config  >> ' + generated_basepath +'pre_start_config')
            s.sendline ('sed -e "s/servicename/' + service_name + '/" ' + generic_basepath + 'service-green.yaml  >> ' + generated_basepath + 'service-green.yaml')
            s.sendline ('sed -e "s/servicename/' + service_name + '/" ' + generic_basepath + 'service-blue.yaml  >> ' + generated_basepath + 'service-blue.yaml')
            s.sendline ('sed -e "s/servicename/' + service_name + '/" -e "s/appmodulename/' + module_name + '/" -e "s/reltype/' + rel_type + '/"  ' + generic_basepath + 'deployconfig-template-greeen.yaml  >> ' + generated_basepath +'deployconfig-template-greeen.yaml')
            s.sendline ('sed -e "s/servicename/' + service_name + '/" -e "s/appmodulename/' + module_name + '/" -e "s/reltype/' + rel_type + '/"  ' + generic_basepath + 'deployconfig-template-blue.yaml  >> ' + generated_basepath +'deployconfig-template-blue.yaml')
            s.sendline ('oc create -f  ' + generated_basepath + 'service-green.yaml -n ' + project_name)
            s.sendline ('oc create -f  ' + generated_basepath + 'service-blue.yaml -n ' + project_name)
    s.prompt()
    s.logout()

    response = "Success"
    return response


def caedockerfilecreation(moduleInfo,env):

    print caedockerfilecreation

    generic_basepath = ""


    project_name = namespace(env)
    print project_name
    rel_type = releasetype(env)

    for module_name in moduleInfo:
        print module_name
        module =  moduleInfo[module_name]
        module_type = module['type']
        service_name = module['service_name']
        min_heap = module['heap_min']
        max_heap = module['heap_max']

        if module_type == 'tomcat':
            generic_basepath = "/apps/automated-dockerfiles/tomcatmodule-cae/"
        if module_type == 'springboot':
            generic_basepath = "/apps/automated-dockerfiles/sbootmodule-cae/"
        if module_type == 'nodejs':
            generic_basepath = "/apps/automated-dockerfiles/nodemodule-cae/"
        if module_type == 'nginx':
            generic_basepath = "/apps/automated-dockerfiles/nginxmodule-cae/"
        if module_type == 'golang':
            generic_basepath = "/apps/automated-dockerfiles/golangmodule-cae/"

        generated_basepath = "/apps/automated-dockerfiles/generatedmodules/cae/%s-%s_CAE/" % (module_name,rel_type)

        s = pxssh.pxssh()
        if not s.login (conf.DOCKER_SERVER_NPRD, 'root', 'cisco999'):
            Logger.error('SSH session failed on login: %s' % str(s))
        else:
            s.sendline ('mkdir -p ' + generated_basepath)
            s.sendline ('rm -rf '+ generated_basepath + '/*')

            if module_name == 'CCRCUpload':
                s.sendline ('yes | cp -f ' + generic_basepath + 'Dockerfile-upload ' + generated_basepath+  '/Dockerfile')
            if module_name == 'EDWReports':
                s.sendline ('yes | cp -f ' + generic_basepath + 'EDWReports/Dockerfile ' + generated_basepath+  '/Dockerfile')
                s.sendline ('yes | cp -Rf ' + generic_basepath + 'EDWReports/trust ' +  generated_basepath + '/trust')
            if module_name == 'CCRCB2B':
                s.sendline ('yes | cp -f ' + generic_basepath + 'CCRCB2B/Dockerfile ' + generated_basepath+  '/Dockerfile')
                s.sendline ('yes | cp -Rf ' + generic_basepath + 'CCRCB2B/trust ' +  generated_basepath + '/trust')
            if module_name == 'CCRCSaaSService':
                s.sendline ('yes | cp -f ' + generic_basepath + 'CCRCSaaSService/Dockerfile ' + generated_basepath+  '/Dockerfile')
                s.sendline ('yes | cp -Rf ' + generic_basepath + 'CCRCSaaSService/certs ' +  generated_basepath + '/trust')
            if module_name == 'CCRCDashboard':
                s.sendline ('yes | cp -f ' + generic_basepath + 'CCRCDashboard/Dockerfile ' + generated_basepath+  '/Dockerfile')
            if module_name in ['CCRCCopyQuote' , 'CCRCSelectAll', 'CCRCUpload' , 'CCRCQuotingAsync','CCRCDownload','CCRCLocalz', 'CCRCB2BPunchout', 'CCRCBrandProtection','CCRCActivityLog','CCRCQuoteSummary']:
                s.sendline ('yes | cp -f ' + generic_basepath + 'NodeEight/Dockerfile ' + generated_basepath+  '/Dockerfile')
            else:
                s.sendline ('yes | cp -f ' + generic_basepath + 'Dockerfile ' + generated_basepath+  '/Dockerfile')

            s.sendline ('yes | cp -Rf ' + generic_basepath + 'configs ' +  generated_basepath + '/configs')

            s.sendline ('sed -e "s/minheap/' + min_heap + 'M/" -e "s/maxheap/' + max_heap + 'M/" -e "s/appsrvname/' + service_name + '/" '+ generic_basepath + 'pre_start_config  >> ' + generated_basepath +'pre_start_config')

            s.sendline ('sed -e "s/servicename/' + service_name + '/" ' + generic_basepath + 'route.yaml  >> ' + generated_basepath + 'route.yaml')

            s.sendline ('sed -e "s/servicename/' + service_name + '/" ' + generic_basepath + 'service-green.yaml  >> ' + generated_basepath + 'service-green.yaml')
            s.sendline ('sed -e "s/servicename/' + service_name + '/" ' + generic_basepath + 'service-blue.yaml  >> ' + generated_basepath + 'service-blue.yaml')

            s.sendline ('sed -e "s/servicename/' + service_name + '/" ' + generic_basepath + 'route.yaml  >> ' + generated_basepath + 'route.yaml')

            if module_name == 'CCRCConfig':
                s.sendline ('sed -e "s/servicename/' + service_name + '/" -e "s/appmodulename/' + module_name + '/" -e "s/reltype/' + rel_type + '/"  ' + generic_basepath + 'deployconfig-template-blue-config.yaml  >> ' + generated_basepath +'deployconfig-template-blue.yaml')
                s.sendline ('sed -e "s/servicename/' + service_name + '/" -e "s/appmodulename/' + module_name + '/" -e "s/reltype/' + rel_type + '/"  ' + generic_basepath + 'deployconfig-template-green-config.yaml  >> ' + generated_basepath +'deployconfig-template-green.yaml')
            elif module_name == 'CCRCDownload':
                s.sendline ('sed -e "s/servicename/' + service_name + '/" -e "s/appmodulename/' + module_name + '/" -e "s/reltype/' + rel_type + '/"  ' + generic_basepath + 'deployconfig-template-blue-download.yaml  >> ' + generated_basepath +'deployconfig-template-blue.yaml')
                s.sendline ('sed -e "s/servicename/' + service_name + '/" -e "s/appmodulename/' + module_name + '/" -e "s/reltype/' + rel_type + '/"  ' + generic_basepath + 'deployconfig-template-green-download.yaml  >> ' + generated_basepath +'deployconfig-template-green.yaml')
            elif module_name == 'CCRCLocalz':
                s.sendline ('sed -e "s/servicename/' + service_name + '/" -e "s/appmodulename/' + module_name + '/" -e "s/reltype/' + rel_type + '/"  ' + generic_basepath + 'deployconfig-template-blue-localz.yaml  >> ' + generated_basepath +'deployconfig-template-blue.yaml')
                s.sendline ('sed -e "s/servicename/' + service_name + '/" -e "s/appmodulename/' + module_name + '/" -e "s/reltype/' + rel_type + '/"  ' + generic_basepath + 'deployconfig-template-green-localz.yaml  >> ' + generated_basepath +'deployconfig-template-green.yaml')
            else:
                s.sendline ('sed -e "s/servicename/' + service_name + '/" -e "s/appmodulename/' + module_name + '/" -e "s/reltype/' + rel_type + '/"  ' + generic_basepath + 'deployconfig-template-blue.yaml  >> ' + generated_basepath +'deployconfig-template-blue.yaml')
                s.sendline ('sed -e "s/servicename/' + service_name + '/" -e "s/appmodulename/' + module_name + '/" -e "s/reltype/' + rel_type + '/"  ' + generic_basepath + 'deployconfig-template-green.yaml  >> ' + generated_basepath +'deployconfig-template-green.yaml')

            s.sendline ('oc create -f  ' + generated_basepath + 'service-green.yaml -n ' + project_name)
            s.sendline ('oc create -f  ' + generated_basepath + 'deployconfig-template-green.yaml -n ' + project_name)
            s.sendline ('oc create -f  ' + generated_basepath + 'service-blue.yaml -n ' + project_name)
            s.sendline ('oc create -f  ' + generated_basepath + 'deployconfig-template-blue.yaml -n ' + project_name)

        s.prompt()
        s.logout()

    response = "Success"
    return response



def caedeleteroute(moduleInfo,env):

    print caedockerfilecreation

    generic_basepath = ""


    project_name = namespace(env)
    rel_type = releasetype(env)
    print project_name

    for module_name in moduleInfo:
        print module_name
        module =  moduleInfo[module_name]
        module_type = module['type']
        service_name = module['service_name']
        min_heap = module['heap_min']
        max_heap = module['heap_max']

        if module_type == 'tomcat':
            generic_basepath = "/apps/automated-dockerfiles/tomcatmodule-cae/"
        if module_type == 'springboot':
            generic_basepath = "/apps/automated-dockerfiles/sbootmodule-cae/"
        if module_type == 'nodejs':
            generic_basepath = "/apps/automated-dockerfiles/nodemodule-cae/"
        if module_type == 'nginx':
            generic_basepath = "/apps/automated-dockerfiles/nginxmodule-cae/"
        if module_type == 'golang':
            generic_basepath = "/apps/automated-dockerfiles/golangmodule-cae/"

        generated_basepath = "/apps/automated-dockerfiles/generatedmodules/cae/%s-%s_CAE/" % (module_name,rel_type)

        s = pxssh.pxssh()
        if not s.login (conf.DOCKER_SERVER_NPRD, 'root', 'cisco999'):
            Logger.error('SSH session failed on login: %s' % str(s))
        else:
            print generated_basepath
            s.sendline ('oc create -f ' + generated_basepath + 'route.yaml -n ' + project_name)

        s.prompt()
        s.logout()

    response = "Success"
    return response


def caedeleteroute_rel(moduleInfo,env):

    print caedockerfilecreation

    generic_basepath = ""


    project_name = namespace(env)
    rel_type = releasetype(env)
    print project_name

    for module_name in moduleInfo:
        print module_name
        module =  moduleInfo[module_name]
        module_type = module['type']
        service_name = module['service_name']
        min_heap = module['heap_min']
        max_heap = module['heap_max']

        if module_type == 'tomcat':
            generic_basepath = "/apps/automated-dockerfiles/tomcatmodule-cae/"
        if module_type == 'springboot':
            generic_basepath = "/apps/automated-dockerfiles/sbootmodule-cae/"
        if module_type == 'nodejs':
            generic_basepath = "/apps/automated-dockerfiles/nodemodule-cae/"
        if module_type == 'nginx':
            generic_basepath = "/apps/automated-dockerfiles/nginxmodule-cae/"
        if module_type == 'golang':
            generic_basepath = "/apps/automated-dockerfiles/golangmodule-cae/"

        generated_basepath = "/apps/automated-dockerfiles/generatedmodules/cae/%s-%s_CAE/" % (module_name,rel_type)

        s = pxssh.pxssh()
        if not s.login (conf.DOCKER_SERVER_PRD, 'root', 'cisco999'):
            Logger.error('SSH session failed on login: %s' % str(s))
        else:
            #print generated_basepath
            s.sendline ('oc delete route ' +  service_name + ' -n ' + project_name)
            s.sendline ('oc delete dc/' +  service_name + ' -n ' + project_name)
            s.sendline ('oc delete service ' +  service_name + ' -n ' + project_name)
            #s.sendline ('oc create -f ' + generated_basepath + 'route-'+ env +'.yaml -n ' + project_name)

        s.prompt()
        s.logout()

    response = "Success"
    return response

def caecreateservice_rel(moduleInfo,env):

    print "Inside create"

    generic_basepath = ""


    project_name = namespace(env)
    rel_type = releasetype(env)
    print project_name

    for module_name in moduleInfo:
        print module_name
        module =  moduleInfo[module_name]
        module_type = module['type']
        service_name = module['service_name']
        min_heap = module['heap_min']
        max_heap = module['heap_max']

        if module_type == 'tomcat':
            generic_basepath = "/apps/automated-dockerfiles/tomcatmodule-cae/"
        if module_type == 'springboot':
            generic_basepath = "/apps/automated-dockerfiles/sbootmodule-cae/"
        if module_type == 'nodejs':
            generic_basepath = "/apps/automated-dockerfiles/nodemodule-cae/"
        if module_type == 'nginx':
            generic_basepath = "/apps/automated-dockerfiles/nginxmodule-cae/"
        if module_type == 'golang':
            generic_basepath = "/apps/automated-dockerfiles/golangmodule-cae/"

        generated_basepath = "/apps/automated-dockerfiles/generatedmodules/cae/%s-%s_CAE/" % (module_name,rel_type)

        s = pxssh.pxssh()
        if not s.login (conf.DOCKER_SERVER_PRD, 'root', 'cisco999'):
            Logger.error('SSH session failed on login: %s' % str(s))
        else:
            #print generated_basepath
            #s.sendline ('oc delete route ' +  service_name + ' -n ' + project_name)
            #s.sendline ('oc delete dc/' +  service_name + ' -n ' + project_name)
            s.sendline ('oc create -f ' + generated_basepath + 'service-blue.yaml -n ' + project_name)
            s.sendline ('oc create -f ' + generated_basepath + 'service-green.yaml -n ' + project_name)
            s.sendline ('oc create -f ' + generated_basepath + 'deployconfig-template-' + env+ '-blue.yaml -n ' + project_name)
            s.sendline ('oc create -f ' + generated_basepath + 'deployconfig-template-' + env+ '-green.yaml -n ' + project_name)
        s.prompt()
        s.logout()

    response = "Success"
    return response



def caedockerfilecreationall_rel(moduleInfo,env):

    generic_basepath = ""


    rel_type = releasetype(env)

    project_name = namespace(env)
    print project_name


    for module_name in moduleInfo:
        print module_name
        module =  moduleInfo[module_name]
        module_type = module['type']
        service_name = module['service_name']
        min_heap = module['heap_min']
        max_heap = module['heap_max']
        blue_replica_stg2_rel = module["envs"]["stg2-rel"]['blue_replicas']
        green_replica_stg2_rel = module["envs"]["stg2-rel"]['green_replicas']
        blue_replica_pre_prd1 = module["envs"]["pre-prd1"]['blue_replicas']
        green_replica_pre_prd1 = module["envs"]["pre-prd1"]['green_replicas']
        blue_replica_prd1 = module["envs"]["prd1"]['blue_replicas']
        green_replica_prd1 = module["envs"]["prd1"]['green_replicas']
        container_cpu = module['container_cpu']
        container_mem = module['container_mem']

        if module_type == 'tomcat':
            generic_basepath = "/apps/automated-dockerfiles/release/tomcatmodule-cae/"
        if module_type == 'springboot':
            generic_basepath = "/apps/automated-dockerfiles/release/sbootmodule-cae/"
        if module_type == 'nodejs':
            generic_basepath = "/apps/automated-dockerfiles/release/nodemodule-cae/"
        if module_type == 'nginx':
            generic_basepath = "/apps/automated-dockerfiles/release/nginxmodule-cae/"
        if module_type == 'golang':
            generic_basepath = "/apps/automated-dockerfiles/release/golangmodule-cae/"

        generated_basepath = "/apps/automated-dockerfiles/generatedmodules/cae/%s-%s_CAE/" % (module_name,rel_type)

        #print generated_basepath
        #print generic_basepath

        s = pxssh.pxssh()
        if not s.login (conf.DOCKER_SERVER_PRD, 'root', 'cisco999'):
            Logger.error('SSH session failed on login: %s' % str(s))
        else:
            s.sendline ('mkdir -p ' + generated_basepath)
            s.sendline ('rm -rf '+ generated_basepath + '/*')
            if module_name == 'CCRCUpload':
                s.sendline ('yes | cp -f ' + generic_basepath + 'CCRCUpload/Dockerfile-upload ' + generated_basepath+  'Dockerfile')
            elif module_name == 'CCRB2B':
                s.sendline ('yes | cp -f ' + generic_basepath + 'CCRCB2B/Dockerfile ' + generated_basepath+  'Dockerfile')
                s.sendline ('yes | cp -Rf ' + generic_basepath + 'CCRCB2B/trust ' +  generated_basepath + 'trust')
            elif module_name == 'CCRCDashboard':
                s.sendline ('yes | cp -f ' + generic_basepath + 'CCRCDashboard/Dockerfile ' + generated_basepath+  'Dockerfile')
            elif module_name == 'EDWReports':
                s.sendline ('yes | cp -f ' + generic_basepath + 'EDWReports/Dockerfile ' + generated_basepath+  'Dockerfile')
                s.sendline ('yes | cp -Rf ' + generic_basepath + 'EDWReports/trust ' +  generated_basepath + 'trust')
            else:
                s.sendline ('yes | cp -f ' + generic_basepath + 'Dockerfile ' + generated_basepath+  'Dockerfile')

            s.sendline ('yes | cp -Rf ' + generic_basepath + 'configs ' +  generated_basepath + 'configs')

            if module_name == 'QOTService':
                s.sendline ('sed -e "s/minheap/' + min_heap + 'M/" -e "s/maxheap/' + max_heap + 'M/" -e "s/appsrvname/' + service_name + '/" '+ generic_basepath + 'QOTService/pre_start_config  >> ' + generated_basepath +'pre_start_config')
            else:
                s.sendline ('sed -e "s/minheap/' + min_heap + 'M/" -e "s/maxheap/' + max_heap + 'M/" -e "s/appsrvname/' + service_name + '/" '+ generic_basepath + 'pre_start_config  >> ' + generated_basepath +'pre_start_config')

            s.sendline ('sed -e "s/servicename/' + service_name + '/" ' + generic_basepath + 'service-blue.yaml  >> ' + generated_basepath + 'service-blue.yaml')
            s.sendline ('sed -e "s/servicename/' + service_name + '/" ' + generic_basepath + 'service-green.yaml  >> ' + generated_basepath + 'service-green.yaml')

            s.sendline ('sed -e "s/servicename/' + service_name + '/" -e "s/enviornment/' + env + '/" '  + generic_basepath + 'route-stg2-rel.yaml  >> ' + generated_basepath + 'route-stg2-rel.yaml')
            s.sendline ('sed -e "s/servicename/' + service_name + '/" -e "s/enviornment/' + env + '/" '  + generic_basepath + 'route-preprd1.yaml  >> ' + generated_basepath + 'route-preprd1.yaml')
            s.sendline ('sed -e "s/servicename/' + service_name + '/" -e "s/enviornment/' + env + '/" '  + generic_basepath + 'route-prd1.yaml  >> ' + generated_basepath + 'route-prd1.yaml')

            #s.sendline ('oc create -f  ' + generated_basepath + 'service-blue.yaml -n ' + project_name)
            #s.sendline ('oc create -f  ' + generated_basepath + 'service-green.yaml -n ' + project_name)

            if(module_type == 'nodejs'):
                if(module_name == 'CCRCDownload'):
                    s.sendline ('sed -e "s/servicename/' + service_name + '/" -e "s/appmodulename/' + module_name + '/" -e "s/reltype/' + rel_type + '/" -e "s/svcreplica/' + blue_replica_stg2_rel + '/" -e "s/containercpu/' + container_cpu + '/" -e "s/containermem/' + container_mem + '/" ' + generic_basepath + 'CCRCDownload/deployconfig-template-stg2-rel-download-blue.yaml  >> ' + generated_basepath +'deployconfig-template-stg2-rel-blue.yaml')
                    s.sendline ('sed -e "s/servicename/' + service_name + '/" -e "s/appmodulename/' + module_name + '/" -e "s/reltype/' + rel_type + '/" -e "s/svcreplica/' + green_replica_stg2_rel + '/" -e "s/containercpu/' + container_cpu + '/" -e "s/containermem/' + container_mem + '/" ' + generic_basepath + 'CCRCDownload/deployconfig-template-stg2-rel-download-green.yaml  >> ' + generated_basepath +'deployconfig-template-stg2-rel-green.yaml')
                    s.sendline ('sed -e "s/servicename/' + service_name + '/" -e "s/appmodulename/' + module_name + '/" -e "s/reltype/' + rel_type + '/" -e "s/svcreplica/' + blue_replica_pre_prd1 + '/" -e "s/containercpu/' + container_cpu + '/" -e "s/containermem/' + container_mem + '/" ' + generic_basepath + 'CCRCDownload/deployconfig-template-preprd1-download-blue.yaml  >> ' + generated_basepath +'deployconfig-template-preprd1-blue.yaml')
                    s.sendline ('sed -e "s/servicename/' + service_name + '/" -e "s/appmodulename/' + module_name + '/" -e "s/reltype/' + rel_type + '/" -e "s/svcreplica/' + green_replica_pre_prd1 + '/" -e "s/containercpu/' + container_cpu + '/" -e "s/containermem/' + container_mem + '/" ' + generic_basepath + 'CCRCDownload/deployconfig-template-preprd1-download-green.yaml  >> ' + generated_basepath +'deployconfig-template-preprd1-green.yaml')
                    s.sendline ('sed -e "s/servicename/' + service_name + '/" -e "s/appmodulename/' + module_name + '/" -e "s/reltype/' + rel_type + '/" -e "s/svcreplica/' + blue_replica_prd1 + '/" -e "s/containercpu/' + container_cpu + '/" -e "s/containermem/' + container_mem + '/" ' + generic_basepath + 'CCRCDownload/deployconfig-template-prd1-download-blue.yaml  >> ' + generated_basepath +'deployconfig-template-prd1-blue.yaml')
                    s.sendline ('sed -e "s/servicename/' + service_name + '/" -e "s/appmodulename/' + module_name + '/" -e "s/reltype/' + rel_type + '/" -e "s/svcreplica/' + green_replica_prd1 + '/" -e "s/containercpu/' + container_cpu + '/" -e "s/containermem/' + container_mem + '/" ' + generic_basepath + 'CCRCDownload/deployconfig-template-prd1-download-green.yaml  >> ' + generated_basepath +'deployconfig-template-prd1-green.yaml')

                elif(module_name == 'CCRCLocalz'):
                    s.sendline ('sed -e "s/servicename/' + service_name + '/" -e "s/appmodulename/' + module_name + '/" -e "s/reltype/' + rel_type + '/" -e "s/svcreplica/' + blue_replica_stg2_rel + '/" -e "s/containercpu/' + container_cpu + '/" -e "s/containermem/' + container_mem + '/" ' + generic_basepath + 'CCRCLocalz/deployconfig-template-stg2-rel-localz-blue.yaml  >> ' + generated_basepath +'deployconfig-template-stg2-rel-blue.yaml')
                    s.sendline ('sed -e "s/servicename/' + service_name + '/" -e "s/appmodulename/' + module_name + '/" -e "s/reltype/' + rel_type + '/" -e "s/svcreplica/' + green_replica_stg2_rel + '/" -e "s/containercpu/' + container_cpu + '/" -e "s/containermem/' + container_mem + '/" ' + generic_basepath + 'CCRCLocalz/deployconfig-template-stg2-rel-localz-green.yaml  >> ' + generated_basepath +'deployconfig-template-stg2-rel-green.yaml')
                    s.sendline ('sed -e "s/servicename/' + service_name + '/" -e "s/appmodulename/' + module_name + '/" -e "s/reltype/' + rel_type + '/" -e "s/svcreplica/' + blue_replica_pre_prd1 + '/" -e "s/containercpu/' + container_cpu + '/" -e "s/containermem/' + container_mem + '/" ' + generic_basepath + 'CCRCLocalz/deployconfig-template-preprd1-localz-blue.yaml  >> ' + generated_basepath +'deployconfig-template-preprd1-blue.yaml')
                    s.sendline ('sed -e "s/servicename/' + service_name + '/" -e "s/appmodulename/' + module_name + '/" -e "s/reltype/' + rel_type + '/" -e "s/svcreplica/' + green_replica_pre_prd1 + '/" -e "s/containercpu/' + container_cpu + '/" -e "s/containermem/' + container_mem + '/" ' + generic_basepath + 'CCRCLocalz/deployconfig-template-preprd1-localz-green.yaml  >> ' + generated_basepath +'deployconfig-template-preprd1-green.yaml')
                    s.sendline ('sed -e "s/servicename/' + service_name + '/" -e "s/appmodulename/' + module_name + '/" -e "s/reltype/' + rel_type + '/" -e "s/svcreplica/' + blue_replica_prd1 + '/" -e "s/containercpu/' + container_cpu + '/" -e "s/containermem/' + container_mem + '/" ' + generic_basepath + 'CCRCLocalz/deployconfig-template-prd1-localz-blue.yaml  >> ' + generated_basepath +'deployconfig-template-prd1-blue.yaml')
                    s.sendline ('sed -e "s/servicename/' + service_name + '/" -e "s/appmodulename/' + module_name + '/" -e "s/reltype/' + rel_type + '/" -e "s/svcreplica/' + green_replica_prd1 + '/" -e "s/containercpu/' + container_cpu + '/" -e "s/containermem/' + container_mem + '/" ' + generic_basepath + 'CCRCLocalz/deployconfig-template-prd1-localz-green.yaml  >> ' + generated_basepath +'deployconfig-template-prd1-green.yaml')
                else:
                    s.sendline ('sed -e "s/servicename/' + service_name + '/" -e "s/appmodulename/' + module_name + '/" -e "s/reltype/' + rel_type + '/" -e "s/svcreplica/' + blue_replica_stg2_rel + '/" -e "s/containercpu/' + container_cpu + '/" -e "s/containermem/' + container_mem + '/" ' + generic_basepath + 'deployconfig-template-stg2-rel-blue.yaml  >> ' + generated_basepath +'deployconfig-template-stg2-rel-blue.yaml')
                    s.sendline ('sed -e "s/servicename/' + service_name + '/" -e "s/appmodulename/' + module_name + '/" -e "s/reltype/' + rel_type + '/" -e "s/svcreplica/' + green_replica_stg2_rel + '/" -e "s/containercpu/' + container_cpu + '/" -e "s/containermem/' + container_mem + '/" ' + generic_basepath + 'deployconfig-template-stg2-rel-green.yaml  >> ' + generated_basepath +'deployconfig-template-stg2-rel-green.yaml')
                    s.sendline ('sed -e "s/servicename/' + service_name + '/" -e "s/appmodulename/' + module_name + '/" -e "s/reltype/' + rel_type + '/" -e "s/svcreplica/' + blue_replica_pre_prd1 + '/" -e "s/containercpu/' + container_cpu + '/" -e "s/containermem/' + container_mem + '/" ' + generic_basepath + 'deployconfig-template-preprd1-blue.yaml  >> ' + generated_basepath +'deployconfig-template-preprd1-blue.yaml')
                    s.sendline ('sed -e "s/servicename/' + service_name + '/" -e "s/appmodulename/' + module_name + '/" -e "s/reltype/' + rel_type + '/" -e "s/svcreplica/' + green_replica_pre_prd1 + '/" -e "s/containercpu/' + container_cpu + '/" -e "s/containermem/' + container_mem + '/" ' + generic_basepath + 'deployconfig-template-preprd1-green.yaml  >> ' + generated_basepath +'deployconfig-template-preprd1-green.yaml')
                    s.sendline ('sed -e "s/servicename/' + service_name + '/" -e "s/appmodulename/' + module_name + '/" -e "s/reltype/' + rel_type + '/" -e "s/svcreplica/' + blue_replica_prd1 + '/" -e "s/containercpu/' + container_cpu + '/" -e "s/containermem/' + container_mem + '/" ' + generic_basepath + 'deployconfig-template-prd1-blue.yaml  >> ' + generated_basepath +'deployconfig-template-prd1-blue.yaml')
                    s.sendline ('sed -e "s/servicename/' + service_name + '/" -e "s/appmodulename/' + module_name + '/" -e "s/reltype/' + rel_type + '/" -e "s/svcreplica/' + green_replica_prd1 + '/" -e "s/containercpu/' + container_cpu + '/" -e "s/containermem/' + container_mem + '/" ' + generic_basepath + 'deployconfig-template-prd1-green.yaml  >> ' + generated_basepath +'deployconfig-template-prd1-green.yaml')
            else:
                if(module_name == 'CCRCConfig'):
                    s.sendline ('sed -e "s/servicename/' + service_name + '/" -e "s/appmodulename/' + module_name + '/" -e "s/reltype/' + rel_type + '/" -e "s/svcreplica/' + blue_replica_stg2_rel + '/" -e "s/containercpu/' + container_cpu + '/" -e "s/containermem/' + container_mem + '/" ' + generic_basepath + 'CCRCConfig/deployconfig-template-config-blue.yaml  >> ' + generated_basepath +'deployconfig-template-stg2-rel-blue.yaml')
                    s.sendline ('sed -e "s/servicename/' + service_name + '/" -e "s/appmodulename/' + module_name + '/" -e "s/reltype/' + rel_type + '/" -e "s/svcreplica/' + green_replica_stg2_rel + '/" -e "s/containercpu/' + container_cpu + '/" -e "s/containermem/' + container_mem + '/" ' + generic_basepath + 'CCRCConfig/deployconfig-template-config-green.yaml  >> ' + generated_basepath +'deployconfig-template-stg2-rel-green.yaml')
                    s.sendline ('sed -e "s/servicename/' + service_name + '/" -e "s/appmodulename/' + module_name + '/" -e "s/reltype/' + rel_type + '/" -e "s/svcreplica/' + blue_replica_pre_prd1 + '/" -e "s/containercpu/' + container_cpu + '/" -e "s/containermem/' + container_mem + '/" ' + generic_basepath + 'CCRCConfig/deployconfig-template-config-blue.yaml  >> ' + generated_basepath +'deployconfig-template-preprd1-blue.yaml')
                    s.sendline ('sed -e "s/servicename/' + service_name + '/" -e "s/appmodulename/' + module_name + '/" -e "s/reltype/' + rel_type + '/" -e "s/svcreplica/' + green_replica_pre_prd1 + '/" -e "s/containercpu/' + container_cpu + '/" -e "s/containermem/' + container_mem + '/" ' + generic_basepath + 'CCRCConfig/deployconfig-template-config-green.yaml  >> ' + generated_basepath +'deployconfig-template-preprd1-green.yaml')
                    s.sendline ('sed -e "s/servicename/' + service_name + '/" -e "s/appmodulename/' + module_name + '/" -e "s/reltype/' + rel_type + '/" -e "s/svcreplica/' + blue_replica_prd1 + '/" -e "s/containercpu/' + container_cpu + '/" -e "s/containermem/' + container_mem + '/" ' + generic_basepath + 'CCRCConfig/deployconfig-template-config-blue.yaml  >> ' + generated_basepath +'deployconfig-template-prd1-blue.yaml')
                    s.sendline ('sed -e "s/servicename/' + service_name + '/" -e "s/appmodulename/' + module_name + '/" -e "s/reltype/' + rel_type + '/" -e "s/svcreplica/' + green_replica_prd1 + '/" -e "s/containercpu/' + container_cpu + '/" -e "s/containermem/' + container_mem + '/" ' + generic_basepath + 'CCRCConfig/deployconfig-template-config-green.yaml  >> ' + generated_basepath +'deployconfig-template-prd1-green.yaml')
                else:
                    s.sendline ('sed -e "s/servicename/' + service_name + '/" -e "s/appmodulename/' + module_name + '/" -e "s/reltype/' + rel_type + '/" -e "s/svcreplica/' + blue_replica_stg2_rel + '/" -e "s/containercpu/' + container_cpu + '/" -e "s/containermem/' + container_mem + '/" ' + generic_basepath + 'deployconfig-template-blue.yaml  >> ' + generated_basepath +'deployconfig-template-stg2-rel-blue.yaml')
                    s.sendline ('sed -e "s/servicename/' + service_name + '/" -e "s/appmodulename/' + module_name + '/" -e "s/reltype/' + rel_type + '/" -e "s/svcreplica/' + green_replica_stg2_rel + '/" -e "s/containercpu/' + container_cpu + '/" -e "s/containermem/' + container_mem + '/" ' + generic_basepath + 'deployconfig-template-green.yaml >> ' + generated_basepath +'deployconfig-template-stg2-rel-green.yaml')
                    s.sendline ('sed -e "s/servicename/' + service_name + '/" -e "s/appmodulename/' + module_name + '/" -e "s/reltype/' + rel_type + '/" -e "s/svcreplica/' + blue_replica_pre_prd1 + '/" -e "s/containercpu/' + container_cpu + '/" -e "s/containermem/' + container_mem + '/" ' + generic_basepath + 'deployconfig-template-blue.yaml  >> ' + generated_basepath +'deployconfig-template-preprd1-blue.yaml')
                    s.sendline ('sed -e "s/servicename/' + service_name + '/" -e "s/appmodulename/' + module_name + '/" -e "s/reltype/' + rel_type + '/" -e "s/svcreplica/' + green_replica_pre_prd1 + '/" -e "s/containercpu/' + container_cpu + '/" -e "s/containermem/' + container_mem + '/" ' + generic_basepath + 'deployconfig-template-green.yaml >> ' + generated_basepath +'deployconfig-template-preprd1-green.yaml')
                    s.sendline ('sed -e "s/servicename/' + service_name + '/" -e "s/appmodulename/' + module_name + '/" -e "s/reltype/' + rel_type + '/" -e "s/svcreplica/' + blue_replica_prd1 + '/" -e "s/containercpu/' + container_cpu + '/" -e "s/containermem/' + container_mem + '/" ' + generic_basepath + 'deployconfig-template-blue.yaml  >> ' + generated_basepath +'deployconfig-template-prd1-blue.yaml')
                    s.sendline ('sed -e "s/servicename/' + service_name + '/" -e "s/appmodulename/' + module_name + '/" -e "s/reltype/' + rel_type + '/" -e "s/svcreplica/' + green_replica_prd1 + '/" -e "s/containercpu/' + container_cpu + '/" -e "s/containermem/' + container_mem + '/" ' + generic_basepath + 'deployconfig-template-green.yaml >> ' + generated_basepath +'deployconfig-template-prd1-green.yaml')


                    #s.sendline ('oc create -f  ' + generated_basepath + 'deployconfig-template-' +  env  + '.yaml -n ' + project_name)

        s.prompt()
        s.logout()

    response = "Success"
    return response


def osdockerfilecreation(modulename, servicename, moduletype, minheap, maxheap, jmxport, rmiport):

    generated_basepath = "/apps/automated-dockerfiles/generatedmodules/os/%s-%s/" % (modulename,'main')
    generic_basepath = ""

    if moduletype == 'tomcat':
        if modulename == 'NGVSService':
            generic_basepath = "/apps/automated-dockerfiles/tomcat7module-os/"
        else:
            generic_basepath = "/apps/automated-dockerfiles/tomcatmodule-os/"
    if moduletype == 'springboot':
        generic_basepath = "/apps/automated-dockerfiles/sbootmodule-os/"
    if moduletype == 'nodejs':
        generic_basepath = "/apps/automated-dockerfiles/nodemodule-os/"
    if moduletype == 'nginx':
        generic_basepath = "/apps/automated-dockerfiles/nginxmodule-os/"


    s = pxssh.pxssh()
    if not s.login (conf.DOCKER_SERVER_NPRD, 'root', 'cisco999'):
        Logger.error('SSH session failed on login: %s' % str(s))
    else:
        s.sendline ('mkdir -p ' + generated_basepath)

        s.sendline ('rm -rf '+ generated_basepath + '/*')

        if(modulename == 'CCRCB2B'):
            print "Inside B2B"
            s.sendline ('yes | cp -f ' + generic_basepath + 'CCRCB2B/Dockerfile ' + generated_basepath+  '/Dockerfile')
            s.sendline ('yes | cp -Rf ' + generic_basepath + 'CCRCB2B/trust ' +  generated_basepath + '/trust')
        elif(modulename == 'EDWReports'):
            s.sendline ('yes | cp -f ' + generic_basepath + 'EDWReports/Dockerfile ' + generated_basepath+  '/Dockerfile')
            s.sendline ('yes | cp -Rf ' + generic_basepath + 'EDWReports/trust ' +  generated_basepath + '/trust')
        elif(modulename == 'CCRCDashboard'):
            s.sendline ('yes | cp -f ' + generic_basepath + 'CCRCDashboard/Dockerfile ' + generated_basepath+  '/Dockerfile')
        elif(modulename == 'CCRCDownload'):
            s.sendline ('yes | cp -f ' + generic_basepath + 'CCRCDownload/Dockerfile ' + generated_basepath+  '/Dockerfile')
        elif(modulename == 'CCRCCommonUX'):
            s.sendline ('yes | cp -f ' + generic_basepath + 'CCRCCommonUX/Dockerfile ' + generated_basepath+  '/Dockerfile')
            s.sendline ('yes | cp -Rf ' + generic_basepath + 'CCRCCommonUX/configs ' +  generated_basepath + '/configs')
        elif(modulename == 'CCRCSaaSUI'):
            s.sendline ('yes | cp -f ' + generic_basepath + 'CCRCSaaSUI/Dockerfile ' + generated_basepath+  '/Dockerfile')
            s.sendline ('yes | cp -Rf ' + generic_basepath + 'CCRCSaaSUI/configs ' +  generated_basepath + '/configs')
        elif(modulename == 'swsspa'):
            s.sendline ('yes | cp -f ' + generic_basepath + 'swsspa/Dockerfile ' + generated_basepath+  '/Dockerfile')
            s.sendline ('yes | cp -Rf ' + generic_basepath + 'swsspa/configs ' +  generated_basepath + '/configs') 
        elif(modulename == 'Opportunity'):
            s.sendline ('yes | cp -f ' + generic_basepath + 'Opportunity/Dockerfile ' + generated_basepath+  '/Dockerfile')
            s.sendline ('yes | cp -Rf ' + generic_basepath + 'Opportunity/configs ' +  generated_basepath + '/configs')        
        elif(modulename == 'CCRCDownloadNginx'):
            s.sendline ('yes | cp -f ' + generic_basepath + 'CCRCDownloadNginx/Dockerfile ' + generated_basepath+  '/Dockerfile')
            s.sendline ('yes | cp -Rf ' + generic_basepath + 'CCRCDownloadNginx/configs ' +  generated_basepath + '/configs')
        else:
            s.sendline ('yes | cp -f ' + generic_basepath + 'Dockerfile ' + generated_basepath+  '/Dockerfile')

        if(moduletype == 'tomcat' or moduletype == 'springboot' or moduletype == 'nodejs'):
            s.sendline ('yes | cp -Rf ' + generic_basepath + 'configs ' +  generated_basepath + '/configs')

        if(moduletype == 'tomcat' or moduletype == 'springboot'):
            s.sendline ('sed -e "s/minheap/' + minheap + 'M/" -e "s/maxheap/' + maxheap + 'M/" -e "s/rmiport/' + rmiport + '/" -e "s/jmxport/' + jmxport + '/" -e "s/apptiername/' + modulename.lower() + '/" ' + generic_basepath + 'pre_start_config  >> ' + generated_basepath +'pre_start_config')

        s.prompt()
        s.logout()

    response = "Success"
    return response


def osdockerfilecreation_rel_single(modulename,moduleInfo):

    module =  moduleInfo[modulename]
    moduletype = module['type']
    servicename = module['service_name']
    minheap = module['heap_min']
    maxheap = module['heap_max']
    jmxport = module['jmx_port']
    rmiport = module['rmi_port']

    sshprompt = pxssh.pxssh()
    if not sshprompt.login (conf.DOCKER_SERVER_PRD, 'root', 'cisco999'):
        Logger.error('SSH session failed on login: %s' % str(s))
    else:
        response = osdockerfilecreation_rel(sshprompt,modulename, servicename, moduletype, minheap, maxheap, jmxport, rmiport)

        sshprompt.prompt()
        sshprompt.logout()

    response = "Success"
    return response


def osdockerfilecreation_rel_all(moduleInfo):


    sshprompt = pxssh.pxssh()
    if not sshprompt.login (conf.DOCKER_SERVER_PRD, 'root', 'cisco999'):
        Logger.error('SSH session failed on login: %s' % str(s))
    else:
        for modulename in moduleInfo:
            module =  moduleInfo[modulename]
            moduletype = module['type']
            servicename = module['service_name']
            minheap = module['heap_min']
            maxheap = module['heap_max']
            jmxport = module['jmx_port']
            rmiport = module['rmi_port']

            response = osdockerfilecreation_rel(sshprompt,modulename, servicename, moduletype, minheap, maxheap, jmxport, rmiport)

        sshprompt.prompt()
        sshprompt.logout()

    response = "Success"
    return response


def osdockerfilecreation_rel(sshprompt,modulename, servicename, moduletype, minheap, maxheap, jmxport, rmiport):

    print modulename

    generated_basepath = "/apps/automated-dockerfiles/generatedmodules/os/%s-%s/" % (modulename,'ps')
    generic_basepath = ""

    if moduletype == 'tomcat':
        generic_basepath = "/apps/automated-dockerfiles/release/tomcatmodule-os/"
    if moduletype == 'springboot':
        generic_basepath = "/apps/automated-dockerfiles/release/sbootmodule-os/"
    if moduletype == 'nodejs':
        generic_basepath = "/apps/automated-dockerfiles/release/nodemodule-os/"
    if moduletype == 'nginx':
        generic_basepath = "/apps/automated-dockerfiles/release/nginxmodule-os/"


    sshprompt.sendline ('mkdir -p ' + generated_basepath)

    sshprompt.sendline ('rm -rf '+ generated_basepath + '/*')

    if(modulename == 'CCRCB2B'):
        print "Inside B2B"
        sshprompt.sendline ('yes | cp -f ' + generic_basepath + 'CCRCB2B/Dockerfile ' + generated_basepath+  '/Dockerfile')
        sshprompt.sendline ('yes | cp -Rf ' + generic_basepath + 'CCRCB2B/trust ' +  generated_basepath + '/trust')
    elif(modulename == 'EDWReports'):
        sshprompt.sendline ('yes | cp -f ' + generic_basepath + 'EDWReports/Dockerfile ' + generated_basepath+  '/Dockerfile')
        sshprompt.sendline ('yes | cp -Rf ' + generic_basepath + 'EDWReports/trust ' +  generated_basepath + '/trust')
    elif(modulename == 'CCRCDashboard'):
        sshprompt.sendline ('yes | cp -f ' + generic_basepath + 'CCRCDashboard/Dockerfile ' + generated_basepath+  '/Dockerfile')
    elif(modulename == 'CCRCDownload'):
        sshprompt.sendline ('yes | cp -f ' + generic_basepath + 'CCRCDownload/Dockerfile ' + generated_basepath+  '/Dockerfile')
    elif(modulename == 'CCRCCommonUX'):
        sshprompt.sendline ('yes | cp -f ' + generic_basepath + 'CCRCCommonUX/Dockerfile ' + generated_basepath+  '/Dockerfile')
        sshprompt.sendline ('yes | cp -Rf ' + generic_basepath + 'CCRCCommonUX/configs ' +  generated_basepath + '/configs')
    elif(modulename == 'CCRCSaaSUI'):
        sshprompt.sendline ('yes | cp -f ' + generic_basepath + 'CCRCSaaSUI/Dockerfile ' + generated_basepath+  '/Dockerfile')
        sshprompt.sendline ('yes | cp -Rf ' + generic_basepath + 'CCRCSaaSUI/configs ' +  generated_basepath + '/configs')
    elif(modulename == 'swsspa'):
            s.sendline ('yes | cp -f ' + generic_basepath + 'swsspa/Dockerfile ' + generated_basepath+  '/Dockerfile')
            s.sendline ('yes | cp -Rf ' + generic_basepath + 'swsspa/configs ' +  generated_basepath + '/configs') 
    elif(modulename == 'CCRCDownloadNginx'):
        sshprompt.sendline ('yes | cp -f ' + generic_basepath + 'CCRCDownloadNginx/Dockerfile ' + generated_basepath+  '/Dockerfile')
        sshprompt.sendline ('yes | cp -Rf ' + generic_basepath + 'CCRCDownloadNginx/configs ' +  generated_basepath + '/configs')
    else:
        sshprompt.sendline ('yes | cp -f ' + generic_basepath + 'Dockerfile ' + generated_basepath+  '/Dockerfile')

    sshprompt.sendline ('yes | cp -Rf ' + generic_basepath + 'configs ' +  generated_basepath + '/configs')

    if(modulename == 'CCRCCommonUX'):
        sshprompt.sendline ('yes | cp -f ' + generic_basepath + 'CCRCCommonUX/env.js ' + generated_basepath+  '/env.js')

    if(modulename == 'CCRCSaaSUI-ps'):
        sshprompt.sendline ('yes | cp -f ' + generic_basepath + 'CCRCSaaSUI/env.js ' + generated_basepath+  '/env.js')
 
    if(moduletype == 'tomcat' or moduletype == 'springboot'):
        sshprompt.sendline ('sed -e "s/minheap/' + minheap + 'M/" -e "s/maxheap/' + maxheap + 'M/" -e "s/rmiport/' + rmiport + '/" -e "s/jmxport/' + jmxport + '/" -e "s/apptiername/' + modulename.lower() + '/" ' + generic_basepath + 'pre_start_config  >> ' + generated_basepath +'pre_start_config')

    response = "Success"
    return response


def namespace(env):
    namespace = ""
    conf.getNamespace(env)
    return namespace

def releasetype(env):
    releasetype = ""
    if ("main" in env):
        releasetype = "main"
    else:
        releasetype = "ps"
    return releasetype
