import db.data as db_api
import dockerfile_api


def setup_dockerfile(module_name, env, dockerfile_type):
    
    moduleInfo = db_api.get_module(module_name)

    moduleObj = moduleInfo[module_name]
    module_type = moduleObj['type']
    service_name = moduleObj['service_name']
    min_heap = moduleObj['heap_min']
    max_heap = moduleObj['heap_max']
    jmx_port = moduleObj['jmx_port']
    rmi_port = moduleObj['rmi_port']

    response = ""
    if dockerfile_type == "cae":
        response = dockerfile_api.caedockerfilecreationsingle(moduleInfo,env,module_name)
    elif dockerfile_type == "os":
        if(env == 'main'):
            response = dockerfile_api.osdockerfilecreation(module_name, service_name, module_type, min_heap, max_heap,
                                                       jmx_port, rmi_port)
        elif(env == 'rel'):
            response = dockerfile_api.osdockerfilecreation_rel_single(module_name,moduleInfo)

    if response == "Success":
        return "Successfully setup %s dockerfile for module %s in env %s " % (dockerfile_type, module_name, env)
