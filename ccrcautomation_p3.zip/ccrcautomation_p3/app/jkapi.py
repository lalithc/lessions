import xml_api
from jenkins import Jenkins
import config as conf


def get_job_name(module_name, env, goal, job_type, saas=""):
    res = env.split('-')
    lifecycle = res[0].title()
    if len(res) > 1:
        main_rel = res[1] 

    if env == "dev-main" and goal == "test":
        return "%s-API-Testcases" % module_name
    if env in ("dev-main", "dev-rel","stg2-main", "stg1-main", "stg-main","stg2-rel", "stg1-rel", "stg-rel"):
        return gen_job_name_nprod(module_name,lifecycle,goal,main_rel)
    if env in ("pre-prd1", "pre-prd2", "prd1", "prd2", "prd3") and goal == "deploy":
        return gen_deploy_job_name_prd(module_name,saas,env)

def gen_deploy_job_name_prd(module_name,saas,env):
    return "Deploy%s_%s-%s-CAE" % (saas, module_name, env.title()) #Deploy-SaaS_CCRCSaaSUI-Prd2-CAE | Deploy_CCRCAPI-Prd2-CAE | Deploy-SaaS_CCRCSaaSUI-Pre-Prd2-CAE

def gen_job_name_nprod(module_name,lifecycle,goal,main_rel):
    if goal in ('build','build_dependency'):
       if lifecycle == 'Stg' and main_rel == 'main':
            return "Promote_%s-MAIN" % module_name #Promote_CCRCAPI-MAIN 
       elif lifecycle == 'Dev':
            return "%s-%s" % (module_name, main_rel) #CCRCAPI-main | CCRCAPI-ps 
    elif (goal == 'deploy'): 
        if lifecycle == 'Stg' and main_rel == 'main':
            return "%s_CAE-main-Stg" % module_name #CCRCAPI_CAE-main-stg
        else: 
            return "%s-%s-%s-CAE" % (module_name, main_rel, lifecycle) #CCRCAPI-rel-Dev-CAE | CCRCAPI-rel-Stg-CAE | CCRCAPI-main-Dev-CAE

def get_server(server_name):
    token = conf.getJenkinsAPIToken(server_name)
    server = Jenkins('http://%s:8080' % server_name, username='jenkinsapi', password=token)
    return server


def create_job(server_name, job_name, job_xml):
    server = get_server(server_name)
    server.create_job(job_name, job_xml)


def update_job(server_name, job_name, job_xml):
    server = get_server(server_name)
    server.reconfig_job(job_name, job_xml)


def get_deploy_job_xml(module_name, env, job_type, data):
    job_xml = ""

    if job_type == "cae":
        if env in ("stg2-main", "stg2-rel", "stg1-main", "stg1-rel", "stg-rel", "stg-main"):
            job_xml = xml_api.get_stg_cae_deploy_job_xml(module_name, env, data)
        elif env in ("dev-rel", "dev-main"):
            job_xml = xml_api.get_dev_cae_deploy_job_xml(module_name, env, data)
        elif env in ("pre-prd1", "pre-prd2", "prd1", "prd2", "prd3"):
            job_xml = xml_api.get_prd_cae_deploy_job_xml(module_name, env, data)
    else:
        if env in("dev-main", "dev-rel"):
            job_xml = xml_api.get_dev_os_deploy_job_xml(module_name, env, data)
        elif env in ("stg1-main", "stg-rel", "stg1-rel"):
            job_xml = xml_api.get_stg_os_deploy_job_xml(module_name, env, data)
        elif env in ("pre-prd1", "pre-prd2", "prd1", "prd2"):
            job_xml = xml_api.get_prd_deploy_job_xml(module_name, env, data)

    return job_xml


def get_api_test_job_xml(module_name, env, data):
    return xml_api.get_api_tests_job_xml(module_name, env, data)


def get_build_dependency_job_xml(module_name, env, data):
    if data[module_name]['type'] == "ui":
        return xml_api.get_dev_build_dependency_ui_job_xml(module_name, env, data)
    else:
        return xml_api.get_dev_build_dependency_job_xml(module_name, env, data)


def get_build_job_xml(module_name, env, data):
    job_xml = ""

    if env in ("dev-main", "dev-rel"):
        job_xml = xml_api.get_dev_build_job_xml(module_name, env, data)
    elif env == "stg-main":
        job_xml = xml_api.get_stg_build_job_xml(module_name, data)
    return job_xml


def create_deploy_job(module_name, server_name, env, job_type, job_name, data):
    job_xml = get_deploy_job_xml(module_name, env, job_type, data)
    create_job(server_name, job_name, job_xml)


def update_deploy_job(module_name, server_name, env, job_type, job_name, data):
    job_xml = get_deploy_job_xml(module_name, env, job_type, data)
    update_job(server_name, job_name, job_xml)


def create_build_job(module_name, server_name, env, job_name, data):
    job_xml = get_build_job_xml(module_name, env, data)
    print(job_xml)
    create_job(server_name, job_name, job_xml)


def update_build_job(module_name, server_name, env, job_name, data):
    job_xml = get_build_job_xml(module_name, env, data)
    update_job(server_name, job_name, job_xml)


def create_build_dependency_job(module_name, server_name, env, job_name, data):
    job_xml = get_build_dependency_job_xml(module_name, env, data)
    create_job(server_name, job_name, job_xml)


def update_build_dependency_job(module_name, server_name, env, job_name, data):
    job_xml = get_build_dependency_job_xml(module_name, env, data)
    update_job(server_name, job_name, job_xml)


def create_api_test_job(module_name, server_name, env, job_name, data):
    job_xml = get_api_test_job_xml(module_name, env, data)
    create_job(server_name, job_name, job_xml)


def update_api_test_job(module_name, server_name, env, job_name, data):
    job_xml = get_api_test_job_xml(module_name, env, data)
    update_job(server_name, job_name, job_xml)


def delete_job(job_name, server_name):
    server = get_server(server_name)
    server.delete_job(job_name)
