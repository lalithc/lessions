import json
import Logger

from flask import Flask
from flask import request

import healthcheck
import db.data as db_api
import service
import mysql_service
import jenkins_service
import version_service
import puppet_api
import dockerfile_api
import cae_service

app = Flask(__name__)


@app.route('/ping')
def health_check():
    return 'SUCCESS'


@app.route('/modules', methods=['GET'])
def get_modules():
    module_name = request.args.get('module')
    ext = request.args.get('ext')
    module_type = request.args.get('type')
    env = request.args.get('env')
    host_name = request.args.get('host')
    heap_min = request.args.get('heap_min')
    heap_max = request.args.get('heap_max')
    project = request.args.get('project')
    automated = request.args.get('automated')
    pre_prd_enabled = request.args.get('pre_prd_enabled')
    bg_enabled = request.args.get('bg_enabled')
    cae_enabled = request.args.get('cae_enabled')
    lt_enabled = request.args.get('lt_enabled')

    try:
        data = db_api.get_modules(module_name, ext, module_type, host_name, env, heap_min, heap_max, project, automated,
                                  bg_enabled, pre_prd_enabled, cae_enabled, lt_enabled)
        return json.dumps(data)
    except Exception as e:
        Logger.exception(request.args)
        return json.dumps({"result": "Exception occurred during get_modules! (%s) " % e})


@app.route('/submodules', methods=['GET'])
def get_sub_modules():
    module_name = request.args.get('module')
    module_type = request.args.get('type')

    try:
        data = db_api.get_sub_modules(module_name, module_type)
        return json.dumps(data)
    except Exception as e:
        Logger.exception(request.args)
        return json.dumps({"result": "Exception occurred during get_sub_modules! (%s) " % e})


@app.route('/hosts', methods=['GET'])
def get_hosts():
    host_name = request.args.get('host')
    env = request.args.get('env')

    data = db_api.get_hosts(host_name, env)
    return json.dumps(data)


@app.route('/env/<env>', methods=['PUT'])
def update_env(env):
    input_json = request.get_json(force=True)
    try:
        return mysql_service.update_env(env, input_json)
    except Exception as e:
        Logger.exception(json.dumps(input_json))
        return json.dumps({"result": "Exception occurred during update_env! (%s) " % e})


@app.route('/envs', methods=['GET'])
def get_envs():
    env = request.args.get('env')
    try:
        return json.dumps(db_api.get_envs(env))
    except Exception as e:
        Logger.exception("Env: %s" % env)
        return json.dumps({"result": "Exception occurred during get_envs! (%s) " % e})


@app.route('/setup_submodule', methods=['POST'])
def setup_submodule():
    input_json = request.get_json(force=True)
    try:
        return json.dumps(service.setup_submodule(input_json))
    except Exception as e:
        Logger.exception(json.dumps(input_json))
        return json.dumps({"result": "Exception occurred during setup_submodule! (%s) " % e})


@app.route('/reconfigure_submodule', methods=['PUT'])
def reconfigure_submodule():
    input_json = request.get_json(force=True)
    try:
        return json.dumps(service.reconfigure_submodule(input_json))
    except Exception as e:
        Logger.exception(json.dumps(input_json))
        return json.dumps({"result": "Exception occurred during reconfigure_submodule! (%s) " % e})


@app.route('/setup_module', methods=['POST'])
def setup_module():
    input_json = request.get_json(force=True)
    try:
        return json.dumps(service.setup_module(input_json))
    except Exception as e:
        Logger.exception(json.dumps(input_json))
        return json.dumps({"result": "Exception occurred during setup_module! (%s) " % e})


@app.route('/reconfigure_module', methods=['PUT'])
def reconfigure_module():
    input_json = request.get_json(force=True)
    try:
        return json.dumps(service.reconfigure_module(input_json))
    except Exception as e:
        Logger.exception(json.dumps(input_json))
        return json.dumps({"result": "Exception occurred during reconfigure_module! (%s) " % e})


@app.route('/modules', methods=['POST'])
def create_module():
    input_json = request.get_json(force=True)
    try:
        return mysql_service.create_module(input_json)
    except Exception as e:
        Logger.exception(json.dumps(input_json))
        return "Exception occurred during create_module! (%s) " % e


@app.route('/module/<module_name>', methods=['PUT'])
def update_module(module_name):
    input_json = request.get_json(force=True)
    try:
        return mysql_service.update_module(module_name, input_json)
    except Exception as e:
        Logger.exception(json.dumps(input_json))
        return "Exception occurred during update_module! (%s) " % e


@app.route('/api_test/<module_name>', methods=['POST'])
def create_api_test(module_name):
    try:
        data = db_api.get_module(module_name)
        return mysql_service.create_ping_api_test(module_name, data)
    except Exception as e:
        Logger.exception(module_name)
        return "Exception occurred during create_api_test! (%s) " % e


@app.route('/module/update_version', methods=['PUT'])
def update_version():
    input_json = request.get_json(force=True)
    try:
        return mysql_service.update_version(input_json)
    except Exception as e:
        Logger.exception(json.dumps(input_json))
        return "Exception occurred during update_version! (%s) " % e


@app.route('/module/promote_version', methods=['PUT'])
def promote_version():
    input_json = request.get_json(force=True)
    try:
        return mysql_service.promote_version(input_json)
    except Exception as e:
        Logger.exception(json.dumps(input_json))
        return "Exception occurred during promote_version! (%s) " % e


@app.route('/module/versions', methods=['GET'])
def get_versions():
    module_name = request.args.get('module')
    env = request.args.get('env')

    try:
        return json.dumps(mysql_service.get_env_versions(module_name, env))
    except Exception as e:
        Logger.exception("Module name: %s, Env: %s" % (module_name, env))
        return "Exception occurred during get_versions! (%s) " % e


@app.route('/status', methods=['GET'])
def get_status():
    module_name = str(request.args.get('module'))
    env = str(request.args.get('env'))

    try:
        return json.dumps(service.get_status(module_name, env))
    except Exception as e:
        Logger.exception("Module name: %s, Env: %s" % (module_name, env))
        return "Exception occurred during get_status! (%s) " % e

@app.route('/cae/status', methods=['GET'])
def get_cae_status():
    module_name = str(request.args.get('module'))
    env = str(request.args.get('env'))
    try:
        return json.dumps(service.get_cae_status(module_name, env))
    except Exception as e:
        Logger.exception("Module name: %s, Env: %s" % (module_name, env))
        return "Exception occurred during get_cae_status! (%s) " % e
    
@app.route('/jenkins/create_api_test_job')
def create_api_test_job():
    module_name = str(request.args.get('module'))
    server_name = request.args.get('server')
    env = request.args.get('env')

    data = db_api.get_module(module_name)
    return jenkins_service.create_api_test_job(module_name, server_name, env, data)


@app.route('/jenkins/update_api_test_job')
def update_api_test_job():
    module_name = str(request.args.get('module'))
    server_name = request.args.get('server')
    env = request.args.get('env')

    data = db_api.get_module(module_name)
    return jenkins_service.update_api_test_job(module_name, server_name, env, data)


@app.route('/jenkins/create_submodule_job')
def create_submodule_job():
    module_name = str(request.args.get('module'))
    server_name = request.args.get('server')
    env = request.args.get('env')

    data = db_api.get_sub_module(module_name)
    return jenkins_service.create_sub_module_build_job(module_name, server_name, env, data)


@app.route('/jenkins/update_submodule_job')
def update_submodule_job():
    module_name = str(request.args.get('module'))
    server_name = request.args.get('server')
    env = request.args.get('env')

    data = db_api.get_sub_module(module_name)
    return jenkins_service.update_sub_module_build_job(module_name, server_name, env, data)


@app.route('/jenkins/create_deploy_job')
def create_deploy_job():
    module_name = str(request.args.get('module'))
    server_name = request.args.get('server')
    env = request.args.get('env')
    job_type = request.args.get('type', 'os')

    data = db_api.get_module(module_name)
    return jenkins_service.create_deploy_job(module_name, server_name, env, job_type, data)


@app.route('/jenkins/update_deploy_job')
def update_deploy_job():
    module_name = str(request.args.get('module'))
    server_name = request.args.get('server')
    env = request.args.get('env')
    job_type = request.args.get('type', 'os')

    data = db_api.get_module(module_name)
    return jenkins_service.update_deploy_job(module_name, server_name, env, job_type, data)


@app.route('/jenkins/create_build_job')
def create_build_job():
    module_name = str(request.args.get('module'))
    server_name = request.args.get('server')
    env = request.args.get('env')

    data = db_api.get_module(module_name)
    return jenkins_service.create_build_job(module_name, server_name, env, data)


@app.route('/jenkins/update_build_job')
def update_build_job():
    module_name = str(request.args.get('module'))
    server_name = request.args.get('server')
    env = request.args.get('env')

    data = db_api.get_module(module_name)
    return jenkins_service.update_build_job(module_name, server_name, env, data)


@app.route('/jenkins/delete_job')
def delete_job():
    module_name = str(request.args.get('module'))
    server_name = request.args.get('server')
    env = request.args.get('env')
    job_type = request.args.get('type')
    goal = request.args.get('goal')

    data = db_api.get_module(module_name)

    return jenkins_service.delete_job(module_name, server_name, env, goal, job_type, data)


@app.route('/cae/generate_all_resources', methods=['GET'])
def generate_cae_resources():
    env = str(request.args.get('env'))

    try:
        return cae_service.generate_resources(env)
    except Exception as e:
        Logger.exception("Error generating cae resources for %s envs!" % env)
        return "Exception occurred during generate_cae_resources! (%s) " % e


@app.route('/cae/generate_resource', methods=['GET'])
def generate_cae_resource():
    env = str(request.args.get('env'))
    module_name = str(request.args.get('module'))

    try:
        return cae_service.generate_resource(module_name, env)
    except Exception as e:
        Logger.exception("Error generating cae resources for module %s in %s envs!" % (module_name, env))
        return "Exception occurred during generate_cae_resource! (%s) " % e


@app.route('/cae/create_all_resources', methods=['GET'])
def create_cae_resources():
    main_rel = str(request.args.get('main_rel'))
    config_type = str(request.args.get('type'))
    input_json = request.get_json(force=True)
    env = input_json.get('env', None)

    try:
        return cae_service.create_resources(main_rel, config_type, env)
    except Exception as e:
        Logger.exception("Error creating cae resources for %s envs!" % env)
        return "Exception occurred during create_cae_resources! (%s) " % e


@app.route('/cae/create_resource', methods=['GET'])
def create_cae_resource():
    input_json = request.get_json(force=True)
    env = input_json.get('env', None)
    config_type = str(request.args.get('type'))
    module_name = str(request.args.get('module'))
    main_rel = str(request.args.get('main_rel'))

    try:
        return cae_service.create_resource(module_name, main_rel, config_type, env)
    except Exception as e:
        Logger.exception("Error generating cae resources for module %s in %s envs!" % (module_name, env))
        return "Exception occurred during create_cae_resource! (%s) " % e


@app.route('/nagio/healthcheck')
def get_healthcheck():
    module_name = request.args.get('module')
    env = request.args.get('env')
    
    result = healthcheck.cae_nagio_healthcheck(module_name, env)
    if result['status'] != "Success":
        return result['description']
    else:
        return "Success"
    
@app.route('/apps_healthcheck', methods=['GET'])
def apps_healthcheck():
    
    app_name = request.args.get('app')
    env = request.args.get('env')
   
    result = healthcheck.apps_healthcheck(app_name, env)
    if result['status'] != "Success":
        return result['description']
    else:
        return "Success"


@app.route('/healthcheck')
def cae_healthcheck():
    module_name = request.args.get('module')
    env = request.args.get('env')

    return json.dumps(healthcheck.cae_nagio_healthcheck(module_name, env))


@app.route('/status/healthcheck')
def status_healthcheck():
    module_name = request.args.get('module')
    env = request.args.get('env')

    return healthcheck.cae_nagio_healthcheck(module_name, env)


@app.route('/status/version', methods=['GET'])
def get_status_version():
    module_name = str(request.args.get('module'))
    env = str(request.args.get('env'))

    try:
        return json.dumps(version_service.get_host_versions(module_name, env))
    except Exception as e:
        Logger.exception("Module name: %s, Env: %s" % (module_name, env))
        return "Exception occurred during get_status_version! (%s) " % e


@app.route('/cae/update_replicas', methods=['PUT'])
def update_replicas():
    input_json = request.get_json(force=True)
    try:
        return mysql_service.update_replicas(input_json)
    except Exception as e:
        Logger.exception(json.dumps(input_json))
        return "Exception occurred during updating green blue replicas! (%s) " % e

@app.route('/cae/alldockerfilecreation')
def caealldockerfilecreation():
    
    print caealldockerfilecreation

    env = request.args.get('env')

    moduleInfo = db_api.get_automated_modules("ServiceContract")

    response = dockerfile_api.caedockerfilecreation(moduleInfo,env)

    return "Success"

@app.route('/cae/alldockerfilecreation/rel')
def caealldockerfilecreation_rel():

    env = request.args.get('env')

    moduleInfo = db_api.get_automated_modules(None)

    response = dockerfile_api.caedockerfilecreationall_rel(moduleInfo,env)

    return "Success"

@app.route('/cae/all/deleteroute')
def caealldeleteroute():
    
    print caealldockerfilecreation

    env = request.args.get('env')

    moduleInfo = db_api.get_automated_modules("ServiceContract")

    response = dockerfile_api.caedeleteroute(moduleInfo,env)

    return "Success"

@app.route('/cae/all/createservice/rel')
def caeallcreateservice_rel():
    print "Inside caeallcreateservice_rel"
    
    env = request.args.get('env')

    moduleInfo = db_api.get_automated_modules("ServiceContract")

    response = dockerfile_api.caecreateservice_rel(moduleInfo,env)

    return "Success"

@app.route('/cae/all/deleteroute/rel')
def caealldeleteroute_rel():
    
    print caealldockerfilecreation

    env = request.args.get('env')

    moduleInfo = db_api.get_automated_modules("ServiceContract")

    response = dockerfile_api.caedeleteroute_rel(moduleInfo,env)

    return "Success"

@app.route('/cae/dockerfilecreation')
def caedockerfilecreation():
    
    env = request.args.get('env')
    module_name = request.args.get('module_name')

    moduleInfo = db_api.get_module(module_name)
    response = dockerfile_api.caedockerfilecreationsingle(moduleInfo,env,module_name)

    return response


@app.route('/os/alldockerfilecreation')
def osalldockerfilecreation():

    env = request.args.get('env')

    moduleInfo = db_api.get_automated_modules(None)


    for module_name in moduleInfo:
        module =  moduleInfo[module_name]
        module_type = module['type']
        service_name = module['service_name']
        min_heap = module['heap_min']
        max_heap = module['heap_max'] 
        jmx_port = module['jmx_port'] 
        rmi_port = module['rmi_port']
        response = dockerfile_api.osdockerfilecreation(module_name, service_name, module_type, min_heap, max_heap, jmx_port,rmi_port, env)

    return "Success"

@app.route('/os/dockerfilecreation')
def osdockerfilecreation():
    
    env = request.args.get('env')
    module_name = request.args.get('module_name')

    moduleInfo = db_api.get_module(module_name)
    
    module =  moduleInfo[module_name]
    module_type = module['type']
    service_name = module['service_name']
    min_heap = module['heap_min']
    max_heap = module['heap_max'] 
    jmx_port = module['jmx_port'] 
    rmi_port = module['rmi_port'] 
    response = dockerfile_api.osdockerfilecreation(module_name, service_name, module_type, min_heap, max_heap, jmx_port,rmi_port, env)

    return response

@app.route('/os/alldockerfilecreation/release')
def osalldockerfilecreationrel():

    moduleInfo = db_api.get_automated_modules(None)
 
    response = dockerfile_api.osdockerfilecreation_rel_all(moduleInfo)
    
    return "Success"

@app.route('/os/dockerfilecreation/release')
def osdockerfilecreationrel():
    
    module_name = request.args.get('module_name')

    moduleInfo = db_api.get_module(module_name)
    
    response = dockerfile_api.osdockerfilecreation_rel_single(module_name,moduleInfo)

    return response


@app.route('/os/nodepuppetcreation')
def nodepuppetcreation():

    env = request.args.get('env')
    module_name = request.args.get('module_name')

    moduleInfo = db_api.get_module(module_name)
    module =  moduleInfo[module_name]
    module_type = module['type']
    service_name = module['service_name']
    min_heap = module['heap_min']
    max_heap = module['heap_max'] 
    jmx_port = module['jmx_port'] 
    rmi_port = module['rmi_port'] 
    container_cpu = module['container_cpu'] 
    container_mem = module['container_mem'] 
    http_port = module['http_port'] 
    response1 = puppet_api.ospuppetcreationnode(module_name, service_name, module_type, min_heap, max_heap, jmx_port,rmi_port, env,container_cpu,container_mem,http_port)
    return "Success"

@app.route('/os/javapuppetcreation')
def javauppetcreation():

    env = request.args.get('env')
    module_name = request.args.get('module_name')

    moduleInfo = db_api.get_module(module_name)
    module =  moduleInfo[module_name]
    module_type = module['type']
    service_name = module['service_name']
    min_heap = module['heap_min']
    max_heap = module['heap_max'] 
    jmx_port = module['jmx_port'] 
    rmi_port = module['rmi_port'] 
    container_cpu = module['container_cpu'] 
    container_mem = module['container_mem'] 
    http_port = module['http_port'] 
    response1 = puppet_api.ospuppetcreationjava(module_name, service_name, module_type, min_heap, max_heap, jmx_port,rmi_port, env,container_cpu,container_mem,http_port)
    return "Success"

@app.route('/os/allpuppetcreation/java')
def alluppetcreation():

    env = request.args.get('env')

    moduleInfo = db_api.get_automated_modules("ServiceContract")


    for module_name in moduleInfo:
        module =  moduleInfo[module_name]
        module_type = module['type']
        service_name = module['service_name']
        min_heap = module['heap_min']
        max_heap = module['heap_max'] 
        jmx_port = module['jmx_port'] 
        rmi_port = module['rmi_port'] 
        container_cpu = module['container_cpu'] 
        container_mem = module['container_mem'] 
        http_port = module['http_port'] 
        response1 = puppet_api.ospuppetcreationjava(module_name, service_name, module_type, min_heap, max_heap, jmx_port,rmi_port, env, container_cpu,container_mem,http_port)
    return "Success"

@app.route('/os/allpuppetcreation/node')
def alluppetcreationnode():

    env = request.args.get('env')

    moduleInfo = db_api.get_automated_modules("ServiceContract")


    for module_name in moduleInfo:
        module =  moduleInfo[module_name]
        module_type = module['type']
        service_name = module['service_name']
        min_heap = module['heap_min']
        max_heap = module['heap_max'] 
        jmx_port = module['jmx_port'] 
        rmi_port = module['rmi_port'] 
        container_cpu = module['container_cpu'] 
        container_mem = module['container_mem'] 
        http_port = module['http_port']
        response2 = puppet_api.ospuppetcreationnode(module_name, service_name, module_type, min_heap, max_heap, jmx_port,rmi_port, env,container_cpu,container_mem,http_port)
    return "Success"

@app.route('/os/allpuppetcreation/java/rel')
def alluppetcreationjavarel():

    moduleInfo = db_api.get_automated_modules(None)

    response = puppet_api.ospuppetcreationjava_rel_all(moduleInfo)
    return "Success"

@app.route('/os/allpuppetcreation/node/rel')
def alluppetcreationnoderel():

    moduleInfo = db_api.get_automated_modules(None)

    response = puppet_api.ospuppetcreationnode_rel_all(moduleInfo)
    return "Success"

@app.route('/os/puppetcreation/java/rel')
def puppetcreationjavarel():

    module_name = request.args.get('module_name')

    moduleInfo = db_api.get_module(module_name)
   
    response = puppet_api.ospuppetcreationjava_rel_single(module_name,moduleInfo)
    return "Success"

@app.route('/os/puppetcreation/node/rel')
def puppetcreationnoderel():

    module_name = request.args.get('module_name')

    moduleInfo = db_api.get_module(module_name)

    response = puppet_api.ospuppetcreationnode_rel_single(module_name,moduleInfo)
    return "Success"

@app.route('/module/promote_version_dc3', methods=['PUT'])
def promote_version_dc3():
    input_json = request.get_json(force=True)
    try:
        return mysql_service.promote_version_dc3(input_json)
    except Exception as e:
        Logger.exception(json.dumps(input_json))
        return "Exception occurred during promote_version! (%s) " % e
    
@app.route('/deployer', methods=['GET'])
def get_deployer_server():
    env = request.args.get('env')
    return cae_service.get_deployer(env)

@app.route('/config', methods=['GET'])
def get_config():
    key = request.args.get('key')
    env = request.args.get('env')
    return cae_service.get_config(key,env)

@app.route('/nonmicroservices', methods=['GET'])
def get_nonms():
    app = request.args.get('app')
    env = request.args.get('env')
    return mysql_service.get_nonms(app,env)
