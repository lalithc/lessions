import subprocess
import os
import re
import config as conf
import cae_service as cae_service

ROOT_PATH = os.path.abspath(os.path.dirname(__file__))


def get_api_tests_job_xml(module_name, env, data):
    edits = {}
    api_test_code = data[module_name]['api_test_code']
    rel_mgr_srvr = conf.DOCKER_SERVER_NPRD

    xml = "dev-main-api-test-job"
    params = (
                 "PROTOCOL=http\n"
                 "HOST=%s\n"
                 "PORT=8099\n"
                 "TEST_TYPE=%s\n"
                 "MODULE=%s\n"
                 "NGVS_URL=http://ccwr-sc-dev.cisco.com/ServiceContract-main/ngvsservice\n"
                 "ENV=DEV-MAIN\n"
                 "SERVICE_URL=http://ccwr-sc-dev.cisco.com/ServiceContract-main/qotservice\n"
                 "AUTH_USER_ID=vrachuri\n"
                 "AUTH_PWD=cisco123\n"
                 "OAUTH_FLG=Y") % (rel_mgr_srvr, api_test_code, module_name)

    edits[("/project/builders/hudson.plugins.parameterizedtrigger.TriggerBuilder/configs/"
           "hudson.plugins.parameterizedtrigger.BlockableBuildTriggerConfig/configs/"
           "hudson.plugins.parameterizedtrigger.PredefinedBuildParameters/properties")] = params

    ref_xml_path = ROOT_PATH + "/xml/%s.xml" % xml

    return run_edits(ref_xml_path, edits)


def get_dev_build_job_xml(module_name, env, data):
    edits = {}
    xml_base = "/maven2-moduleset"

    ext = data[module_name]['ext']
    git_repo = data[module_name]['git_repo']

    if env == "dev-main":
        xml = "dev-main-build-job"
        script = ("#!/bin/sh \n\n"
                  "git archive --remote=ssh://lchennup@gitscm.cisco.com/ccwren/ccrcscripts.git CCRCScripts_P3:jenkins/dev "
                  "build_dev.sh | tar xf - \n"
                  "./build_dev.sh %s dev-main %s ${Version} ${BUILD_NUMBER}" % (module_name, ext))
    else:
        xml = "dev-rel-build-job"
        script = ("#!/bin/sh \n\n"
                  "git archive --remote=ssh://lchennup@gitscm.cisco.com/ccwren/ccrcscripts.git CCRCScripts_P3:jenkins/dev "
                  "build_dev-rel.sh | tar xf - \n"
                  "./build_dev-rel.sh %s %s ${Version} ${BUILD_NUMBER}" % (module_name, ext))

    edits["%s/scm/userRemoteConfigs/hudson.plugins.git.UserRemoteConfig/url" % xml_base] = \
        "ssh://lchennup@gitscm.cisco.com/ccwren/%s.git" % git_repo
    edits["%s/rootModule/groupId" % xml_base] = module_name
    edits["%s/rootModule/artifactId" % xml_base] = module_name
    edits["%s/postbuilders/hudson.tasks.Shell/command" % xml_base] = script

    ref_xml_file = ROOT_PATH + "/xml/%s.xml" % xml

    return run_edits(ref_xml_file, edits)


def get_dev_build_dependency_job_xml(module_name, env, data):
    edits = {}
    xml_base = "/maven2-moduleset"
    git_repo = data[module_name]['git_repo']

    if env == "dev-main":
        xml = "dev-main-build-dep-job"
    else:
        xml = "dev-rel-build-dep-job"

    edits["%s/scm/userRemoteConfigs/hudson.plugins.git.UserRemoteConfig/url" % xml_base] = \
        "ssh://lchennup@gitscm.cisco.com/ccwren/%s.git" % git_repo
    edits["%s/rootModule/groupId" % xml_base] = module_name
    edits["%s/rootModule/artifactId" % xml_base] = module_name

    ref_xml_file = ROOT_PATH + "/xml/%s.xml" % xml

    return run_edits(ref_xml_file, edits)


def get_dev_build_dependency_ui_job_xml(module_name, env, data):
    edits = {}
    xml_base = "/maven2-moduleset"
    git_repo = data[module_name]['git_repo']

    main_ps = "rel"
    if env == "dev-main":
        main_ps = "main"

    xml = "dev-%s-build-dep-ui-job" % main_ps

    edits["%s/scm/userRemoteConfigs/hudson.plugins.git.UserRemoteConfig/url" % xml_base] = \
        "ssh://lchennup@gitscm.cisco.com/ccwren/%s.git" % git_repo
    edits["%s/rootModule/groupId" % xml_base] = module_name
    edits["%s/rootModule/artifactId" % xml_base] = module_name
    edits["%s/customWorkspace" % xml_base] = "/a/b/workspace/CCRCCommonUX-%s/%s" % (main_ps, module_name)

    ref_xml_file = ROOT_PATH + "/xml/%s.xml" % xml

    return run_edits(ref_xml_file, edits)


def get_stg_build_job_xml(module_name, data):
    if module_name == "CCRCCommonUX":
        return open(ROOT_PATH + "/xml/stg-main-build-ui-job.xml", 'r').read()
    else:
        edits = {}
        xml_base = "/project"

        git_repo = data[module_name]['git_repo']
        project = data[module_name]['project']
        testcase_job = "%s-API-Testcases" % module_name

        edits["%s/properties/hudson.plugins.buildblocker.BuildBlockerProperty/blockingJobs" % xml_base] = \
            "%s-main" % module_name
        edits["%s/scm/userRemoteConfigs/hudson.plugins.git.UserRemoteConfig/url" % xml_base] = \
            "ssh://lchennup@gitscm.cisco.com/ccwren/%s.git" % git_repo
        edits["%s/authToken" % xml_base] = str(module_name).lower()
        edits[("%s/builders/hudson.plugins.parameterizedtrigger.TriggerBuilder/configs/"
               "hudson.plugins.parameterizedtrigger.BlockableBuildTriggerConfig/projects" % xml_base)] = testcase_job
        edits["%s/builders/hudson.tasks.Shell/command" % xml_base] = \
            ("#!/bin/sh \n\n"
             "git archive --remote=ssh://lchennup@gitscm.cisco.com/ccwren/ccrcscripts.git CCRCScripts_P3:jenkins/stage "
             "build_stage.sh | tar xf - \n"
             "./build_stage.sh %s %s stg-main" % (module_name, project))

        ref_xml_file = ROOT_PATH + "/xml/stg-main-build-job.xml"

        return run_edits(ref_xml_file, edits)


def get_dev_os_deploy_job_xml(module_name, env, data):
    edits = {}
    xml_base = "/flow-definition/properties/hudson.model.ParametersDefinitionProperty/parameterDefinitions/" \
               "hudson.model.StringParameterDefinition "

    ext = data[module_name]['ext']
    main_rel = "main" if (env == "dev-main") else "rel"
    token = "%s-%s" % (str.lower(str(module_name)), main_rel)
    hosts = get_host_list_string(data[module_name]['envs'][env]['hosts'])

    edits["%s[name = \"MODULE\"]/defaultValue" % xml_base] = module_name
    edits["%s[name = \"EXT\"]/defaultValue" % xml_base] = ext
    edits["%s[name = \"HOSTS\"]/defaultValue" % xml_base] = hosts
    edits["/flow-definition/authToken"] = token

    ref_xml_file = ROOT_PATH + "/xml/dev-%s-deploy-job.xml" % main_rel

    return run_edits(ref_xml_file, edits)


def get_dev_cae_deploy_job_xml(module_name, env, data):
    edits = {}
    xml_base = "/flow-definition/properties/hudson.model.ParametersDefinitionProperty/parameterDefinitions/" \
               "hudson.model.StringParameterDefinition "

    ext = data[module_name]['ext']
    service_name = data[module_name]['service_name']
    main_rel = "main" if (env == "dev-main") else "rel"
    token = "%s-%s" % (str.lower(str(module_name)), main_rel)

    edits["%s[name = \"MODULE\"]/defaultValue" % xml_base] = module_name
    edits["%s[name = \"EXT\"]/defaultValue" % xml_base] = ext
    edits["%s[name = \"SERVICENAME\"]/defaultValue" % xml_base] = service_name
    edits["/flow-definition/authToken"] = token

    ref_xml_file = ROOT_PATH + "/xml/dev-%s-cae-job.xml" % main_rel

    return run_edits(ref_xml_file, edits)


def get_stg_os_deploy_job_xml(module_name, env, data):
    edits = {}
    xml_base = "/flow-definition/properties/hudson.model.ParametersDefinitionProperty/parameterDefinitions/" \
               "hudson.model.StringParameterDefinition "

    if env in ("stg-rel", "stg1-rel"):
        main_rel = "ps"
        envs = data[module_name]['envs']
        hosts = get_host_list_string(envs['stg1-rel']['hosts'])
    else:
        main_rel = "main"
        hosts = get_host_list_string(data[module_name]['envs']['stg1-main']['hosts'])

    token = "%sdeploy" % str.lower(str(module_name))

    edits["%s[name = \"MODULE\"]/defaultValue" % xml_base] = module_name
    edits["%s[name = \"HOSTS\"]/defaultValue" % xml_base] = hosts
    edits["/flow-definition/authToken"] = token

    ref_xml_file = ROOT_PATH + "/xml/stg-%s-deploy-job.xml" % main_rel

    return run_edits(ref_xml_file, edits)


def get_stg_cae_deploy_job_xml(module_name, env, data):
    edits = {}
    xml_base = "/flow-definition/properties/hudson.model.ParametersDefinitionProperty/parameterDefinitions/" \
               "hudson.model.StringParameterDefinition "

    ext = data[module_name]['ext']
    service_name = data[module_name]['service_name']

    if env in ("stg-rel", "stg1-rel", "stg2-rel"):
        main_rel = "ps"
    else:
        edits["%s[name = \"EXT\"]/defaultValue" % xml_base] = ext
        main_rel = "main"

    token = "%s-cae" % str.lower(str(module_name))

    edits["%s[name = \"MODULE\"]/defaultValue" % xml_base] = module_name
    edits["%s[name = \"SERVICENAME\"]/defaultValue" % xml_base] = service_name
    edits["/flow-definition/authToken"] = token

    ref_xml_file = ROOT_PATH + "/xml/stg-%s-cae-job.xml" % main_rel

    return run_edits(ref_xml_file, edits)


def get_prd_cae_deploy_job_xml(module_name, env, data):
    edits = {}
    xml_base = "/flow-definition/properties/hudson.model.ParametersDefinitionProperty/parameterDefinitions/" \
               "hudson.model.StringParameterDefinition "

    service_name = data[module_name]['service_name']

    if re.match(r'pre-prd\d', env):
        preprd_prd = "preprd"
    else:
        preprd_prd = "prd"

    edits["%s[name = \"MODULE\"]/defaultValue" % xml_base] = module_name
    edits["%s[name = \"SERVICENAME\"]/defaultValue" % xml_base] = service_name
    edits["%s[name = \"ENV\"]/defaultValue" % xml_base] = env
    edits["%s[name = \"NODE\"]/defaultValue" % xml_base] = get_cae_deploy_node(env)

    ref_xml_file = ROOT_PATH + "/xml/%s-cae-job.xml" % preprd_prd

    return run_edits(ref_xml_file, edits)


def get_prd_deploy_job_xml(module_name, env, data):
    edits = {}
    xml_base = "/flow-definition/properties/hudson.model.ParametersDefinitionProperty/parameterDefinitions/" \
               "hudson.model.StringParameterDefinition "

    if re.match(r'pre-prd\d', env):
        preprd_prd = "preprd"
    else:
        preprd_prd = "prd"
        edits["%s[name = \"TYPE\"]/defaultValue" % xml_base] = data[module_name]['type']

    hosts = get_host_list_string(data[module_name]['envs'][env]['hosts'])

    edits["%s[name = \"MODULE\"]/defaultValue" % xml_base] = module_name
    edits["%s[name = \"HOSTS\"]/defaultValue" % xml_base] = hosts

    ref_xml_file = ROOT_PATH + "/xml/%s-deploy-job.xml" % preprd_prd

    return run_edits(ref_xml_file, edits)


def run_edits(xml_file, edits):
    edit = None
    final_xml = None
    num_edits = len(edits)
    i = 1

    for path, value in edits.items():
        if i == num_edits:
            final_xml = edit_xml(path, value, xml_file, edit, final_edit=True)
        else:
            edit = edit_xml(path, value, xml_file, edit, final_edit=False)
            i = i + 1

    return final_xml


def edit_xml(path, value, xml_file, previous_result, final_edit):
    if previous_result is not None:
        stdin_pipe = previous_result.stdout
        cmd_args = ('xmlstarlet', 'ed', '-u', path, '-v', value)
    else:
        stdin_pipe = None
        cmd_args = ('xmlstarlet', 'ed', '-u', path, '-v', value, xml_file)

    if final_edit:
        return subprocess.check_output(cmd_args, stdin=stdin_pipe)
    else:
        return subprocess.Popen(cmd_args, stdin=stdin_pipe, stdout=subprocess.PIPE)


def get_host_list_string(hosts):
    return ",".join(hosts)


def get_cae_deploy_node(env):
    return cae_service.get_deployer(env)