from pexpect import pxssh

import db.data as db_api
import re
import json
import requests
import Logger
import config as conf


blue = "blue"
green = "green"
cyan = "cyan"


def scp_generated_resources(main_rel, module_name=None):
    s = get_ssh_session(get_server(main_rel))

    module_path = ""
    target_path = ""
    if module_name is not None:
        module_path = "/%s-%s" % (module_name, main_rel)
        target_path = "ccrckubernetes_generated/"

    servers = [conf.DEPLOYER_NPRD_RTP]
    if(main_rel == "rel"):
        #servers = servers + [conf.DEPLOYER_PRD_RCDN, conf.DEPLOYER_PRD_ALLN, conf.DEPLOYER_PRD_RTP]
        servers = servers + [conf.DEPLOYER_PRD_ALLN, conf.DEPLOYER_PRD_RTP]
        
    for server in servers:
        cmd = "rsync -a --sparse /apps/ccrckubernetes_generated%s root@%s:/apps/%s" % (module_path, server, target_path)
        s.sendline(cmd)
    close_ssh(s)


def generate_resources(modules, main_rel):
    envs = db_api.get_cae_envs(main_rel)
    for module_name in modules:
        generate_resource(module_name, modules[module_name], main_rel, envs)

    return "CAE Resources for %s envs were successfully generated!" % main_rel


def generate_resource(module_name, data, rel_type, envs=None):
    if envs is None:
        envs = db_api.get_cae_envs(rel_type)

    module_type = data['type']
    service_name = data['service_name']
    project = data['project']
    min_heap = data['heap_min']
    max_heap = data['heap_max']
    bg_enabled = data['bg_enabled']

    generic_path = get_generic_path(module_type, rel_type)
    generated_path = get_generated_path(module_name, rel_type)

    s = get_ssh_session(get_server(rel_type))
    s.sendline(clear_dir(generated_path))
    for cmd in cp_configs(module_type, module_name, generic_path, generated_path):
        s.sendline(cmd)

    source_path = get_service_file_path(generic_path)
    if bg_enabled == 'Y':
        
        blue_target_path = get_service_file_path(generated_path, blue)
        green_target_path = get_service_file_path(generated_path, green)
        # Service is same for all envs
        s.sendline(edit_service(service_name, source_path, blue_target_path, blue))
        s.sendline(edit_service(service_name, source_path, green_target_path, green))
    else:
        target_path = get_service_file_path(generated_path)
        s.sendline(edit_service(service_name, source_path, target_path, cyan))

    # Pre-start config is same for all envs
    s.sendline(edit_pre_start_config(min_heap, max_heap, service_name, generic_path, generated_path))

    if module_name in ('CCRCCommonUX','CCRCSaaSUI','CCRCCommonUXLanding','CCRCSaaSUILanding','Opportunity','swsspa'):
        # Edit Dockerfile
        s.sendline(edit_variables(project, module_name, 'Dockerfile', generic_path, generated_path))

        # Edit env.sh
        s.sendline(edit_variables(project, module_name, 'env.sh',  generic_path, generated_path))


    for env in envs:
        # Deployment config files are generated for each env
        source_path = get_deployment_file_path(env, generic_path)
        if bg_enabled == 'Y':
            blue_target_path = get_deployment_file_path(env, generated_path, blue)
            hotfix_target_path = get_deployment_file_path(env, generated_path)

            # Blue deployment config
            s.sendline(edit_deploy_config(data, rel_type, env, source_path, blue_target_path, blue))
            
            if(is_prd(env)):
                green_target_path = get_deployment_file_path(env, generated_path, green)
                # Green deployment config
                s.sendline(edit_deploy_config(data, rel_type, env, source_path, green_target_path, green))
                
            # Hotfix deployment config
            s.sendline(edit_deploy_config(data, rel_type, env, source_path, hotfix_target_path))
        else:
            target_path = get_deployment_file_path(env, generated_path)
            s.sendline(edit_deploy_config(data, rel_type, env, source_path, target_path, cyan))

        print("Module %s deployment configs generated for %s env!" % (module_name, env))

    close_ssh(s)
    return "Resources for module %s have been generated for %s envs" % (module_name, rel_type)


def create_resources(modules, rel_type, config_type, envs=None):
    if envs is None:
        envs = db_api.get_cae_envs(rel_type)
    for module_name in modules:
        create_resource(module_name, modules[module_name], config_type, rel_type, envs)

    return "Resources for %s envs were successfully created!" % rel_type


def create_resource(module_name, data, config_type, rel_type, envs=None):
    if envs is None:
        envs = db_api.get_cae_envs(rel_type)

    bg_enabled = data['bg_enabled']
    blue_config = None
    green_config = None
    config = None

    generated_path = get_generated_path(module_name, rel_type)

    for env in envs:
        print("establishing conn for env %s" % env)
        s = get_ssh_session(get_server(env))
        project_name = get_project(env)

        if config_type == 'service':
            if bg_enabled == 'Y':
                blue_config = get_service_file_path(generated_path, blue)
                if(is_prd(env)):
                    green_config = get_service_file_path(generated_path, green)
            else:
                config = get_service_file_path(generated_path)
        elif config_type == 'deploy':
            if bg_enabled == 'Y':
                blue_config = get_deployment_file_path(env, generated_path, blue)
                green_config = get_deployment_file_path(env, generated_path, green)
            else:
                config = get_deployment_file_path(env, generated_path)
        else:
            raise Exception("Config type %s not supported!" % config_type)

        if blue_config is not None:
            oc_create(s, blue_config, project_name)

        if green_config is not None:
            oc_create(s, green_config, project_name)

        if config is not None:
            oc_create(s, config, project_name)

        print("%s resource created for %s env for module %s" % (config_type, env, module_name))
        close_ssh(s)

    return "%s resources for %s envs were successfully created for module %s!" % (config_type, rel_type, module_name)


def oc_create(session, config, project):
    cmd = 'oc create -f %s -n %s' % (config, project)
    session.sendline(cmd)


def edit_pre_start_config(min_heap, max_heap, service_name, source_path, target_path):
    fields = ['minheap', 'maxheap', 'appsrvname']
    values = ['%sM' % min_heap, '%sM' % max_heap, service_name]
    source_file = '%s/pre_start_config' % source_path
    target_file = '%s/pre_start_config' % target_path

    return generate_sed(fields, values, source_file, target_file)


def edit_service(service_name, source_path, target_path, blue_green=None):
    fields = ['servicename']
    values = [get_service_name(service_name, blue_green)]

    return generate_sed(fields, values, source_path, target_path)


def edit_variables(project, service_name, file_name, source_path, target_path):
    fields = ['modulename', 'projectname','servicename']
    values = [service_name, project,service_name.lower()]
    source_file = '%s/%s' % (source_path, file_name)
    target_file = '%s/%s' % (target_path, file_name)

    return generate_sed(fields, values, source_file, target_file)


def edit_deploy_config(data, rel_type, env, source_path, target_path, blue_green=None):
    bg_service_name = get_service_name(data['service_name'], blue_green)
    service_name = data['service_name']
    project = data['project']

    fields = ['cservicename', 'bgservicename', 'reltype', 'containermem', 'containercpu', 'pingurl',
              'ciscolife', 'ccrchost', 'ccrcrabbithostkey', 'requestcpu', 'requestmem']
    values = [service_name, bg_service_name, rel_type, data['container_mem'], data['container_cpu'],
              get_ping_url(data, rel_type), get_pre_start_env(env), get_ccrc_host(env, project, blue_green),
              get_rabbithost_key(blue_green), data['request_cpu'], data['request_mem']]

    return generate_sed(fields, values, source_path, target_path)


def cp_configs(module_type, module_name, generic_path, generated_path):
    cmds = []
    if module_name == 'EDWReports':
        cmds.append('cp -f %s/EDWReports/Dockerfile %s/Dockerfile' % (generic_path, generated_path))
        cmds.append('mkdir -p %s/trust' % generated_path)
        cmds.append('cp -Rf %s/EDWReports/trust/* %s/trust/.' % (generic_path, generated_path))
    elif module_name == 'CCRCB2B':
        cmds.append('cp -f %s/CCRCB2B/Dockerfile %s/Dockerfile' % (generic_path, generated_path))
        cmds.append('mkdir -p %s/trust' % generated_path)
        cmds.append('cp -Rf %s/CCRCB2B/trust/* %s/trust/.' % (generic_path, generated_path))
    elif module_name == 'CCRCSaaSService':
        cmds.append('cp -f %s/CCRCSaaSService/Dockerfile %s/Dockerfile' % (generic_path, generated_path))
        cmds.append('mkdir -p %s/certs' % generated_path)
        cmds.append('cp -Rf %s/CCRCSaaSService/certs/* %s/certs/.' % (generic_path, generated_path))
    elif module_name in ('CCRCCommonUX','CCRCSaaSUI','CCRCCommonUXLanding','CCRCSaaSUILanding','Opportunity','swsspa'):
        cmds.append('mkdir -p %s/configs' % generated_path)
        cmds.append('cp -Rf %s/%s/configs/* %s/configs/.' % (generic_path, module_name, generated_path))
    elif module_name == 'CCRCDownloadNginx':
        cmds.append('cp -f %s/%s/Dockerfile %s/Dockerfile' % (generic_path, module_name, generated_path))
        cmds.append('mkdir -p %s/configs' % generated_path)
        cmds.append('cp -Rf %s/%s/configs/* %s/configs/.' % (generic_path, module_name, generated_path))
    elif module_name == 'CCRCDashboard':
        cmds.append('cp -f %s/CCRCDashboard/Dockerfile %s/Dockerfile' % (generic_path, generated_path))
    elif module_name in ['CCRCCopyQuote' , 'CCRCSelectAll', 'CCRCUpload' , 'CCRCQuotingAsync','CCRCDownload', 'CCRCLocalz', 'CCRCB2BPunchout', 'CCRCBrandProtection','CCRCActivityLog','CCRCQuoteSummary']:
        cmds.append('cp -f %s/NodeEight/Dockerfile %s/Dockerfile' % (generic_path, generated_path))
    else:
        cmds.append('cp -f %s/Dockerfile %s/Dockerfile' % (generic_path, generated_path))

    if module_type == 'golang':
        cmds.append('/usr/bin/find %s -name "Dockerfile" -exec sed -i "s/cservicename/%s/g" {} \;' % (
        generated_path, module_name.lower()))

    cmds.append('cp -Rf %s/configs/* %s/configs/.' % (generic_path, generated_path))
    return cmds


def clear_dir(generated_path):
    return 'mkdir -p %s && rm -rf %s/* && mkdir -p %s/configs' % (generated_path, generated_path, generated_path)


def generate_sed(fields, values, source_file, target_file):
    if len(fields) != len(values):
        raise Exception("Fields must match values!")

    sed_command = "sed "
    for i in range(len(fields)):
        field = fields[i]
        value = values[i]

        sed_command = '%s -e "s/%s/%s/g"' % (sed_command, field, str.replace(str(value), '/', '\/'))

    sed_command = "%s %s >> %s" % (sed_command, source_file, target_file)
    return sed_command


def get_ping_url(data, rel_type):
    if rel_type == "rel":
        return data['ping_url'].replace("-main", "")
    else:
        return data['ping_url']


def get_project(env):
    project = ""
    project = conf.getNamespace(env)
    return project


def get_rel_type(env):
    main_ps = "rel"
    if "main" in env:
        main_ps = "main"

    return main_ps


def get_generated_path(module_name, rel_type):
    return "%s_generated/%s-%s" % (get_base_path(), module_name, rel_type)


def get_generic_path(module_type, rel_type):
    base_dir = "%s/%s" % (get_base_path(), rel_type)

    if module_type == 'tomcat':
        return "%s/tomcatmodule-cae" % base_dir
    if module_type == 'springboot':
        return "%s/sbootmodule-cae" % base_dir
    if module_type == 'nodejs':
        return "%s/nodemodule-cae" % base_dir
    if module_type == 'nginx':
        return "%s/nginxmodule-cae" % base_dir
    if module_type == 'golang':
        return "%s/golangmodule-cae" % base_dir


def get_cae_env(env):
    return str.replace(env, "-", "")


def get_service_name(service_name, blue_green=None):
    if blue_green is None:
        return "servicename"
    elif blue_green == cyan:
        return service_name
    else:
        return "%s%s" % (blue_green[0], service_name)


def get_ccrc_host(env, project, blue_green):
    normalized_env = normalize_env(env)
    url_env = get_cae_env(normalized_env)

    if blue_green is None:
        return 'ccrchost'
    elif blue_green == cyan:
        if normalized_env in ('lt-main', 'stg-main', 'stg-rel', 'dev-main', 'dev-rel'):
            return 'localhaproxy'
        elif normalized_env in ('pre-prd', 'prd'):
            return 'prodhaproxy'
    else:
        if normalized_env in ('dev-main', 'lt-main', 'stg-main', 'stg-rel', 'dev-rel'):
          		return "localhaproxy"
        elif normalized_env in ('pre-prd', 'prd'):
                return "%slocalhaproxy" % (blue_green[0])


def normalize_env(env):
    return re.sub(r'\d+', '', env)

def is_prd(env):
    return 'prd' in env


def get_pre_start_env(env):
    return env


def get_service_file_path(path, blue_green=None):
    bg_string = "" if blue_green is None else "-%s" % blue_green
    return "%s/service%s.yaml" % (path, bg_string)


def get_deployment_file_path(env, path, blue_green=None):
    bg_string = "" if blue_green is None else "-%s" % blue_green
    return '%s/deployconfig-template-%s%s.yaml' % (path, get_cae_env(env), bg_string)


def get_rabbithost_key(blue_green):
    if blue_green is None:
        return "ccrcrabbithostkey"
    elif blue_green == blue:
        return "ccrc.bluerabbitmqhost"
    elif blue_green == green:
        return "ccrc.greenrabbitmqhost"
    elif blue_green == cyan:
         return "ccrcrabbithostkey" #we don't have cyan consumers/producers so returning same string only
    else:
        raise Exception ('No rabbit key configured for %s replica' %blue_green)


def get_base_path():
    return "/apps/ccrckubernetes"


def get_server(env):
    if env in ("main","rel"):
        return conf.getDockerServer(env)
    elif env in ('dev-main', 'dev-rel', 'lt-main', 'stg2-main', 'stg1-main', 'stg2-rel', 'stg1-rel', 'pre-prd1', 'prd1', 'pre-prd2', 'prd2', 'prd3'):
        dc=conf.getEnvCluster(env)
        return conf.getDeployer(dc)
    else:
        raise Exception('%s envs not supported for ssh login!' % env)

def get_deployer_server(env):
    dc = conf.getEnvCluster(env)
    deployer = conf.getDeployer(dc)
    node = conf.getAgentNode(deployer)
    if node is None:
        raise Exception('%s No deployer configured!' % env)
    return node


def get_ssh_session(server):
    s = pxssh.pxssh()
    if not s.login(server, 'root', 'cisco999'):
        # Retry
        if not s.login(server, 'root', 'cisco999'):
            raise Exception('SSH session failed on login: %s' % str(s))

    return s


def close_ssh(ssh_session):
    try:
        ssh_session.prompt()
        ssh_session.logout()
    except Exception:
        Logger.exception("Exception during ssh logout!")


def get_cae_module_version(module_name, env):  
    env_info = db_api.get_envs(env)
    blue_green = env_info[env]['blue_green']
    
    moduleInfo = db_api.get_modules(module_name, None, None, None, env, None, None, None, None, None, None,None, None)
    module = moduleInfo[module_name]
    service_name = module['service_name']
    
    project_name = getNamespace(env)
    datacenter = getDatacenter(env)
    token = getToken(env)
    
    blue_url = get_deploy_configs_url(datacenter, project_name, service_name, bgflag='b')
    green_url = get_deploy_configs_url(datacenter, project_name, service_name, bgflag='g')
    cyan_url = get_deploy_configs_url(datacenter, project_name, service_name, bgflag='')
     
    headers = {'Authorization': 'Bearer ' + token}
    
    if blue_green == blue:
        actual_version = get_actual_version(blue_url, headers)
    elif blue_green == green:
        actual_version = get_actual_version(green_url, headers)
    else:
        actual_version = get_actual_version(cyan_url, headers)
        
    return actual_version


def get_actual_replicas(url, headers):
    response = requests.get(url, headers=headers, verify=False)
    json_data = json.loads(response.text)
    addresses = None if 'subsets' not in json_data or json_data['subsets'] == [] \
        else json_data['subsets'][0]['addresses']
    return 0 if addresses is None else len(addresses)


def get_actual_version (url, headers):
    response = requests.get(url, headers=headers, verify=False)
    json_data = json.loads(response.text)
    image_name = None 
    
    #TODO : Work on response JSON's validation
    if 'spec' not in json_data or json_data['spec'] == []:
        raise Exception ('Exception getting actual version: BAD JSON response')
    else:
       if json_data['spec']['template']['spec']['containers'][0] == []:
        raise Exception ('Exception getting actual version: BAD JSON response') 
       else :
        image_name = json_data['spec']['template']['spec']['containers'][0]['image']
        
    if image_name is None:
       raise Exception ('Exception getting actual version, possible reason may be : PODs not running')
    else:
        splitted_image_name = image_name.split(':')
        actual_version = splitted_image_name [1]
    
    return actual_version


def get_endpoint_url(datacenter, project_name, service_name, bgflag):
    return 'https://%s:443/api/v1/namespaces/%s/endpoints/%s%s' % (datacenter, project_name, bgflag, service_name)


def get_deploy_configs_url(datacenter, project_name, service_name, bgflag):
    return 'https://%s:443/oapi/v1/namespaces/%s/deploymentconfigs/%s%s' % (datacenter, project_name, bgflag, service_name)


def getNamespace(env):
    ns = ""
    ns = conf.getNamespace(env)
    return ns


def getDatacenter(env):
    dc = conf.getEnvCluster(env)
    return dc


def getToken(env):
    token = ""
    token = conf.CONFIG['token'][env]       
    return token

def getConfig(key,env):
    result=conf.CONFIG[key]
    for k,v in result.items():
        if k == env:
            return v
