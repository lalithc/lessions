import json
import os

configFile='config.json'
with open(os.path.abspath(os.path.join(os.path.dirname( __file__ ),configFile)), 'r') as f:
    config = json.load(f)

BUILD_SERVER = config['build_server']
DOCKER_SERVER_NPRD = config['docker_server']['nprd']
DOCKER_SERVER_PRD = config['docker_server']['prd']
DEPLOYER_NPRD_RTP=config['deployer']['cae-np-rtp']
DEPLOYER_NPRD_ALLN=config['deployer']['cae-np-alln']
DEPLOYER_NPRD_RCDN=config['deployer']['cae-np-rcdn']
DEPLOYER_PRD_RTP=config['deployer']['cae-prd-rtp']
DEPLOYER_PRD_ALLN=config['deployer']['cae-prd-alln']
DEPLOYER_PRD_RCDN=config['deployer']['cae-prd-rcdn']

CONFIG = config


def getNamespace(env):
    return config['namespace'][env]


def getAgentNode(deployer):
    return config['agentNode'][deployer]


def getEnvCluster(env):
    return config['envCluster'][env]


def getDeployer(dc):
    return config['deployer'][dc]

def getDockerServer(env):
    if env == 'main':
        return config['docker_server']['nprd']
    else:
        return config['docker_server']['prd']
def getJenkinsAPIToken(srvr):
    return config['jenkinsapitoken'][srvr]
