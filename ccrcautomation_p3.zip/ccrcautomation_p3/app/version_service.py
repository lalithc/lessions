import Logger
import validation
import mysql_service


def get_host_versions(module_name, env):
    msg = validation.validate_status(module_name, env)

    if msg is not None:
        Logger.info(msg)
        return msg

    return mysql_service.get_host_versions(module_name, env)
