import Logger

import validation
import mysql_service
import jenkins_service
import healthcheck
import dockerfile_service
import puppet_service
import db.data as db_api
import cae_service
import config as conf


def setup_submodule(input_json):
    module_name = input_json.get('module', None)
    build_server = input_json.get('build_server', conf.BUILD_SERVER)
    migrate = input_json.get('migrate')
    main_rel = input_json.get('main_rel')
    rel=True
    main=True
    
    results = {}
    returnObj = {}

    # Mysql
    if (migrate is None or migrate == 'No'):
        results = {'mysql': mysql_service.create_submodule(input_json)}
    data = db_api.get_sub_module(module_name)
    
    if(main_rel):
        if (main_rel not in ('rel','main')):
            return 'Incorrect Value for env! choose between rel|main|null'
        rel = main_rel == 'rel'
        main = main_rel == 'main'

    results['jenkins_build_submodule_job-dev-main'] = jenkins_service.create_sub_module_build_job(module_name, build_server, "dev-main", data)
    if(rel):
        results['jenkins_build_submodule_job-dev-rel'] = jenkins_service.create_sub_module_build_job(module_name, build_server, "dev-rel", data)

    returnObj[module_name] = results
    return returnObj


def reconfigure_submodule(input_json):
    module_name = input_json.get('module', None)
    build_server = input_json.get('build_server', conf.BUILD_SERVER)

    returnObj = {}

    # Mysql
    results = {'mysql': mysql_service.update_submodule(input_json)}
    data = db_api.get_sub_module(module_name)

    results['jenkins_build_submodule_job-dev-main'] = jenkins_service.update_sub_module_build_job(module_name, build_server, "dev-main", data)
    results['jenkins_build_submodule_job-dev-rel'] = jenkins_service.update_sub_module_build_job(module_name, build_server, "dev-rel", data)

    returnObj[module_name] = results
    return returnObj


def setup_module(input_json):
    module_name = input_json.get('module', None)
    deploy_server = input_json.get('deploy_server', conf.DOCKER_SERVER_NPRD)
    build_server = input_json.get('build_server', conf.BUILD_SERVER)
    migrate = input_json.get('migrate')
    env = input_json.get('env', None)
    main_rel = input_json.get('main_rel')
    prd_deploy_server = conf.DOCKER_SERVER_PRD

    returnObj = {}
    results = {}
    rel=True
    main=True

    # Mysql
    if (migrate is None or migrate == 'No'):
        results = {'mysql': mysql_service.create_module(input_json)}
    data = db_api.get_module(module_name)
    
    if(main_rel):
        if (main_rel not in ('rel','main')):
            return 'Incorrect Value for env! choose between rel|main|null'
        rel = main_rel == 'rel'
        main = main_rel == 'main'
    
    # Dockerfile + kube configs
    if(main):
        results['cae_generate_config_main'] = cae_service.generate_resource(module_name, 'main')
        results['cae_cp_resources_main'] = cae_service.cp_resources(module_name, 'main')
        results['cae_create_resource_main'] = cae_service.create_resource(module_name, 'main', 'service', env)
     
    if(rel):
       results['cae_generate_config_rel'] = cae_service.generate_resource(module_name, 'rel') 
       results['cae_cp_resources_rel'] = cae_service.cp_resources(module_name, 'rel')
       results['cae_create_resource_rel'] = cae_service.create_resource(module_name, 'rel', 'service', env)
  
    #Jenkins
    if(main):
         # API Test cases
        results['mysql_api_test_cases'] = mysql_service.create_ping_api_test(module_name, data)
        results['jenkins_api_test_cases_job'] = jenkins_service.create_api_test_job(module_name, build_server, 'dev-main', data)
  
        # Build jobs
        results['jenkins_build_job-stg-main'] = jenkins_service.create_build_job(module_name, build_server, 'stg-main', data)
        results['jenkins_build_job-dev-main'] = jenkins_service.create_build_job(module_name, build_server, 'dev-main', data)
        
        # Deployment jobs
        results['jenkins_deploy_job-dev-main-cae'] = jenkins_service.create_deploy_job(module_name, deploy_server, 'dev-main', 'cae', data)
        results['jenkins_deploy_job-stg-main'] = jenkins_service.create_deploy_job(module_name, deploy_server, 'stg-main', 'cae', data)
     
    if(rel):
        #build-job
        results['jenkins_build_job-dev-rel'] = jenkins_service.create_build_job(module_name, build_server, 'dev-rel', data)
         
        #deploy-jobs
        results['jenkins_deploy_job-dev-rel-cae'] = jenkins_service.create_deploy_job(module_name, prd_deploy_server, 'dev-rel', 'cae', data)
        results['jenkins_deploy_job-stg-rel'] = jenkins_service.create_deploy_job(module_name, prd_deploy_server, 'stg-rel', 'cae', data)
        results['jenkins_deploy_job-pre-prd1-cae'] = jenkins_service.create_deploy_job(module_name, prd_deploy_server, 'pre-prd1', 'cae', data)
        results['jenkins_deploy_job-pre-prd2-cae'] = jenkins_service.create_deploy_job(module_name, prd_deploy_server, 'pre-prd2', 'cae', data)
        results['jenkins_deploy_job-prd1-cae'] = jenkins_service.create_deploy_job(module_name, prd_deploy_server, 'prd1', 'cae', data)
        results['jenkins_deploy_job-prd2-cae'] = jenkins_service.create_deploy_job(module_name, prd_deploy_server, 'prd2', 'cae', data)
        results['jenkins_deploy_job-prd3-cae'] = jenkins_service.create_deploy_job(module_name, prd_deploy_server, 'prd3', 'cae', data)

    returnObj[module_name] = results
    return returnObj


def reconfigure_module(input_json):
    module_name = input_json.get('module', None)
    ext = input_json.get('ext', None)
    module_type = input_json.get('type', None)
    service_name = input_json.get('service_name', None)
    deploy_server = input_json.get('deploy_server', conf.DOCKER_SERVER_NPRD)
    build_server = input_json.get('build_server', conf.BUILD_SERVER)
    jmx_port = input_json.get('jmx_port')
    project = input_json.get('project')
    env = input_json.get('env', 'all')

    prd_deploy_server = conf.DOCKER_SERVER_PRD

    msg = validation.validate_module("PUT", module_name, ext, module_type, service_name, jmx_port, project)
    if msg is not None:
        Logger.info(msg)
        return msg

    returnObj = {}
    results = {'mysql': mysql_service.update_module(module_name, input_json)}
    data = db_api.get_module(module_name)

    if env in ('all', 'main'):
        results['jenkins_api_test_cases_job'] = jenkins_service.update_api_test_job(module_name, build_server,'dev-main', data)
        results['jenkins_deploy_job-dev-main'] = jenkins_service.update_deploy_job(module_name, deploy_server, 'dev-main', 'cae', data)
        results['jenkins_deploy_job-stg1-main'] = jenkins_service.update_deploy_job(module_name, deploy_server, 'stg1-main', 'cae', data)
        results['jenkins_deploy_job-stg2-main'] = jenkins_service.update_deploy_job(module_name, deploy_server, 'stg2-main', 'cae', data)
        results['jenkins_build_job-dev-main'] = jenkins_service.update_build_job(module_name, build_server, 'dev-main', data)

    if env in ('all', 'rel'):
        results['jenkins_deploy_job-dev-rel'] = jenkins_service.update_deploy_job(module_name, prd_deploy_server, 'dev-rel', 'cae', data)
        results['jenkins_deploy_job-stg-rel'] = jenkins_service.update_deploy_job(module_name, prd_deploy_server, 'stg-rel', 'cae', data)
        results['jenkins_build_job-dev-rel'] = jenkins_service.update_build_job(module_name, build_server, 'dev-rel', data)

        # Production
        results['jenkins_deploy_job-pre-prd1'] = jenkins_service.update_deploy_job(module_name, prd_deploy_server, 'pre-prd1', 'cae', data)
        results['jenkins_deploy_job-pre-prd2'] = jenkins_service.update_deploy_job(module_name, prd_deploy_server, 'pre-prd2', 'cae', data)
        results['jenkins_deploy_job-prd1'] = jenkins_service.update_deploy_job(module_name, prd_deploy_server, 'prd1', 'cae', data)
        results['jenkins_deploy_job-prd2'] = jenkins_service.update_deploy_job(module_name, prd_deploy_server, 'prd2', 'cae', data)
        results['jenkins_deploy_job-prd3'] = jenkins_service.update_deploy_job(module_name, prd_deploy_server, 'prd3', 'cae', data)

    returnObj[module_name] = results
    return returnObj


def get_status(module_name, env):
    msg = validation.validate_status(module_name, env)

    if msg is not None:
        Logger.info(msg)
        return msg

    host_versions = mysql_service.get_host_versions(module_name, env)
    host_healthchecks = healthcheck.nagio_healthcheck(module_name, env)

    hosts = {}
    for host in host_healthchecks:
        version = host_versions[host]
        health = host_healthchecks[host]
        if health != "Success":
            log_url = 'http://'+str(host) + ':8000/' + str(module_name).lower() + '/ServerLogger.log'
            hosts[host] = {'version': version, 'health_check': health, 'log_url': log_url}
        else:
            hosts[host] = {'version': version, 'health_check': health}

    return {module_name: hosts}

def get_cae_status(module_name, env):
    msg = validation.validate_status(module_name, env)

    if msg is not None:
        Logger.info(msg)
        return msg

    cae_expected_version  = mysql_service.get_cae_versions(module_name,env)
    
    cae_result = {}
    for env_key in cae_expected_version:
        expected_version = cae_expected_version[env_key]
        actual_version = cae_service.get_cae_module_version (module_name, env_key)
        health = healthcheck.cae_nagio_healthcheck(module_name,env_key)
        
        cae_result[env_key] = {'expected_version': expected_version ,'actual_version': actual_version , 'health_check' : health }

    return { module_name : cae_result }
