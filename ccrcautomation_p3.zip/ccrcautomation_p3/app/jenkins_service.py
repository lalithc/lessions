import Logger

import validation
import jkapi
import re


def create_api_test_job(module_name, server_name, env, data):
    job_name = jkapi.get_job_name(module_name, env, "test", None)

    msg = validation.validate_create_job(module_name, server_name, env, job_name, "test", None, data)
    if msg is not None:
        Logger.info(msg)
        return msg

    jkapi.create_api_test_job(module_name, server_name, env, job_name, data)
    return "API tests job %s for %s on server %s created!" % (job_name, env, server_name)


def update_api_test_job(module_name, server_name, env, data):
    job_name = jkapi.get_job_name(module_name, env, "test", None)

    msg = validation.validate_update_job(module_name, server_name, env, job_name, "test", None, data)
    if msg is not None:
        Logger.info(msg)
        return msg

    jkapi.update_api_test_job(module_name, server_name, env, job_name, data)
    return "API tests job %s for %s on server %s updated!" % (job_name, env, server_name)


def create_sub_module_build_job(module_name, server_name, env, data):
    job_name = jkapi.get_job_name(module_name, env, "build_dependency", None)
    msg = validation.validate_create_job(module_name, server_name, env, job_name, "build_dependency", None, data)
    if msg is not None:
        Logger.info(msg)
        return msg

    jkapi.create_build_dependency_job(module_name, server_name, env, job_name, data)
    return "Build dependency job %s for %s on server %s created!" % (job_name, env, server_name)


def update_sub_module_build_job(module_name, server_name, env, data):
    job_name = jkapi.get_job_name(module_name, env, "build_dependency", None)
    msg = validation.validate_update_job(module_name, server_name, env, job_name, "build_dependency", None, data)
    if msg is not None:
        Logger.info(msg)
        return msg

    jkapi.update_build_dependency_job(module_name, server_name, env, job_name, data)
    return "Build dependency job %s for %s on server %s updated!" % (job_name, env, server_name)


def create_deploy_job(module_name, server_name, env, job_type, data):
    saas = get_saas(data, module_name, env)
    job_name = jkapi.get_job_name(module_name, env, "deploy", job_type, saas=saas)
    print(str(job_name)+str(server_name))
    print('start validation of deploy jobs')
    msg = validation.validate_create_job(module_name, server_name, env, job_name, "deploy", job_type, data)
    if msg is not None:
        Logger.info(msg)
        return msg
    
    print('deploy job validated')

    jkapi.create_deploy_job(module_name, server_name, env, job_type, job_name, data)
    return "Deploy job %s for %s on server %s created!" % (job_name, env, server_name)


def update_deploy_job(module_name, server_name, env, job_type, data):
    saas = get_saas(data, module_name, env)
    job_name = jkapi.get_job_name(module_name, env, "deploy", job_type, saas=saas)

    msg = validation.validate_update_job(module_name, server_name, env, job_name, "deploy", job_type, data)
    if msg is not None:
        Logger.info(msg)
        return msg

    jkapi.update_deploy_job(module_name, server_name, env, job_type, job_name, data)
    return "Deploy job %s for %s on server %s updated!" % (job_name, env, server_name)


def create_build_job(module_name, server_name, env, data):
    job_name = jkapi.get_job_name(module_name, env, "build", None)

    msg = validation.validate_create_job(module_name, server_name, env, job_name, "build", None, data)
    if msg is not None:
        Logger.info(msg)
        return msg

    jkapi.create_build_job(module_name, server_name, env, job_name, data)
    return "Build job %s for %s on server %s created!" % (job_name, env, server_name)


def update_build_job(module_name, server_name, env, data):
    job_name = jkapi.get_job_name(module_name, env, "build", None)

    msg = validation.validate_update_job(module_name, server_name, env, job_name, "build", None, data)
    if msg is not None:
        Logger.info(msg)
        return msg

    jkapi.update_build_job(module_name, server_name, env, job_name, data)
    return "Build job %s for %s on server %s updated!" % (job_name, env, server_name)


def delete_job(module_name, server_name, env, goal, job_type, data):
    saas = get_saas(data, module_name, env)
    job_name = jkapi.get_job_name(module_name, env, goal, job_type, saas=saas)

    if job_name is None:
        return "Job not supported for env %s, goal %s, and job_type %s" % (env, goal, job_type)

    jkapi.delete_job(job_name, server_name)
    return "Job %s deleted from %s" % (job_name, server_name)


def get_saas(data, module_name, env):
    saas = ""
    if re.match(r'(pre-)*prd\d*', env):
        if module_name in data:
            project = data[module_name]['project']
            if project == "subscriptions":
                saas = "-SaaS"

    return saas
