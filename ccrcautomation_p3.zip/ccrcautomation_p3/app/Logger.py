import logging
import os

log_format = "%(asctime)s [%(levelname)s] %(message)s"
log_dir = os.getenv('LOG_DIR', "app")


def get_log_file(log_file):
    return "%s/%s" % (log_dir, log_file)


def setup_logger(name, log_file, level):
    handler = logging.FileHandler(get_log_file(log_file))
    handler.setFormatter(logging.Formatter(log_format))

    logger = logging.getLogger(name)
    logger.setLevel(level)
    logger.addHandler(handler)

    return logger


logging.basicConfig(format=log_format, filename=get_log_file("debug.log"), level=logging.DEBUG)
errorLogger = setup_logger("error", "exception.log", logging.ERROR)


def exception(msg):
    errorLogger.exception(msg)


def info(msg):
    logging.info(msg)


def error(msg):
    errorLogger.error(msg)
