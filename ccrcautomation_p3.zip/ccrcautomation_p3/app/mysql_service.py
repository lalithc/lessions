import Logger

import db.data as db_api
import validation


def create_submodule(input_json):
    module_name = input_json.get('module', None)
    module_type = input_json.get('type', None)

    msg = validation.validate_create_submodule(module_name, module_type)
    if msg is not None:
        Logger.info(msg)
        return msg

    db_api.create_submodule(module_name, module_type)
    return "Submodule %s of type %s has been created" % (module_name, module_type)


def update_submodule(input_json):
    module_name = input_json.get('module', None)
    module_type = input_json.get('type', None)

    msg = validation.validate_update_submodule(module_name, module_type)
    if msg is not None:
        Logger.info(msg)
        return msg

    db_api.update_submodule(module_name, module_type)
    return "Submodule %s has been updated to type %s" % (module_name, module_type)


def create_module(input_json):
    module_name = input_json.get('module', None)
    module_type = input_json.get('type', None)
    ext = input_json.get('ext', get_ext_from_module_type(module_type))
    hosts = input_json.get('hosts', None)
    service_name = input_json.get('service_name', get_service_name_from_module_name(module_name))
    heap_min = input_json.get('heap_min', '512')
    heap_max = input_json.get('heap_max', '1024')
    project = input_json.get('project', 'ServiceContract')
    jmx_port = input_json.get('jmx_port')
    container_cpu = input_json.get('container_cpu', 1)
    container_mem = input_json.get('container_mem', str(get_container_mem_from_heap_max(heap_max)))
    request_cpu = input_json.get('request_cpu', str(get_request_cpu_from_container_cpu(container_cpu)))
    request_mem = input_json.get('request_mem', container_mem)
    git_repo = input_json.get('git_repo', service_name)
    jvm_params = input_json.get('jvm_params', None)
    bg_enabled = input_json.get('bg_enabled', 'Y')

    msg = validation.validate_create_module(module_name, ext, module_type, service_name, jmx_port, project)
    if msg is not None:
        Logger.info(msg)
        return msg

    if jmx_port is None:
        jmx_port = db_api.get_new_jmx()

    rmi_port = get_rmi_from_jmx(jmx_port)
    http_port = get_http_port_from_jmx(jmx_port)

    generated_hosts = db_api.create_module(module_name, ext, module_type, hosts, service_name, heap_min, heap_max,
                                           jmx_port, rmi_port, project, container_cpu, container_mem, http_port,
                                           bg_enabled, request_cpu, request_mem, git_repo, jvm_params)
    hosts_string = get_hosts_string(generated_hosts, "POST")
    return "Module %s of type %s packaged as a %s has been created with service_name %s, heap_min %s, " \
           "heap_max %s, jmx_port %s, rmi_port %s, container_cpu %s, container_mem %s, " \
           "and assigned the following hosts: %s" \
           % (module_name, module_type, ext, service_name, heap_min, heap_max, jmx_port, rmi_port, container_cpu,
              container_mem,  hosts_string)


def update_module(module_name, input_json):
    ext = input_json.get('ext', None)
    module_type = input_json.get('type', None)
    hosts = input_json.get('hosts', None)
    service_name = input_json.get('service_name', None)
    heap_min = input_json.get('heap_min', None)
    heap_max = input_json.get('heap_max', None)
    jmx_port = input_json.get('jmx_port')
    project = input_json.get('project')
    container_cpu = input_json.get('container_cpu', None)
    container_mem = input_json.get('container_mem', None)
    request_cpu = input_json.get('request_cpu', None)
    request_mem = input_json.get('request_mem', None)
    git_repo = input_json.get('git_repo', None)
    jvm_params = input_json.get('jvm_params', None)

    msg = validation.validate_update_module(module_name, ext, module_type, service_name, jmx_port, project)
    if msg is not None:
        Logger.info(msg)
        return msg

    rmi_port = get_rmi_from_jmx(jmx_port)

    db_api.update_module(module_name, ext, module_type, hosts, service_name, heap_min, heap_max, jmx_port, rmi_port,
                         project, container_cpu, container_mem, request_cpu, request_mem, git_repo, jvm_params)
    hosts_string = get_hosts_string(hosts, "PUT")
    return "Module %s has been updated to project %s, type %s, ext %s, service_name %s, heap_min %s, heap_max %s, " \
           "jmx_port %s, rmi_port %s, container_cpu %s, container_mem %s, " \
           "and has been assigned the following hosts: %s" \
           % (module_name, nvl(project), nvl(module_type), nvl(ext), nvl(service_name), nvl(heap_min), nvl(heap_max),
              nvl(jmx_port), nvl(rmi_port), nvl(container_cpu), nvl(container_mem), hosts_string)


def update_env(env, input_json):
    blue_green = input_json.get('blue_green', None)
    hotfix_enabled = input_json.get('hotfix_enabled', None)
    if blue_green is None and hotfix_enabled is None:
        return "blue_green or hotfix_enabled parameter is mandatory!"
    else:
        db_api.update_env(env, blue_green, hotfix_enabled)
        return "Env %s labeled to be running on %s route and hotfix %s!" % (env, blue_green, hotfix_enabled)


def create_ping_api_test(module_name, data):
    if not db_api.module_exists(module_name):
        return "Module %s does not exist!" % module_name

    return db_api.create_ping_api_test(module_name, data)


def update_version(input_json):
    module_name = input_json.get('module')
    host_name = input_json.get('host')
    version = input_json.get('version')
    env = input_json.get('env')

    msg = validation.validate_update_version(module_name, host_name, env, version)
    if msg is not None:
        Logger.info(msg)
        return msg

    result = db_api.update_version(module_name, host_name, env, version)
    return result


def promote_version(input_json):
    module_name = input_json.get('module')
    source_env = input_json.get('source_env')
    target_env = input_json.get('target_env')

    msg = validation.validate_promote_version(module_name, source_env, target_env)
    if msg is not None:
        Logger.info(msg)
        return msg

    msg = "Module %s has been promoted from %s to %s" % (module_name, source_env, target_env)
    if module_name == 'all':
        msg = "All modules have been promoted from %s to %s" % (source_env, target_env)
        module_name = None

    db_api.promote_version(module_name, source_env, target_env)
    return msg


def get_env_versions(module_name, env):
    return db_api.get_env_versions(module_name, env)


def get_host_versions(module_name, env):
    return db_api.get_host_versions(module_name, env)


def get_cae_versions(module_name, env):
    return db_api.get_cae_versions(module_name,env)


def nvl(var):
    return "<no change>" if var is None else var


# rmi_port is jmx_port but replacing first letter with "7"
def get_rmi_from_jmx(jmx_port):
    if jmx_port is None:
        return None

    jmx_tail_len = len(str(jmx_port))-1
    rmi_port = "7%s" % (str(jmx_port)[-jmx_tail_len:])
    return rmi_port


def get_http_port_from_jmx(jmx_port):
    if jmx_port is None:
        return None

    http_port = "2%s" % str(jmx_port)
    return http_port


def get_ext_from_module_type(module_type):
    if module_type is None:
        return None

    if module_type == "springboot":
        return "jar"

    if module_type == "tomcat":
        return "war"

    if module_type in ("nodejs", "nginx"):
        return "zip"


def get_service_name_from_module_name(module_name):
    if module_name is None:
        return None

    moduleStr = str.lower(str(module_name))

    if len(module_name) <= 15:
        return moduleStr
    else:
        return str.replace(moduleStr, "ccrc", "")[:15]


def get_container_mem_from_heap_max(heap_max):
    return int(heap_max) + 512


def get_request_cpu_from_container_cpu(container_cpu):
    return float(container_cpu) / 2


def get_hosts_string(hosts, method):
    if hosts is None and method == "PUT":
        return "<no change>"
    elif hosts is None and method == "POST":
        return "\nWARNING: No hosts were assigned to this module!"

    if isinstance(hosts, basestring):
        return "[%s]" % hosts
    else:
        return "[%s]" % ", ".join(hosts)


def update_replicas(input_json):
    module_name = input_json.get('module')
    env = input_json.get('env')
    blue_replicas = input_json.get('blue', None)
    green_replicas = input_json.get('green', None)
        
    msg = validation.validate_update_replicas(module_name, env, blue_replicas, green_replicas)
    if msg is not None:
        Logger.info(msg)
        return msg

    result = db_api.update_replicas(module_name, env, blue_replicas, green_replicas)
    return result

def promote_version_dc3(input_json):
    module_name = input_json.get('module')
    source_env = input_json.get('source_env')
    target_env = input_json.get('target_env')

    msg = validation.validate_promote_version(module_name, source_env, target_env)
    if msg is not None:
        Logger.info(msg)
        return msg

    msg = "Module %s has been promoted from %s to %s" % (module_name, source_env, target_env)
    if module_name == 'all':
        msg = "All modules have been promoted from %s to %s" % (source_env, target_env)
        module_name = None

    db_api.promote_version_dc3(module_name, source_env, target_env)
    return msg

def get_nonms(app,env):
    return db_api.get_nonms(app,env)
