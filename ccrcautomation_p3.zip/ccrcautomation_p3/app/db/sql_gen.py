def get_modules(module_name, ext, module_type, host_name, env, heap_min, heap_max, project, automated, bg_enabled,
                pre_prd_enabled, cae_enabled, lt_enabled):
    sql = ("SELECT m.module_name, ext, type, h.host_name, h.env, m.service_name, m.heap_min, m.heap_max, m.jmx_port, "
           "m.rmi_port, m.project, m.automated, m.comments, m.container_cpu, m.container_mem, m.http_port, "
           "m.api_test_code, m.bg_enabled, m.pre_prd_enabled, m.cae_enabled, NULL, NULL, NULL, m.lt_enabled, "
           "m.ping_url, NULL, m.request_cpu, m.request_mem, m.git_repo, m.jvm_params "
           "FROM modules m "
           "LEFT JOIN modules_hosts mh ON m.module_name = mh.module_name "
           "LEFT JOIN hosts h ON mh.host_name = h.host_name "
           "WHERE 1=1 ")

    sql = get_filter(sql, module_name, ext, module_type, host_name, env, heap_min, heap_max, project, automated,
                     bg_enabled, pre_prd_enabled, cae_enabled, lt_enabled)
    cae_sql = ("SELECT m.module_name, ext, type, NULL, h.env, m.service_name, m.heap_min, m.heap_max, m.jmx_port, "
               "m.rmi_port, m.project, m.automated, m.comments, m.container_cpu, m.container_mem, m.http_port, "
               "m.api_test_code, m.bg_enabled, m.pre_prd_enabled, m.cae_enabled, h.blue_replicas, h.green_replicas, "
               "h.version, m.lt_enabled, m.ping_url, h.replicas, m.request_cpu, m.request_mem, m.git_repo, "
               "m.jvm_params "
               "FROM modules m "
               "LEFT JOIN modules_envs h ON m.module_name = h.module_name "
               "WHERE 1=1 ")
    cae_sql = get_filter(cae_sql, module_name, ext, module_type, None, env, heap_min, heap_max, project, automated,
                         bg_enabled, pre_prd_enabled, cae_enabled, lt_enabled)
    return sql + "UNION " + cae_sql


def get_sub_modules(module_name, module_type):
    sql = ("SELECT m.module_name, m.type, m.git_repo "
           "FROM submodules m "
           "WHERE 1=1 ")

    sql = get_filter(sql, module_name, None, module_type, None, None, None, None, None, None, None, None, None, None)
    return sql


def get_hosts(host_name, env):
    sql = ("SELECT h.host_name, h.env FROM hosts h "
           "WHERE 1=1 ")

    sql = get_filter(sql, None, None, None, host_name, env, None, None, None, None, None, None, None, None)
    return sql


def get_filter(sql, module_name, ext, module_type, host_name, env, heap_min, heap_max, project, automated,
               bg_enabled, pre_prd_enabled, cae_enabled, lt_enabled):
    if module_name is not None:
        sql = sql + "AND m.module_name = '%s' " % module_name

    if ext is not None:
        sql = sql + "AND m.ext = '%s' " % ext

    if module_type is not None:
        sql = sql + "AND m.type = '%s' " % module_type

    if host_name is not None:
        sql = sql + "AND h.host_name = '%s' " % host_name

    if env is not None:
        sql = sql + "AND h.env in (%s) " % env

    if heap_min is not None:
        sql = sql + "AND m.heap_min = '%s' " % heap_min

    if heap_max is not None:
        sql = sql + "AND m.heap_max = '%s' " % heap_max

    if project is not None:
        sql = sql + "AND m.project = '%s' " % project

    if automated is not None:
        sql = sql + "AND m.automated = '%s' " % automated

    if pre_prd_enabled is not None:
        sql = sql + "AND m.pre_prd_enabled = '%s' " % pre_prd_enabled

    if bg_enabled is not None:
        sql = sql + "AND m.bg_enabled = '%s' " % bg_enabled

    if cae_enabled is not None:
        sql = sql + "AND m.cae_enabled = '%s' " % cae_enabled

    if lt_enabled is not None:
        sql = sql + "AND m.lt_enabled = '%s' " % lt_enabled

    return sql


def get_hosts_insert(module_name, host):
    sql = ("INSERT INTO modules_hosts (module_name, host_name) "
           "SELECT * FROM (SELECT '%s', '%s') AS tmp WHERE NOT EXISTS "
           "(SELECT 1 FROM modules_hosts WHERE module_name = '%s' AND host_name = '%s') LIMIT 1"
           % (module_name, host, module_name, host))

    return sql


def get_moduleNames():
    sql = "SELECT module_name FROM modules"
    return sql


def get_host_allocation_query(envs):
    query = ""
    first = True
    for env in envs:
        limit = 2
        if env in ("dev-rel", "stg1-rel", "stg2-rel", "pre-prd1", "pre-prd2"):
            limit = 1
        if env in ("prd1", "prd2"):
            limit = 3

        env_table = str.replace(env, "-", "_")
        env_query = ("(SELECT vm_mem, host_name, env FROM ("
                     "SELECT SUM(ifnull(container_mem,0)) vm_mem, h.host_name host_name, h.env env "
                     "FROM hosts h "
                     "LEFT JOIN modules_hosts mh on mh.host_name = h.host_name "
                     "LEFT JOIN modules m on mh.module_name = m.module_name "
                     "INNER JOIN envs e on e.env = h.env "
                     "WHERE h.env='%s' AND e.env_type='microservice' "
                     "GROUP BY mh.host_name, h.env "
                     "ORDER BY h.env, vm_mem asc) as %s limit %s)" % (env, env_table, limit))
        if first:
            query = env_query
            first = False
        else:
            query = "%s UNION %s" % (query, env_query)

    return query
