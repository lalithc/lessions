import db
import sql_gen
import logging
import json

logging.basicConfig(format='%(asctime)s [%(levelname)s] %(message)s', level=logging.DEBUG)


def get_sub_module(module_name):
    return get_sub_modules(module_name, None)


def get_module(module_name):
    return get_modules(module_name, None, None, None, None, None, None, None, None, None, None, None, None)


def get_automated_modules(project):
    return get_modules(None, None, None, None, None, None, None, project, "Y", None, None, None, None)


def get_modules(module_name, ext, module_type, host_name, env, heap_min, heap_max, project, automated, bg_enabled,
                pre_prd_enabled, cae_enabled, lt_enabled):
    conn = db.get_connection()

    cur = conn.cursor()
    sql = sql_gen.get_modules(module_name, ext, module_type, host_name, resolve_env(env), heap_min, heap_max,
                              project, automated, bg_enabled, pre_prd_enabled, cae_enabled, lt_enabled)
    cur.execute(sql)
    rows = cur.fetchall()

    modules = {}
    for module_name, ext, module_type, host, env, service_name, heap_min, heap_max, jmx_port, rmi_port, project, \
        automated, comments, container_cpu, container_mem, http_port, api_test_code, bg_enabled, pre_prd_enabled, \
        cae_enabled, blue_replicas, green_replicas, version, lt_enabled, ping_url, replicas, request_cpu, request_mem, \
        git_repo, jvm_params \
            in rows:
        if module_name in modules:
            m = modules[module_name]
            if env in m['envs']:
                env_obj = m['envs'][env]
            else:
                env_obj = None

            m['envs'][env] = construct_env(env_obj, host, blue_replicas, green_replicas, version, replicas)
        else:
            env_obj = construct_env(None, host, blue_replicas, green_replicas, version, replicas)
            modules[module_name] = {'ext': ext, 'type': module_type, 'service_name': service_name, 'project': project,
                                    'heap_min': heap_min, 'heap_max': heap_max, 'jmx_port': jmx_port,
                                    'automated': automated, 'comments': comments, 'container_cpu': container_cpu,
                                    'container_mem': container_mem, 'rmi_port': rmi_port, 'http_port': str(http_port),
                                    'api_test_code': api_test_code, 'bg_enabled': bg_enabled,
                                    'pre_prd_enabled': pre_prd_enabled, 'cae_enabled': cae_enabled,
                                    'lt_enabled': lt_enabled, 'ping_url': ping_url, 'request_cpu': request_cpu,
                                    'request_mem': request_mem, 'git_repo': git_repo, 'jvm_params': jvm_params,
                                    'envs': {env: env_obj}}

    conn.close()

    return modules


def construct_env(env_obj, host, blue_replicas, green_replicas, version, replicas):
    if env_obj is None:
        env_obj = {}

    if host is not None:
        if 'hosts' in env_obj:
            env_obj['hosts'].append(host)
        else:
            env_obj['hosts'] = [host]

    if blue_replicas is not None and green_replicas is not None and replicas is not None:
        env_obj['blue_replicas'] = blue_replicas
        env_obj['green_replicas'] = green_replicas
        env_obj['replicas'] = replicas

    if version is not None:
        env_obj['version'] = version

    return env_obj


def get_sub_modules(module_name, module_type):
    conn = db.get_connection()

    cur = conn.cursor()
    sql = sql_gen.get_sub_modules(module_name, module_type)

    cur.execute(sql)
    rows = cur.fetchall()

    modules = {}
    for module_name, module_type, git_repo in rows:
        modules[module_name] = {'type': module_type, 'git_repo': git_repo}

    conn.close()

    return modules


def get_hosts(host_name, env):
    conn = db.get_connection()

    cur = conn.cursor()
    sql = sql_gen.get_hosts(host_name, resolve_env(env))
    cur.execute(sql)
    rows = cur.fetchall()

    hosts = {}
    for host_name, env in rows:
        if env in hosts:
            e = hosts[env]
            e.append(host_name)
        else:
            e = [host_name]
            hosts[env] = e

    conn.close()

    return hosts


def module_exists(module_name, env=None):
    pre_prd_filter = ""
    if env is not None and env in ("pre-prd1", "pre-prd2"):
        pre_prd_filter = " AND m.pre_prd_enabled='Y'"

    sql = "SELECT m.module_name FROM modules m WHERE m.module_name = '%s'%s " \
          "UNION SELECT sm.module_name FROM submodules sm " \
          "WHERE sm.module_name = '%s'" % (module_name, pre_prd_filter, module_name)

    conn = db.get_connection()

    cur = conn.cursor()
    cur.execute(sql)
    rows = cur.fetchone()
    if not rows:
        return False
    else:
        return True


def create_submodule(module_name, module_type):
    conn = db.get_connection()
    module_insert = ("INSERT INTO submodules (module_name, type) "
                     "values ('%s', '%s')") % (module_name, module_type)

    cur = conn.cursor()
    logging.info("adding submodule %s of type %s" % (module_name, module_type))
    cur.execute(module_insert)
    conn.commit()


def update_submodule(module_name, module_type):
    conn = db.get_connection()

    module_update = ("UPDATE submodules set type = IFNULL(%s,type) "
                     "WHERE module_name = '%s'"
                     % (nvl(module_type, 'NULL'), module_name))

    cur = conn.cursor()
    logging.info("updating submodule %s to type %s" % (module_name, module_type))
    cur.execute(module_update)
    conn.commit()


def create_module(module_name, ext, module_type, hosts, service_name, heap_min, heap_max, jmx_port, rmi_port, project,
                  container_cpu, container_mem, http_port, bg_enabled, request_cpu, request_mem, git_repo, jvm_params):
    conn = db.get_connection()

    api_test_code = service_name.upper()
    ping_url = get_ping_url(module_name)

    if hosts is None:
        cur = conn.cursor()
        cur.execute(
            "SELECT env env "
            "FROM envs e "
            "WHERE e.env_type='microservice' AND '%s' NOT IN ("
            "SELECT module_name FROM modules_hosts mh "
            "INNER JOIN hosts h on mh.host_Name = h.host_name "
            "WHERE h.env = e.env and h.env not in ('stg2-rel','stg2-main'))" % module_name)
        rows = cur.fetchall()
        envs = []
        for row in rows:
            env = row[0]
            envs.append(env)

        if len(envs) > 0:
            hosts = []
            host_allocation_query = sql_gen.get_host_allocation_query(envs)
            cur = conn.cursor()
            cur.execute(host_allocation_query)
            rows = cur.fetchall()
            for vm_mem, host_name, env in rows:
                hosts.append(host_name)

    module_insert = \
        "INSERT INTO modules (module_name, type, ext, service_name, heap_min, heap_max, jmx_port, rmi_port, project," \
        " container_cpu, container_mem, http_port, api_test_code, ping_url, bg_enabled, request_cpu, request_mem," \
        " git_repo, jvm_params) " \
        "values ('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', %s, '%s', '%s', '%s', '%s', '%s', " \
        "'%s', '%s')" \
        % (module_name, module_type, ext, service_name, heap_min, heap_max, jmx_port, rmi_port, project,
           container_cpu, container_mem, http_port, api_test_code, ping_url, bg_enabled, request_cpu, request_mem,
           git_repo, jvm_params)
    cur = conn.cursor()
    logging.info("adding module %s to project %s of type %s with ext %s with heap_min %s, heap_max of %s, "
                 "jmx_port of %s, rmi_port of %s, container_cpu of %s, container_mem of %s, http_port of %s, "
                 "and bg_enabled %s"
                 % (module_name, project, module_type, ext, heap_min, heap_max, jmx_port, rmi_port, container_cpu,
                    container_mem, http_port, bg_enabled))
    cur.execute(module_insert)

    add_hosts(cur, module_name, hosts)

    module_env_insert = \
        "INSERT INTO modules_envs (module_name, env, blue_replicas, green_replicas, replicas) " \
        "SELECT '%s', env, " \
        "CASE WHEN e.env like 'prd%%' then 0 ELSE 0 END blue_replicas, " \
        "CASE WHEN e.env like 'prd%%' then 0 ELSE 0 END green_replicas," \
        "CASE WHEN e.env like 'prd%%' then 2 ELSE 1 END replicas " \
        "FROM envs e WHERE e.env_type='microservice'" % module_name
    cur = conn.cursor()
    cur.execute(module_env_insert)

    conn.commit()

    return hosts


def update_module(module_name, ext, module_type, hosts, service_name, heap_min, heap_max, jmx_port, rmi_port, project,
                  container_cpu, container_mem, request_cpu, request_mem, git_repo, jvm_params):
    conn = db.get_connection()

    module_update = ("UPDATE modules set ext = IFNULL(%s,ext), type = IFNULL(%s,type), "
                     "service_name = IFNULL(%s,service_name), heap_min = IFNULL(%s,heap_min), "
                     "heap_max = IFNULL(%s, heap_max), jmx_port = IFNULL(%s, jmx_port), "
                     "rmi_port = IFNULL(%s, rmi_port), project = IFNULL(%s, project), "
                     "container_cpu = IFNULL(%s, container_cpu), container_mem = IFNULL(%s, container_mem),"
                     "request_cpu = IFNULL(%s, request_cpu), request_mem = IFNULL(%s, request_mem),"
                     "git_repo = IFNULL(%s, git_repo), jvm_params = IFNULL(%s, jvm_params) "
                     "WHERE module_name = '%s'"
                     % (nvl(ext, 'NULL'), nvl(module_type, 'NULL'), nvl(service_name, 'NULL'),
                        nvl(heap_min, 'NULL'), nvl(heap_max, 'NULL'), nvl(jmx_port, 'NULL'),
                        nvl(rmi_port, 'NULL'), nvl(project, 'NULL'), nvl(container_cpu, 'NULL'),
                        nvl(container_mem, 'NULL'), nvl(request_cpu, 'NULL'), nvl(request_mem, 'NULL'),
                        nvl(git_repo, 'NULL'), nvl(jvm_params, 'NULL'), module_name))

    cur = conn.cursor()
    logging.info("updating module %s to project %s, type %s, ext %s, service_name %s, heap_min %s, heap_max %s, "
                 "jmx_port %s, rmi_port %s, container_cpu %s, container_mem %s"
                 % (module_name, project, module_type, ext, service_name, heap_min, heap_max, jmx_port, rmi_port,
                    container_cpu, container_mem))
    cur.execute(module_update)

    add_hosts(cur, module_name, hosts)

    conn.commit()


def create_ping_api_test(module_name, data):
    api_test_code = str(data[module_name]['api_test_code'])
    project = str(data[module_name]['project'])
    module_name_lower = str(module_name).lower()
    base_url = "http://ccrc-sc-dev.cisco.com/%s-main/%s" % (project, module_name_lower)
    ping_url = "/ping"

    if module_name == "CCRCCommonUX":
        ping_url = "/ping.html"

    if module_name in ("CCRCCommonUX", "CCRCSaaSUI"):
        base_url = "http://ccrc-sc-dev.cisco.com/%s-main" % project

    url_sql = ("INSERT INTO ccrc_taf.XXCSS_QUOTE_TAF_SERVER_INFO (TC_ENV, SERVICE_TYPE, SERVICE_HOST_URL) "
               "SELECT * FROM (SELECT 'DEV-MAIN', '%s' service_type, '%s' service_host_url) AS t "
               "WHERE NOT EXISTS (SELECT 1 from ccrc_taf.XXCSS_QUOTE_TAF_SERVER_INFO WHERE SERVICE_TYPE = '%s') "
               "LIMIT 1") % (api_test_code, base_url, api_test_code)

    tc_sql = ("INSERT INTO ccrc_taf.XXCSS_QUOTE_TAF_TESTCASE "
              "(TC_ID, TRACK_NAME, CATEGORY, TC_DESCRIPTION, EXECUTE_FLAG, TC_USER_REF, CREATED_BY, CREATION_DATE) "
              "SELECT * FROM "
              "(SELECT 'PING_%s_01', '%s Module', '%s', '%s Description', 'Y', '1', 'SYSTEM', CURDATE()) AS t "
              "WHERE NOT EXISTS (SELECT 1 from ccrc_taf.XXCSS_QUOTE_TAF_TESTCASE WHERE TC_ID='PING_%s_01') "
              "LIMIT 1") % (api_test_code, module_name, api_test_code, module_name, api_test_code)

    tc_steps_sql = ("INSERT INTO ccrc_taf.XXCSS_QUOTE_TAF_TC_STEPS "
                    "(TC_ID, TC_SEQ_NO, SERVICE_TYPE, SERVICE_URL, SERVICE_METHOD, EXPECTED_STATUS_CODE, "
                    "STOPPER_YN, CREATED_BY, CREATION_DATE, DELAY_BEFORE) "
                    "SELECT * FROM (SELECT 'PING_%s_01',1,'%s','%s','GET','200','Y','SYSTEM',CURDATE(),0) AS t "
                    "WHERE NOT EXISTS (SELECT 1 from ccrc_taf.XXCSS_QUOTE_TAF_TC_STEPS WHERE TC_ID = 'PING_%s_01') "
                    "LIMIT 1") % (api_test_code, api_test_code, ping_url, api_test_code)

    email_sql = ("INSERT INTO ccrc_taf.XXCSS_QUOTE_TAF_MAIL_CONFIG "
                 "(TEST_CATEGORY,TO_ADDRESS,CC_ADDRESS,BCC_ADDRESS,MAIL_FROM) "
                 "SELECT * FROM (SELECT '%s','ccrc-build-notifications@cisco.com','vsistu@cisco.com',"
                 "'vrachuri@cisco.com','ccrc-devops@cisco.com') AS t "
                 "WHERE NOT EXISTS (SELECT 1 from ccrc_taf.XXCSS_QUOTE_TAF_MAIL_CONFIG WHERE TEST_CATEGORY='%s') "
                 "LIMIT 1") % (api_test_code, api_test_code)

    conn = db.get_connection()
    cur = conn.cursor()
    logging.info("Adding test cases for module %s" % module_name)

    cur.execute(url_sql)
    cur.execute(tc_sql)
    cur.execute(tc_steps_sql)
    cur.execute(email_sql)
    conn.commit()

    return "API test for %s route with api test code of %s has been added for module %s" % (ping_url, api_test_code,
                                                                                            module_name)


def get_envs(env=None):
    conn = db.get_connection()

    env = resolve_env(env)

    env_filter = "AND env in (%s)" % env if env is not None else ""
    cur = conn.cursor()
    sql = "SELECT env, env_type, cae_enabled, blue_green, hotfix_enabled " \
          "FROM envs " \
          "WHERE 1=1 %s" % env_filter
    cur.execute(sql)
    rows = cur.fetchall()

    envs = {}
    for env, env_type, cae_enabled, blue_green, hotfix_enabled in rows:
        env_obj = {'env_type': env_type, 'cae_enabled': cae_enabled, 'blue_green': blue_green,
                   'hotfix_enabled': hotfix_enabled}
        envs[env] = env_obj

    conn.close()
    return envs


def update_env(env, blue_green, hotfix_enabled):
    conn = db.get_connection()
    cur = conn.cursor()

    sql = "UPDATE envs set blue_green = IFNULL(%s,blue_green), hotfix_enabled = IFNULL(%s,hotfix_enabled) " \
          "WHERE env = '%s'" % (nvl(blue_green, 'NULL'), nvl(hotfix_enabled, 'NULL'), env)

    logging.debug("updated env table: %s" % sql)

    cur.execute(sql)
    conn.commit()


def update_version(module_name, host_name, env, version):
    conn = db.get_connection()
    cur = conn.cursor()

    sql = ""
    result = ""
    if host_name is not None:
        sql = ("UPDATE modules_hosts set deployed_version = '%s' "
               "WHERE module_name = '%s' AND host_name = '%s'" % (version, module_name, host_name))

        logging.info("updating module %s on host %s to version %s" % (module_name, host_name, version))
        result = "Module %s on host %s has been updated to version %s" % (module_name, host_name, version)
    elif env is not None:
        sql = ("INSERT INTO modules_envs (module_name, env, version, blue_replicas, green_replicas, replicas) "
               "VALUES ('%s','%s','%s',%s,%s,%s) "
               "ON DUPLICATE KEY UPDATE version = '%s'") % (module_name, env, version, 0, 0, 2, version)
        result = "Module %s in env %s has been updated to version %s" % (module_name, env, version)
        logging.info("updating module %s for env %s to version %s" % (module_name, env, version))

    cur.execute(sql)
    conn.commit()

    return result


def update_replicas(module_name, env, blue_replicas, green_replicas):
    conn = db.get_connection()
    cur = conn.cursor()

    sql = ""
    result = ""

    sql = (
    "UPDATE modules_envs set blue_replicas = IFNULL(%s,blue_replicas),green_replicas = IFNULL(%s,green_replicas) "
    "WHERE module_name = '%s' AND env = '%s'" % (
    (nvl(blue_replicas, 'NULL')), (nvl(green_replicas, 'NULL')), module_name, env))
    cur.execute(sql)
    conn.commit()

    result = "%s updated with blue_replicas: %s and green_replicas: %s " % (module_name, blue_replicas, green_replicas)
    logging.info("updating blue/green replicas for %s in env %s" % (module_name, env))

    return result


def promote_version(module_name, source_env, target_env):
    conn = db.get_connection()
    cur = conn.cursor()

    source_envs = resolve_env(source_env)
    target_envs = resolve_env(target_env)
    sql = ("INSERT INTO modules_envs (module_name, env, version, blue_replicas, green_replicas, replicas) "
           "SELECT * FROM (SELECT me.module_name, e.env, me.version, me.blue_replicas, me.green_replicas, me.replicas "
           "FROM envs e "
           "LEFT JOIN modules_envs me ON me.env in (%s) and me.module_name = IFNULL(%s,me.module_name) "
           "WHERE e.env in (%s)) as t "
           "WHERE t.module_name is not null "
           "ON DUPLICATE KEY UPDATE version = t.version") % (source_envs, nvl(module_name, 'NULL'), target_envs)

    cur.execute(sql)
    conn.commit()


def get_env_versions(module_name, env):
    conn = db.get_connection()
    cur = conn.cursor()

    select_sql = ("SELECT module_name, env, version, blue_replicas, green_replicas, replicas FROM modules_envs "
                  "WHERE module_name = IFNULL(%s,module_name) "
                  "AND env = IFNULL(%s, env)" % (nvl(module_name, 'NULL', ), nvl(env, 'NULL')))
    cur.execute(select_sql)
    rows = cur.fetchall()

    modules = {}
    for module_name, env, version, blue_replicas, green_replicas, replicas in rows:
        if module_name in modules:
            m = modules[module_name]
            m['envs'][env] = {'version': version, 'blue_replicas': blue_replicas, 'green_replicas': green_replicas,
                              'replicas': replicas}
        else:
            modules[module_name] = {'envs': {env: {'version': version,
                                                   'blue_replicas': blue_replicas,
                                                   'green_replicas': green_replicas,
                                                   'replicas': replicas}}}

    conn.close()

    return modules


def get_cae_envs(main_rel):
    conn = db.get_connection()
    cur = conn.cursor()

    if main_rel == "main":
        env_filter = " AND env like '%main'"
    elif main_rel == "rel":
        env_filter = " AND env not like '%main'"
    else:
        env_filter = ""

    sql = ("SELECT env, env_type FROM envs "
           "WHERE cae_enabled='Y' %s" % env_filter)
    cur.execute(sql)
    rows = cur.fetchall()

    envs = {}
    for env, env_type in rows:
        envs[env] = env_type

    conn.close()
    return envs


def get_host_versions(module_name, env):
    conn = db.get_connection()

    cur = conn.cursor()
    sql = ("SELECT mh.host_name, mh.deployed_version "
           "FROM modules_hosts mh INNER JOIN hosts h ON mh.host_name = h.host_name "
           "WHERE mh.module_name = '%s' AND h.env in (%s)" % (module_name, resolve_env(env)))
    cur.execute(sql)
    rows = cur.fetchall()

    hosts = {}
    for host_name, version in rows:
        hosts[host_name] = version

    conn.close()

    return hosts


def get_cae_versions(module_name, env):
    conn = db.get_connection()
    cur = conn.cursor()
    sql = ("SELECT env,version "
           "FROM modules_envs "
           "WHERE module_name = '%s' AND env in (%s)" % (module_name, resolve_env(env)))
    cur.execute(sql)
    rows = cur.fetchall()

    env_versions = {}
    for env, version in rows:
        env_versions[env] = version

    conn.close()
    return env_versions


def add_hosts(cur, module_name, hosts):
    if hosts is None:
        return

    if isinstance(hosts, basestring):
        add_host(cur, module_name, hosts)
    else:
        for host in hosts:
            add_host(cur, module_name, host)

def get_app_replicas(app_name,env):
    conn = db.get_connection()
    cur = conn.cursor()
    sql = ("SELECT app,replicas "
           "FROM non_microservices "
           "WHERE app = '%s' AND env = '%s'" % (app_name, env))
    cur.execute(sql)
    rows = cur.fetchall()
    
    app_replica = {}
    for app,replica in rows:
        app_replica[app] = replica
        
    conn.close()
    return app_replica

def add_host(cur, module_name, host):
    logging.info("adding host %s to module %s" % (host, module_name))
    cur.execute(sql_gen.get_hosts_insert(module_name, host))


def get_new_jmx():
    conn = db.get_connection()
    cur = conn.cursor()
    cur.execute(
        "SELECT CAST(MAX(jmx_port)+1 AS UNSIGNED) jmx_port FROM modules WHERE jmx_port <> 'None' AND jmx_port < 9999"
    )
    jmx_port = int(cur.fetchone()[0])
    conn.close()
    return jmx_port


def nvl(var, val):
    return val if var is None else "'%s'" % var


def get_moduleNames():
    conn = db.get_connection()

    cur = conn.cursor()
    sql = sql_gen.get_moduleNames()
    cur.execute(sql)
    rows = cur.fetchall()
    moduleList = []
    for i in rows:
        moduleList.append(i[0])

    conn.close()
    return moduleList


def get_ping_url(module_name):
    return "/%s-main/ping" % module_name


def resolve_env(env):
    if env is None:
        return None

    if env == 'stg-rel':
        return "'stg1-rel','stg2-rel'"

    if env == 'stg-main':
        return "'stg1-main','stg2-main'"

    if env == 'prd':
        return "'prd1','prd2','prd3'"

    if env == 'pre-prd':
        return "'pre-prd1','pre-prd2'"

    return "'%s'" % env

def promote_version_dc3(module_name, source_env, target_env):
    conn = db.get_connection()
    cur = conn.cursor()

    source_envs = resolve_env(source_env)
    target_envs = "'prd3'"
    sql = ("INSERT INTO modules_envs (module_name, env, version, blue_replicas, green_replicas, replicas) "
           "SELECT * FROM (SELECT me.module_name, e.env, me.version, me.blue_replicas, me.green_replicas, me.replicas "
           "FROM envs e "
           "LEFT JOIN modules_envs me ON me.env in (%s) and me.module_name = IFNULL(%s,me.module_name) "
           "WHERE e.env in (%s)) as t "
           "WHERE t.module_name is not null "
           "ON DUPLICATE KEY UPDATE version = t.version") % (source_envs, nvl(module_name, 'NULL'), target_envs)

    cur.execute(sql)
    conn.commit()


def get_nonms(app,env):
    conn = db.get_connection()
    cur = conn.cursor()
    print app
    sql = "SELECT subtype " \
           "FROM non_microservices " \
           "WHERE app = '%s' and env = '%s'" % (app,env)
          
    print sql

    cur.execute(sql)
    rows = cur.fetchall()
    res=[]

    for r in rows:
       subtype=r[0]
       res.append(subtype)
    
    return json.dumps(res)
    
