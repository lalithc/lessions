import pymysql


def get_connection():
    hostname = 'ccrc-dbsrv-dev-03'
    username = 'root'
    password = 'cisco123'
    database = 'ccrc_automation_p3'

    conn = pymysql.connect(host=hostname, user=username, passwd=password, db=database)

    return conn
