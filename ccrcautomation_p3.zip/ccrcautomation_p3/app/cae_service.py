import db.data as db_api
import cae_api


def generate_resources(main_rel):
    modules = db_api.get_automated_modules(None)

    return cae_api.generate_resources(modules, main_rel)


def generate_resource(module_name, main_rel):
    data = db_api.get_module(module_name)
    return cae_api.generate_resource(module_name, data[module_name], main_rel)


def create_resources(main_rel, config_type, env):
    modules = db_api.get_automated_modules(None)

    return cae_api.create_resources(modules, main_rel, config_type, env)


def create_resource(module_name, main_rel, config_type, env):
    data = db_api.get_module(module_name)[module_name]
    return cae_api.create_resource(module_name, data, config_type, main_rel, env)


def cp_resources(module_name, main_rel):
    return cae_api.scp_generated_resources(main_rel, module_name)


def cp_all_resources(main_rel):
    return cae_api.scp_generated_resources(main_rel)

def get_cae_module_version(module_name,env):
    return cae_api.get_cae_module_version(module_name,env)

def get_deployer(env):
    return cae_api.get_deployer_server(env)

def get_config(key,env):
    return cae_api.getConfig(key,env)