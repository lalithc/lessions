import db.data as data
import urllib
import json
import Logger
import cae_api as cae

const_success = "Success"
const_warning = "Warning"
const_failed = "Failed"
const_blue = "blue"
const_green = "green"
const_cyan = "cyan"
const_critical = "Critical"

def nagio_healthcheck(module_name, env):

    moduleInfo = data.get_modules(module_name, None, None, None, env, None, None, None, None, None, None, None, None)
    moduleName = moduleInfo[module_name]
    envs = moduleName['envs']

    dict = {}

    for e in envs:

        if 'hosts' not in envs[e]:
            continue

        hosts = envs[e]['hosts']

        if (env == 'dev-main'):
            url = "http://ccrc-consul-stg2-01:8500/v1/health/checks/generic-heathcheck-"+env+"?token=2c9572d1-e49d-4d9c-834e-a2adece9fa7a"
        elif (env == 'stg1-main'):
            url = "http://ccrc-consul-stg2-01:8500/v1/health/checks/generic-heathcheck-"+env+"?token=2c9572d1-e49d-4d9c-834e-a2adece9fa7a"
        elif (env == 'lt-main'):
            url = "http://ccrc-consul-stg2-01:8500/v1/health/checks/generic-heathcheck-"+env+"?token=2c9572d1-e49d-4d9c-834e-a2adece9fa7a"
        elif (env == 'dev-rel'):
            url = "http://ccrc-consul-stg2-01:8500/v1/health/checks/generic-heathcheck-"+env+"?token=2c9572d1-e49d-4d9c-834e-a2adece9fa7a"
        elif (env == 'stg1-rel'):
            url = "http://ccrc-consul-stg2-01:8500/v1/health/checks/generic-heathcheck-"+env+"?token=2c9572d1-e49d-4d9c-834e-a2adece9fa7a"
        elif (env == 'pre-prd2'):
            url = "http://ccrc-consul-prd2-01:8500/v1/health/checks/generic-heathcheck-"+env+"?token=059eedfa-e91b-4b80-a7b5-4b59b37f5613"
        elif (env == 'pre-prd1'):
            url = "http://ccrc-consul-prd1-01:8500/v1/health/checks/generic-heathcheck-"+env+"?token=059eedfa-e91b-4b80-a7b5-4b59b37f5613"
        elif (env == 'prd2'):
            url = "http://ccrc-consul-prd2-01:8500/v1/health/checks/generic-heathcheck-"+env+"?token=059eedfa-e91b-4b80-a7b5-4b59b37f5613"
        elif (env == 'prd1'):
            url = "http://ccrc-consul-prd1-01:8500/v1/health/checks/generic-heathcheck-"+env+"?token=059eedfa-e91b-4b80-a7b5-4b59b37f5613"



        consulresponse = urllib.urlopen(url)
        consulresponsejson = json.loads(consulresponse.read())

        # Transform json input to python objects
        consulresponse_dict = consulresponsejson


        response_dict = ''
        # Filter python objects with list comprehensions
        if(module_name == 'CCRCLocalz'):
            module_name = 'CCRCLocalization'
            response_dict = [x for x in consulresponse_dict if module_name in x['Output']]
        if(module_name == 'CCRCDownload'):
            module_name = 'ccrc/download'
            response_dict = [x for x in consulresponse_dict if module_name in x['Output']]
        if(module_name == 'CCRCCommonUX'):
            response_dict = [x for x in consulresponse_dict if 'ServiceContract' in x['Output']]
        else:
            response_dict = [x for x in consulresponse_dict if module_name in x['Output']]

        # Transform python object back into json
        response_json = json.dumps(response_dict)

        # Show json

        for host in hosts:

            if response_json.find(host) == -1:
                response = "Failure, %s is down in %s " % (module_name, host)
                dict[host] = response
            else:
                serverinfo = [x for x in response_dict if host in x['Output']]
                serverinfo_json = json.dumps(serverinfo)
                temp = json.loads(serverinfo_json)
                status = temp[0]['Status']
                if status == 'critical':
                    response = "Failure " + temp[0]['Output']
                    dict[host] = response
                else:
                    response = 'Success'
                    dict[host] = response
    return dict


def cae_nagio_healthcheck(module_name, env):
    module_info = data.get_modules(module_name, None, None, None, env, None, None, None, None, None, None,None, None)
    active_color = data.get_envs(env)[env]['blue_green']
    nonactive_color = "green" if active_color == "blue" else "blue"
    module = module_info[module_name]
    service_name = module['service_name']

    project_name = cae.getNamespace(env)
    datacenter = cae.getDatacenter(env)
    token = cae.getToken(env)

    blue_url = cae.get_endpoint_url(datacenter, project_name, service_name, bgflag='b')
    green_url = cae.get_endpoint_url(datacenter, project_name, service_name, bgflag='g')
    cyan_url = cae.get_endpoint_url(datacenter, project_name, service_name, bgflag='')

    # Response from API 
    headers = {'Authorization': 'Bearer ' + token}

    description = ""

    blue_expected = None
    green_expected = None
    cyan_expected = None

    result = {'active_color': active_color}

    try:
        env_obj = module["envs"][env]

        if module['bg_enabled'] == "Y":
            status = {}
            blue_expected = get_expected_replicas(env_obj, const_blue)
            blue_actual = cae.get_actual_replicas(blue_url, headers)
            status[const_blue] = get_status(blue_expected, blue_actual, active_color == const_blue)
            if status[const_blue] != const_success:
                description = get_failed_result(description, blue_expected, blue_actual, const_blue)

            green_expected = get_expected_replicas(env_obj, const_green)
            green_actual = cae.get_actual_replicas(green_url, headers)
            status[const_green] = get_status(green_expected, green_actual, active_color == const_green)
            if status[const_green] != const_success:
                description = get_failed_result(description, green_expected, green_actual, const_green)

            result['description'] = description
            if status[active_color] == const_success:
                result['status'] = status[nonactive_color]
            else:
                result['status'] = status[active_color]
        else:
            cyan_expected = get_expected_replicas(env_obj, const_cyan)
            cyan_actual = cae.get_actual_replicas(cyan_url, headers)
            result['status'] = get_status(cyan_expected, cyan_actual, True)
            if result['status'] != const_success:
                result['description'] = get_failed_result(description, cyan_expected, cyan_actual, const_cyan)
            else:
                result['description'] = ""

        result['eman_status'] = get_eman_status(result['status'])

    except Exception as e:
        Logger.exception(e)
        result['status'] = const_warning
        result['eman_status'] = const_warning
        result['description'] = get_failed_result(description, blue_expected, 0, "Blue") + \
            get_failed_result(description, green_expected, 0, "Green") + \
            get_failed_result(description, cyan_expected, 0, "Cyan")

    return result

def apps_healthcheck(app_name, env):
    project_name = cae.getNamespace(env)
    datacenter = cae.getDatacenter(env)
    token = cae.getToken(env)
    
    url = cae.get_endpoint_url(datacenter, project_name, app_name, bgflag='')
    # Response from API 
    headers = {'Authorization': 'Bearer ' + token}
    
    description = ""
    result = {}
    try:
        app_replicas = data.get_app_replicas(app_name,env)
        app_expected_replica = app_replicas[app_name]
        
        app_actual_replica = cae.get_actual_replicas(url, headers)

        if app_actual_replica != app_expected_replica:
            if app_actual_replica == 0:
                status = const_critical
            else:
                status = const_warning
            description = get_failed_result(status, app_expected_replica, app_actual_replica, app_name)
            result['status'] = status
            result['description'] = description
        else:
            status = const_success
            result['status'] = status
    except Exception as e:
        Logger.exception(e)
        result['status'] = "Exception"
        result['description'] = "Error occred while fetching details"
        return result
        
    return result

def get_failed_result(result, expected, actual, bgtype):
    if expected is None:
        return result

    if result == "":
        result = "Failed:"

    return "%s Expected %s=%s, Actual %s=%s" % (result, bgtype, expected, bgtype, actual)


def get_expected_replicas(env_obj, blue_green):
    if blue_green == "cyan":
        return max(int(env_obj['blue_replicas']), int(env_obj['green_replicas']))
    else:
        return int(env_obj['%s_replicas' % blue_green])


def get_eman_status(actual_status):
    if actual_status in (const_success, const_warning):
        return const_success
    else:
        return const_failed


def get_status(expected, actual, is_active):
    if expected != actual:
        if is_active:
            if actual / float(expected) < 0.5:
                return const_failed
            else:
                return const_warning
        else:
            return const_warning
    else:
        return const_success
