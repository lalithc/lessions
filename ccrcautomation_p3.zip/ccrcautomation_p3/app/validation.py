import db.data as db_api
import jkapi
import re


def validate_create_submodule(module_name, module_type):
    if db_api.module_exists(module_name):
        return "Submodule %s already exists!" % module_name

    if module_type is None or module_type not in ('ui', 'nodejs', 'java'):
        return "Submodule type %s is not supported!" % module_type

    return None


def validate_update_submodule(module_name, module_type):
    if not db_api.module_exists(module_name):
        return "Submodule %s does not exists!" % module_name

    if module_type is not None and module_type not in ('ui', 'nodejs', 'java'):
        return "Submodule type %s is not supported!" % module_type

    return None


def validate_create_module(module_name, ext, module_type, service_name, jmx_port, project):
    if db_api.module_exists(module_name):
        return "Module %s already exists!" % module_name

    return validate_module("POST", module_name, ext, module_type, service_name, jmx_port, project)


def validate_update_module(module_name, ext, module_type, service_name, jmx_port, project):
    if not db_api.module_exists(module_name):
        return "Module %s does not exist!" % module_name

    return validate_module("PUT", module_name, ext, module_type, service_name, jmx_port, project)


def validate_module(request_method, module_name, ext, module_type, service_name, jmx_port, project):
    if module_name is None:
        return 'module is null!'

    if request_method == "POST" and db_api.module_exists(module_name):
        return None

    if request_method == "POST" and ext is None:
        return 'ext is null!'
    else:
        if ext is not None and ext not in ('jar', 'war', 'zip'):
            return 'ext type %s not supported!' % ext

    if service_name is not None and len(service_name) > 15:
        return 'service name %s is too long! Max character length is 15!' % service_name

    if request_method == "POST" and module_type is None:
        return 'type is null!'
    else:
        if module_type is not None and module_type not in ('tomcat', 'springboot', 'nodejs', 'nginx'):
            return 'type %s not supported!' % module_type

    if request_method == "POST" and module_type in ('tomcat', 'springboot') and jmx_port is not None:
        if not re.match(r'90\d{2}', jmx_port):
            return 'jmx_port does not match 90xx format!'

    if project is not None and project not in ('ServiceContract', 'subscriptions'):
        return 'project %s not support supported!' % project

    return None


def validate_job(module_name, server_name, env, goal, job_type):
    if module_name is None:
        return "module is null!"

    if server_name is None:
        return "server is null!"

    if job_type == "cae" and env not in ("stg2-main", "stg2-rel", "stg1-main", "stg1-rel", "stg-main", "stg-rel",
                                         "dev-main", "dev-rel", "pre-prd1", "prd1", "pre-prd2", "prd2", "prd3"):
        return "env %s is not support in cae!" % env

    if job_type != "cae" and goal == "deploy" \
            and env not in (
                    "dev-main", "stg1-main", "dev-rel", "stg-rel", "stg1-rel", "pre-prd1", "pre-prd2", "prd1", "prd2"):
        return "env %s is not supported for deployment in openstack!" % env

    if goal == "deploy" and job_type not in ("cae", "os"):
        return "job type %s is not supported!" % job_type

    if goal == "build" and env not in ("dev-main", "stg-main", "dev-rel"):
        return "env %s is not supported for build jobs!" % env

    if goal == "build_dependency" and env not in ("dev-main", "dev-rel"):
        return "env %s is not supported for build_dependency jobs!" % env

    if goal == "test" and env not in "dev-main":
        return "env %s is not supported for api tests jobs!" % env

    if not db_api.module_exists(module_name, env):
        return "Module %s does not exist in env %s!" % (module_name, env)

    return None


def validate_create_job(module_name, server_name, env, job_name, goal, job_type, data):
    msg = validate_job(module_name, server_name, env, goal, job_type)
    if msg is not None:
        return msg

    #msg = validate_hosts(module_name, goal, data, env, job_type)
    #if msg is not None:
    #    return msg

    job_exists = validate_job_exists(server_name, job_name)
    if job_exists:
        return "Job %s on server %s already exists!" % (job_name, server_name)

    return None


def validate_update_job(module_name, server_name, env, job_name, goal, job_type, data):
    msg = validate_job(module_name, server_name, env, goal, job_type)
    if msg is not None:
        return msg

    #msg = validate_hosts(module_name, goal, data, env, job_type)
    #if msg is not None:
    #    return msg

    job_exists = validate_job_exists(server_name, job_name)
    if not job_exists:
        return "Job %s on server %s does not exist!" % (job_name, server_name)

    return None


def validate_job_exists(server_name, job_name):
    print('inside validation'+str(server_name)+str(job_name))
    
    server = jkapi.get_server(server_name)
    
    job = server.get_job_name(job_name)
    if job is not None:
        return True
    else:
        return False


def validate_update_version(module_name, host_name, env, version):
    if module_name is None:
        return "module is null!"

    if version is None:
        return "version is null!"

    if env is None and host_name is None:
        return "env and host_name are null!"

    if env is not None and env not in ('stg1-rel', 'stg2-rel', 'stg1-main', 'stg2-main',
                                       'dev-main', 'dev-rel', 'lt-main', 'pre-prd1', 'pre-prd2', 'prd1', 'prd2', 'prd3'):
        return "env %s not supported!" % env

    return None


def validate_promote_version(module_name, source_env, target_env):
    if module_name is None:
        return "module is null!"

    if source_env is None:
        return "source_env is null!"

    if target_env is None:
        return "target_env is null!"

    if source_env not in ('stg-rel', 'stg-main', 'dev-main', 'dev-rel', 'lt-main', 'pre-prd'):
        return "env %s not supported for source_env!" % source_env

    if target_env not in ('stg-rel', 'stg-main', 'dev-main', 'dev-rel', 'lt-main', 'pre-prd', 'prd'):
        return "env %s not supported for target_env!" % target_env

    return None


def validate_status(module_name, env):
    if module_name is None:
        return "module is null!"

    if env is None:
        return "env is null!"

    if env not in ('stg1-rel', 'stg-rel', 'stg1-main', 'stg2-main', 'stg-main',
                   'dev-main', 'dev-rel', 'lt-main', 'prd1', 'prd2', 'prd', 'pre-prd1',
                   'pre-prd2', 'pre-prd', 'prd3'):
        return "env %s not supported!" % env

    return None


def validate_hosts(module_name, goal, data, env, job_type):
    # stg2-main is CAE, will not have any hosts
    if (job_type is not None and job_type == "cae") or goal in ("build_dependency", "test"):
        return None

    msg = 'Cannot create deploy job for module %s as it has no hosts assigned for env %s' % (module_name, env)
    envs = data[module_name]['envs']
    if goal == "deploy":
        if env == "stg-rel":
            env1 = "stg1-rel"
            if not envs.has_key(env1):
                return msg
        else:
            if not envs.has_key(env):
                return msg

    return None

def validate_update_replicas(module_name, env, blue_replicas, green_replicas):
    if module_name is None:
        return "module is null!"

    if env is None:
        return "env is null!"
    
    #TODO : update environments with current supporting CAE envs
    if env not in ('stg1-rel', 'stg2-rel', 'stg-rel', 'stg1-main', 'stg2-main', 'stg-main',
                   'dev-main', 'dev-rel', 'lt-main', 'prd1', 'prd2', 'prd', 'pre-prd1',
                   'pre-prd2', 'pre-prd', 'prd3'):
        return "env %s not supported!" % env

    if blue_replicas is None and green_replicas is None:
        return "both blue_replicas and green_replicas are null, Pass at least one replica to update!"
    
    return None
