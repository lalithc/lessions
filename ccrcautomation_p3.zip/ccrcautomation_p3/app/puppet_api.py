from pexpect import pxssh
import Logger

def ospuppetcreationjava(modulename, servicename, moduletype, minheap, maxheap, jmxport, rmiport, env,container_cpu,container_mem,httpport):

    generated_basepath = ""
    generic_basepath = ""

    if moduletype == 'tomcat' or moduletype == 'springboot':
        print modulename
        s = pxssh.pxssh()
        if not s.login ('ccrc-build-5', 'root', 'cisco999'):
            Logger.error('SSH session failed on login: %s' % str(s))
        else:
            generic_basepath = "/apps/generic-puppet/javamodule/manifests/"
            generated_basepath = "/etc/puppet/modules/%s_dc1/manifests/" % (modulename.lower())
            s.sendline ('mkdir -p ' + generated_basepath)
            s.sendline ('rm -rf '+ generated_basepath + '/*')
            s.sendline ('sed -e "s/servicename/' + modulename.lower() + '/g" -e "s/ciscodc/' + 'dc1' + '/g" '+ generic_basepath + 'init.pp  >> ' + generated_basepath +'init.pp')
            if(modulename == 'NGVSService'):
                s.sendline ('sed -e "s/servicename/' + modulename.lower() + '/g" -e "s/servicetagname/' + modulename + '/g" -e "s/ciscodc/' + 'dc1' + '/g" -e "s/rmiport/' + rmiport + '/g" -e "s/jmxport/' + jmxport + '/g" -e "s/httpport/' + str(httpport) + '/g" -e "s/modulename/' + modulename + '/g" -e "s/container_mem/' + container_mem + '/g" -e "s/container_cpu/' + container_cpu + '/g" ' + generic_basepath + 'deploy_NGVSService.pp  >> ' + generated_basepath +'deploy.pp')
            elif('SaaS' in modulename):
                 s.sendline ('sed -e "s/servicename/' + modulename.lower() + '/g" -e "s/servicetagname/' + modulename + '/g" -e "s/ciscodc/' + 'dc1' + '/g" -e "s/rmiport/' + rmiport + '/g" -e "s/jmxport/' + jmxport + '/g" -e "s/httpport/' + str(httpport) + '/g" -e "s/modulename/' + modulename + '/g" -e "s/container_mem/' + container_mem + '/g" -e "s/container_cpu/' + container_cpu + '/g" ' + generic_basepath + 'deploy_saas.pp  >> ' + generated_basepath +'deploy.pp')
            else:
                s.sendline ('sed -e "s/servicename/' + modulename.lower() + '/g" -e "s/servicetagname/' + modulename + '/g" -e "s/ciscodc/' + 'dc1' + '/g" -e "s/rmiport/' + rmiport + '/g" -e "s/jmxport/' + jmxport + '/g" -e "s/httpport/' + str(httpport) + '/g" -e "s/modulename/' + modulename + '/g" -e "s/container_mem/' + container_mem + '/g" -e "s/container_cpu/' + container_cpu + '/g" ' + generic_basepath + 'deploy.pp  >> ' + generated_basepath +'deploy.pp')
            generated_basepath = "/etc/puppet/modules/%s/manifests/" % (modulename.lower())
            generic_basepath = "/apps/generic-puppet/javamodule_dc2/manifests/"
            s.sendline ('mkdir -p ' + generated_basepath)
            s.sendline ('rm -rf '+ generated_basepath + '/*')
            s.sendline ('sed -e "s/servicename/' + modulename.lower() + '/g" '+ generic_basepath + 'init.pp  >> ' + generated_basepath +'init.pp')
            if(modulename == 'NGVSService'):
                s.sendline ('sed -e "s/servicename/' + modulename.lower() + '/g" -e "s/servicetagname/' + modulename + '/g" -e "s/ciscodc/' + 'dc2' + '/g" -e "s/rmiport/' + rmiport + '/g" -e "s/jmxport/' + jmxport + '/g" -e "s/httpport/' + str(httpport) + '/g" -e "s/modulename/' + modulename + '/g" -e "s/container_mem/' + container_mem + '/g" -e "s/container_cpu/' + container_cpu + '/g" ' + generic_basepath + 'deploy_NGVSService.pp  >> ' + generated_basepath +'deploy.pp')
            elif('SaaS' in modulename):
                 s.sendline ('sed -e "s/servicename/' + modulename.lower() + '/g" -e "s/servicetagname/' + modulename + '/g" -e "s/ciscodc/' + 'dc2' + '/g" -e "s/rmiport/' + rmiport + '/g" -e "s/jmxport/' + jmxport + '/g" -e "s/httpport/' + str(httpport) + '/g" -e "s/modulename/' + modulename + '/g" -e "s/container_mem/' + container_mem + '/g" -e "s/container_cpu/' + container_cpu + '/g" ' + generic_basepath + 'deploy_saas.pp  >> ' + generated_basepath +'deploy.pp')
            else:
                s.sendline ('sed -e "s/servicename/' + modulename.lower() + '/g" -e "s/servicetagname/' + modulename + '/g" -e "s/ciscodc/' + 'dc2' + '/g" -e "s/rmiport/' + rmiport + '/g" -e "s/jmxport/' + jmxport + '/g" -e "s/httpport/' + str(httpport) + '/g" -e "s/modulename/' + modulename + '/g" -e "s/container_mem/' + container_mem + '/g" -e "s/container_cpu/' + container_cpu + '/g" ' + generic_basepath + 'deploy.pp  >> ' + generated_basepath +'deploy.pp')
        
        s.prompt()
        s.logout()

    response = "Success"
    return response


def ospuppetcreationnode(modulename, servicename, moduletype, minheap, maxheap, jmxport, rmiport, env,container_cpu,container_mem,httpport):

    generated_basepath = ""

    if moduletype == 'nodejs':
        print modulename
        s = pxssh.pxssh()
        if not s.login ('ccrc-build-5', 'root', 'cisco999'):
            Logger.error('SSH session failed on login: %s' % str(s))
        else:
            generated_basepath = "/etc/puppet/modules/%s_dc1/manifests/" % (modulename.lower())
            generic_basepath = "/apps/generic-puppet/nodemodule/manifests/"
            s.sendline ('mkdir -p ' + generated_basepath)
            s.sendline ('rm -rf '+ generated_basepath + '/*')
            s.sendline ('sed -e "s/servicename/' + modulename.lower() + '/g" -e "s/ciscodc/' + 'dc1' + '/g" '+ generic_basepath + 'init.pp  >> ' + generated_basepath +'init.pp')
            if('SaaS' in modulename):
                s.sendline ('sed -e "s/servicename/' + modulename.lower() + '/g" -e "s/servicetagname/' + modulename + '/g" -e "s/ciscodc/' + 'dc1' + '/g" -e "s/modulename/' + modulename + '/g" -e "s/httpport/' + str(httpport) + '/g" -e "s/container_mem/' + container_mem + '/g" -e "s/container_cpu/' + container_cpu + '/g" ' + generic_basepath + 'deploy_saas.pp  >> ' + generated_basepath +'deploy.pp')
            elif(modulename == 'CCRCLocalz'):
                s.sendline ('sed -e "s/servicename/' + modulename.lower() + '/g" -e "s/servicetagname/' + modulename + '/g" -e "s/ciscodc/' + 'dc1' + '/g" -e "s/modulename/' + modulename + '/g" -e "s/httpport/' + str(httpport) + '/g" -e "s/container_mem/' + container_mem + '/g" -e "s/container_cpu/' + container_cpu + '/g" ' + generic_basepath + 'deploy_CCRCLocalz.pp  >> ' + generated_basepath +'deploy.pp')
            else: 
                s.sendline ('sed -e "s/servicename/' + modulename.lower() + '/g" -e "s/servicetagname/' + modulename + '/g" -e "s/ciscodc/' + 'dc1' + '/g" -e "s/modulename/' + modulename + '/g" -e "s/httpport/' + str(httpport) + '/g" -e "s/container_mem/' + container_mem + '/g" -e "s/container_cpu/' + container_cpu + '/g" ' + generic_basepath + 'deploy.pp  >> ' + generated_basepath +'deploy.pp')
            generated_basepath = "/etc/puppet/modules/%s/manifests/" % (modulename.lower())
            generic_basepath = "/apps/generic-puppet/nodemodule_dc2/manifests/"
            s.sendline ('mkdir -p ' + generated_basepath)
            s.sendline ('rm -rf '+ generated_basepath + '/*')
            s.sendline ('sed -e "s/servicename/' + modulename.lower() + '/g" '+ generic_basepath + 'init.pp  >> ' + generated_basepath +'init.pp')
            if('SaaS' in modulename):
                s.sendline ('sed -e "s/servicename/' + modulename.lower() + '/g" -e "s/servicetagname/' + modulename + '/g" -e "s/modulename/' + modulename + '/g" -e "s/httpport/' + str(httpport) + '/g" -e "s/container_mem/' + container_mem + '/g" -e "s/container_cpu/' + container_cpu + '/g" ' + generic_basepath + 'deploy_saas.pp  >> ' + generated_basepath +'deploy.pp')
            elif(modulename == 'CCRCLocalz'):
                s.sendline ('sed -e "s/servicename/' + modulename.lower() + '/g" -e "s/servicetagname/' + modulename + '/g" -e "s/modulename/' + modulename + '/g" -e "s/httpport/' + str(httpport) + '/g" -e "s/container_mem/' + container_mem + '/g" -e "s/container_cpu/' + container_cpu + '/g" ' + generic_basepath + 'deploy_CCRCLocalz.pp  >> ' + generated_basepath +'deploy.pp')
            else: 
                 s.sendline ('sed -e "s/servicename/' + modulename.lower() + '/g" -e "s/servicetagname/' + modulename + '/g" -e "s/modulename/' + modulename + '/g" -e "s/httpport/' + str(httpport) + '/g" -e "s/container_mem/' + container_mem + '/g" -e "s/container_cpu/' + container_cpu + '/g" ' + generic_basepath + 'deploy.pp  >> ' + generated_basepath +'deploy.pp')
        s.prompt()
        s.logout()

    response = "Success"
    return response

def ospuppetcreationjava_rel_single(modulename, moduleInfo):

    sshprompt = pxssh.pxssh()
    if not sshprompt.login ('ccrc-build-6', 'root', 'cisco999'):
        Logger.error('SSH session failed on login: %s' % str(sshprompt))
    else:
        module =  moduleInfo[modulename]
        moduletype = module['type']
        servicename = module['service_name']
        minheap = module['heap_min']
        maxheap = module['heap_max'] 
        jmxport = module['jmx_port'] 
        rmiport = module['rmi_port']
        http_port = module['http_port']
        respose = ospuppetcreationjava_rel(sshprompt,modulename, servicename, moduletype, minheap, maxheap, jmxport, rmiport,http_port)                   
    sshprompt.prompt()
    sshprompt.logout()

    return "Success"


def ospuppetcreationnode_rel_single(modulename, moduleInfo):

    sshprompt = pxssh.pxssh()
    if not sshprompt.login ('ccrc-build-6', 'root', 'cisco999'):
        Logger.error('SSH session failed on login: %s' % str(sshprompt))
    else:
        module =  moduleInfo[modulename]
        moduletype = module['type']
        servicename = module['service_name']
        minheap = module['heap_min']
        maxheap = module['heap_max'] 
        jmxport = module['jmx_port'] 
        rmiport = module['rmi_port']
        http_port = module['http_port']
        respose = ospuppetcreationnode_rel(sshprompt,modulename, servicename, moduletype, minheap, maxheap, jmxport, rmiport,http_port)   
    sshprompt.prompt()
    sshprompt.logout()

    return "Success"

def ospuppetcreationjava_rel_all(moduleInfo):

    for modulename in moduleInfo:
            generated_basepath = ""
            generic_basepath = ""
            module =  moduleInfo[modulename]
            moduletype = module['type']
            servicename = module['service_name']
            minheap = module['heap_min']
            maxheap = module['heap_max'] 
            jmxport = module['jmx_port'] 
            rmiport = module['rmi_port']
            httpport = module['http_port'] 
            if moduletype == 'tomcat' or moduletype == 'springboot':
                sshprompt = pxssh.pxssh()
                if not sshprompt.login ('ccrc-build-6', 'root', 'cisco999'):
                    Logger.error('SSH session failed on login: %s' % str(sshprompt))
                else:
                    respose = ospuppetcreationjava_rel(sshprompt,modulename, servicename, moduletype, minheap, maxheap, jmxport, rmiport,httpport)                
                sshprompt.prompt()
                sshprompt.logout()
    
    return "Success"


def ospuppetcreationnode_rel_all(moduleInfo):

    for modulename in moduleInfo:
        generated_basepath = ""
        generic_basepath = ""
        module =  moduleInfo[modulename]
        moduletype = module['type']
        servicename = module['service_name']
        minheap = module['heap_min']
        maxheap = module['heap_max'] 
        jmxport = module['jmx_port'] 
        rmiport = module['rmi_port'] 
        httpport = module['http_port'] 
        if moduletype == 'nodejs':
            sshprompt = pxssh.pxssh()
            if not sshprompt.login ('ccrc-build-6', 'root', 'cisco999'):
                Logger.error('SSH session failed on login: %s' % str(sshprompt))
            else:
                response = ospuppetcreationnode_rel(sshprompt,modulename, servicename, moduletype, minheap, maxheap, jmxport, rmiport,httpport)
            sshprompt.prompt()
            sshprompt.logout()

    return "Success"


def ospuppetcreationjava_rel(sshprompt,modulename, servicename, moduletype, minheap, maxheap, jmxport, rmiport,httpport):

    if moduletype == 'tomcat' or moduletype == 'springboot':
        print modulename
        generic_basepath = "/apps/generic-puppet/release/javamodule/manifests/"
        generated_basepath = "/etc/puppet/modules/%s_dc1/manifests/" % (modulename.lower())
        sshprompt.sendline ('mkdir -p ' + generated_basepath)
        sshprompt.sendline ('rm -rf '+ generated_basepath + '/*')
        sshprompt.sendline ('sed -e "s/servicename/' + modulename.lower() + '/g" -e "s/ciscodc/' + 'dc1' + '/g" '+ generic_basepath + 'init.pp  >> ' + generated_basepath +'init.pp')
        if(modulename == 'NGVSService'):
            sshprompt.sendline ('sed -e "s/servicename/' + modulename.lower() + '/g" -e "s/servicetagname/' + modulename + '/g" -e "s/ciscodc/' + 'dc1' + '/g" -e "s/rmiport/' + rmiport + '/g" -e "s/jmxport/' + jmxport + '/g" -e "s/httpport/' + str(httpport) + '/g" -e "s/modulename/' + modulename + '/g" ' + generic_basepath + 'deploy_NGVSService.pp  >> ' + generated_basepath +'deploy.pp')
        elif('SaaS' in modulename):
            sshprompt.sendline ('sed -e "s/servicename/' + modulename.lower() + '/g" -e "s/servicetagname/' + modulename + '/g" -e "s/ciscodc/' + 'dc1' + '/g" -e "s/rmiport/' + rmiport + '/g" -e "s/jmxport/' + jmxport + '/g" -e "s/httpport/' + str(httpport) + '/g" -e "s/modulename/' + modulename + '/g" ' + generic_basepath + 'deploy_saas.pp  >> ' + generated_basepath +'deploy.pp')
        elif('CCRCOrderConv' in modulename):
            sshprompt.sendline ('sed -e "s/servicename/' + modulename.lower() + '/g" -e "s/servicetagname/' + modulename + '/g" -e "s/ciscodc/' + 'dc1' + '/g" -e "s/rmiport/' + rmiport + '/g" -e "s/jmxport/' + jmxport + '/g" -e "s/httpport/' + str(httpport) + '/g" -e "s/modulename/' + modulename + '/g" ' + generic_basepath + 'deploy_CCRCOrderConv.pp  >> ' + generated_basepath +'deploy.pp')
        else:
            sshprompt.sendline ('sed -e "s/servicename/' + modulename.lower() + '/g" -e "s/servicetagname/' + modulename + '/g" -e "s/ciscodc/' + 'dc1' + '/g" -e "s/rmiport/' + rmiport + '/g" -e "s/jmxport/' + jmxport + '/g" -e "s/httpport/' + str(httpport) + '/g" -e "s/modulename/' + modulename + '/g" ' + generic_basepath + 'deploy.pp  >> ' + generated_basepath +'deploy.pp')
        generated_basepath = "/etc/puppet/modules/%s/manifests/" % (modulename.lower())
        generic_basepath = "/apps/generic-puppet/release/javamodule_dc2/manifests/"
        sshprompt.sendline ('mkdir -p ' + generated_basepath)
        sshprompt.sendline ('rm -rf '+ generated_basepath + '/*')
        sshprompt.sendline ('sed -e "s/servicename/' + modulename.lower() + '/g" '+ generic_basepath + 'init.pp  >> ' + generated_basepath +'init.pp')
        if(modulename == 'NGVSService'):
            sshprompt.sendline ('sed -e "s/servicename/' + modulename.lower() + '/g" -e "s/servicetagname/' + modulename + '/g" -e "s/ciscodc/' + 'dc2' + '/g" -e "s/rmiport/' + rmiport + '/g" -e "s/jmxport/' + jmxport + '/g" -e "s/httpport/' + str(httpport) + '/g" -e "s/modulename/' + modulename + '/g" ' + generic_basepath + 'deploy_NGVSService.pp  >> ' + generated_basepath +'deploy.pp')
        elif('SaaS' in modulename):
            sshprompt.sendline ('sed -e "s/servicename/' + modulename.lower() + '/g" -e "s/servicetagname/' + modulename + '/g" -e "s/ciscodc/' + 'dc2' + '/g" -e "s/rmiport/' + rmiport + '/g" -e "s/jmxport/' + jmxport + '/g" -e "s/httpport/' + str(httpport) + '/g" -e "s/modulename/' + modulename + '/g" ' + generic_basepath + 'deploy_saas.pp  >> ' + generated_basepath +'deploy.pp')
        elif('CCRCOrderConv' in modulename):
            sshprompt.sendline ('sed -e "s/servicename/' + modulename.lower() + '/g" -e "s/servicetagname/' + modulename + '/g" -e "s/ciscodc/' + 'dc2' + '/g" -e "s/rmiport/' + rmiport + '/g" -e "s/jmxport/' + jmxport + '/g" -e "s/httpport/' + str(httpport) + '/g" -e "s/modulename/' + modulename + '/g" ' + generic_basepath + 'deploy_CCRCOrderConv.pp  >> ' + generated_basepath +'deploy.pp')
        else:
            sshprompt.sendline ('sed -e "s/servicename/' + modulename.lower() + '/g" -e "s/servicetagname/' + modulename + '/g" -e "s/ciscodc/' + 'dc2' + '/g" -e "s/rmiport/' + rmiport + '/g" -e "s/jmxport/' + jmxport + '/g" -e "s/httpport/' + str(httpport) + '/g" -e "s/modulename/' + modulename + '/g" ' + generic_basepath + 'deploy.pp  >> ' + generated_basepath +'deploy.pp')
                
   
    return "Success"


def ospuppetcreationnode_rel(sshprompt,modulename, servicename, moduletype, minheap, maxheap, jmxport, rmiport,httpport):

    if moduletype == 'nodejs':
        print modulename
        generated_basepath = "/etc/puppet/modules/%s_dc1/manifests/" % (modulename.lower())
        generic_basepath = "/apps/generic-puppet/release/nodemodule/manifests/"
        sshprompt.sendline ('mkdir -p ' + generated_basepath)
        sshprompt.sendline ('rm -rf '+ generated_basepath + '/*')
        sshprompt.sendline ('sed -e "s/servicename/' + modulename.lower() + '/g" -e "s/ciscodc/' + 'dc1' + '/g" '+ generic_basepath + 'init.pp  >> ' + generated_basepath +'init.pp')
        if('SaaS' in modulename):
            sshprompt.sendline ('sed -e "s/servicename/' + modulename.lower() + '/g" -e "s/servicetagname/' + modulename + '/g" -e "s/ciscodc/' + 'dc1' + '/g" -e "s/httpport/' + str(httpport) +  '/g" -e "s/modulename/' + modulename + '/g" ' + generic_basepath + 'deploy_saas.pp  >> ' + generated_basepath +'deploy.pp')
        elif(modulename == 'CCRCLocalz'):
            sshprompt.sendline ('sed -e "s/servicename/' + modulename.lower() + '/g" -e "s/servicetagname/' + modulename + '/g" -e "s/ciscodc/' + 'dc1' + '/g" -e "s/httpport/' + str(httpport) + '/g" -e "s/modulename/' + modulename + '/g" ' + generic_basepath + 'deploy_CCRCLocalz.pp  >> ' + generated_basepath +'deploy.pp')
        else: 
            sshprompt.sendline ('sed -e "s/servicename/' + modulename.lower() + '/g" -e "s/servicetagname/' + modulename + '/g" -e "s/ciscodc/' + 'dc1' + '/g" -e "s/httpport/' + str(httpport) + '/g" -e "s/modulename/' + modulename + '/g" ' + generic_basepath + 'deploy.pp  >> ' + generated_basepath +'deploy.pp')
        generated_basepath = "/etc/puppet/modules/%s/manifests/" % (modulename.lower())
        generic_basepath = "/apps/generic-puppet/release/nodemodule_dc2/manifests/"
        sshprompt.sendline ('mkdir -p ' + generated_basepath)
        sshprompt.sendline ('rm -rf '+ generated_basepath + '/*')
        sshprompt.sendline ('sed -e "s/servicename/' + modulename.lower() + '/g" '+ generic_basepath + 'init.pp  >> ' + generated_basepath +'init.pp')
        if('SaaS' in modulename):
            sshprompt.sendline ('sed -e "s/servicename/' + modulename.lower() + '/g" -e "s/servicetagname/' + modulename + '/g" -e "s/httpport/' + httpport + '/g" -e "s/modulename/' + modulename + '/g" ' + generic_basepath + 'deploy_saas.pp  >> ' + generated_basepath +'deploy.pp')
        elif(modulename == 'CCRCLocalz'):
            sshprompt.sendline ('sed -e "s/servicename/' + modulename.lower() + '/g" -e "s/servicetagname/' + modulename + '/g" -e "s/httpport/' + httpport + '/g" -e "s/modulename/' + modulename + '/g" ' + generic_basepath + 'deploy_CCRCLocalz.pp  >> ' + generated_basepath +'deploy.pp')
        else: 
            sshprompt.sendline ('sed -e "s/servicename/' + modulename.lower() + '/g" -e "s/servicetagname/' + modulename + '/g" -e "s/httpport/' + httpport + '/g" -e "s/modulename/' + modulename + '/g" ' + generic_basepath + 'deploy.pp  >> ' + generated_basepath +'deploy.pp')
   
    return "Success"