import db.data as db_api
import puppet_api


def setup_puppet(module_name, env):
    moduleInfo = db_api.get_module(module_name)
    moduleObj = moduleInfo[module_name]
    module_type = moduleObj['type']
    service_name = moduleObj['service_name']
    min_heap = moduleObj['heap_min']
    max_heap = moduleObj['heap_max']
    jmx_port = moduleObj['jmx_port']
    rmi_port = moduleObj['rmi_port']
    container_cpu = moduleObj['container_cpu']
    container_mem = moduleObj['container_mem']
    http_port = moduleObj['http_port']

    response = ""
    if module_type in ("springboot", "tomcat"):
        if env == 'main':
            response = puppet_api.ospuppetcreationjava(module_name, service_name, module_type, min_heap, max_heap,
                                                       jmx_port, rmi_port, env, container_cpu, container_mem,http_port)
        elif env == 'rel':
            response = puppet_api.ospuppetcreationjava_rel_single(module_name, moduleInfo)
    elif module_type == "nodejs":
        if env == 'main':
            response = puppet_api.ospuppetcreationnode(module_name, service_name, module_type, min_heap, max_heap,
                                                       jmx_port, rmi_port, env, container_cpu, container_mem,http_port)
        elif env == 'rel':
            response = puppet_api.ospuppetcreationnode_rel_single(module_name, moduleInfo)
    if response == "Success":
        return "Successfully setup %s puppet for module %s in env %s " % (module_type, module_name, env)