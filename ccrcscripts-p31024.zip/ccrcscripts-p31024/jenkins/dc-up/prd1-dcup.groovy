node('Deployer') {
    try {
    
    stage 'Stage 0'    
    sh """
    #!/bin/bash
    

    ssh -t -t -t ccrccloudop@ccrc-haproxy-prd1-01 << EOF
        docker start ccrc-http2
        pkill -9 'consul-template'
        /users/ccrccloudop/consul-template -config /apps/nginx/conf/ngx.conf &
        exit 0
EOF
	ssh -t -t -t ccrccloudop@ccrc-haproxy-prd1-02 << EOF
        docker start ccrc-http2
        pkill -9 'consul-template'
        /users/ccrccloudop/consul-template -config /apps/nginx/conf/ngx.conf &
        exit 0
EOF
	ssh -t -t -t ccrccloudop@ccrc-haproxy-prd1-03 << EOF
        docker start ccrc-http2
        pkill -9 'consul-template'
        /users/ccrccloudop/consul-template -config /apps/nginx/conf/ngx.conf &
        exit 0
EOF
	ssh -t -t -t ccrccloudop@ccrc-haproxy-prd1-04 << EOF
        docker start ccrc-http2
        pkill -9 'consul-template'
        /users/ccrccloudop/consul-template -config /apps/nginx/conf/ngx.conf &
        exit 0
EOF
#	ssh ccrccloudop@ccrc-srv-prd1-03 << EOF
#       docker start ccrcb2b
#EOF
#    ssh ccrccloudop@ccrc-srv-prd1-08 << EOF
#       docker start ccrcb2b
#EOF
#	ssh ccrccloudop@ccrc-srv-prd1-15 << EOF
#       docker start ccrcb2b
#EOF
        exit 0
    """

        print("PDF Execution complete!")
    } catch (Exception e) {
        sparkSend credentialsId: '0c60e710-d3ee-4e5b-aac0-9d48100ad45f',
                message: '[$JOB_NAME]\n$BUILD_URL\nERROR: ' + e.getMessage(),
                messageType: 'text',
                spaceList: [[spaceId: 'Y2lzY29zcGFyazovL3VzL1JPT00vMDA1MWM5NTAtOTMzMS0xMWU3LTg5ZjQtZGZjYmUxMDlhMjI0',
                             spaceName: 'CCRC Jenkins Deployments']]

        throw e
    }
}
