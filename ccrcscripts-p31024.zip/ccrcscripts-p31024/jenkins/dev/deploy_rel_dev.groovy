node('master') {
    try {
        String src = ""

        def target = "CCRC_DEV"
        def module = "${MODULE}"
        def env = "${ENV}"
        def ext = "${EXT}"
        def version = "${Version}"
        def buildNo = "${ReleaseNo}"
        def hosts = "${HOSTS}"
        def repoServer = "ccrc-build-docker-04:5000"

        versionFull = "$version-R$buildNo"

        def buildArg = "$module"

        stage 'Stage 0'
        def moduleLower = module.toLowerCase()
        def docker_dir = "/apps/automated-dockerfiles/generatedmodules/os/"
        //def docker_dir = "/apps/dockerfiles/"
        def puppet_server = "ccrc-build-6.cisco.com"

        sh """
       #!/bin/bash

        rm -rf $docker_dir$module-ps/$module.$ext
        if [ -d $docker_dir$module-ps/$module ]; then
          rm -rf $docker_dir$module-ps/$module
        fi

        if [ -d $docker_dir$module-ps/configs/$module-ps ]; then
          rm -rf $docker_dir$module-ps/configs/$module-ps
        fi

        wget --output-document=$docker_dir$module-ps/$module.$ext http://ccrc-build-7.cisco.com/repodata/repo/$module/$module.$ext
    
        docker build --build-arg moduleName=$buildArg -t $repoServer/$moduleLower:$versionFull --pull=true $docker_dir$module-ps/
        docker push $repoServer/$moduleLower:$versionFull

        docker rmi $repoServer/$moduleLower:$versionFull
        rm -rf $docker_dir$module-ps/$module.$ext

        exit 0
    """

        stage 'Stage 0.1'
        checkout scm
        def relMgr = load("jenkins/rel_mgr.groovy")
        relMgr(module,src,target,env,versionFull)

        stage 'Stage 0.2'
        def hostList = hosts.split(",")

        def puppet = load("jenkins/puppet_apply.groovy")
        for(i = 0; i < hostList.size(); i++) {
            def host = hostList[i]

            stage "Stage $host"
            puppet(host, moduleLower, puppet_server, "ccrc_dev", "ccrccloudop")
        }
    } catch (Exception e) {
        sparkSend credentialsId: '0c60e710-d3ee-4e5b-aac0-9d48100ad45f',
                message: '[$JOB_NAME]\n$BUILD_URL\nERROR: ' + e.getMessage(),
                messageType: 'text',
                spaceList: [[spaceId: 'Y2lzY29zcGFyazovL3VzL1JPT00vM2U3YjMyNTAtYTBiNy0xMWU3LTkxZmQtMTE2Nzc2Njg4MWU0',
                             spaceName: 'CCRC Jenkins Release Deployments']]

        throw e
    }
}