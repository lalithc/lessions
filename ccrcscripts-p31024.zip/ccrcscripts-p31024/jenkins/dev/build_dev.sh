#!/bin/bash

if [ $# -ne 5 ]; then
  echo "Not enough arguments! Required: [module] [env] [ext] [version] [buildNo]"
  exit 1
fi

module=$1
env=$2
ext=$3
version=$4
buildNo=$5

deployServer="ccrc-nprd-docker-build"


moduleLower=$(echo "$module" | tr '[:upper:]' '[:lower:]')
moduleEnv="$module-main"
moduleEnvLower="$moduleLower-main"

package="/var/jenkins_home/workspace/${moduleEnv}/target/${moduleEnv}.${ext}"
if [ ! -f ${package} ]; then
    echo "Build target package does not exist! ${package}"
    echo "Failing build!"
    exit 1
else
    target="/a/repo/${module}/${moduleEnv}.${ext}"
    if [ ! -d ${target} ]; then
        mkdir -p /a/repo/${module}
    fi

    echo "Copying ${package} to ${target}"
    scp ${package} ${target}

    echo "Running chmod 755 on ${target}"
    chmod 755 "/a/repo/${module}"
    chmod 755 ${target}
    if [[ ${module} == "CCRCDownload" ]]; then
        target2=/a/repo/CCRCDownloadNginx/CCRCDownloadNginx-main.${ext}
        if [ ! -d ${target2} ]; then
            mkdir -p /a/repo/CCRCDownloadNginx
        fi
        scp ${package} ${target2}
        chmod 755 ${target2}
    fi
    #if [[ (${module} == "CCRCCommonUX") || (${module} == "CCRCSaaSUI") ]]; then
    #    target2=/a/repo/${module}Landing/${module}Landing-main.${ext}
    #    if [ ! -d ${target2} ]; then
    #        mkdir -p /a/repo/${module}Landing
    #    fi
    #    scp ${package} ${target2}
    #    chmod 755 ${target2}
    #fi
fi

echo "Triggering build jobs for module $moduleEnv with version ${version}-${buildNo} on server $deployServer"
hdr="jenkinsapi:a485dabedf0743de305098ea5f963cd8"

url2="http://ccrc-nprd-docker-build:8080/job/${module}-main-Dev-CAE/buildWithParameters?token=${moduleLower}-main&Version=$version&ReleaseNo=$buildNo"
echo "CAE Job: $url2"
curl -f --user "$hdr" "$url2"

if [[ ${module} == "CCRCDownload" ]]; then

    url4="http://ccrc-nprd-docker-build:8080/job/CCRCDownloadNginx-main-Dev-CAE/buildWithParameters?token=ccrcdownloadnginx-main&Version=$version&ReleaseNo=$buildNo"
    echo "CAE Job: $url4"
    curl -f --user "$hdr" "$url4"
fi
#if [[ (${module} == "CCRCCommonUX") || (${module} == "CCRCSaaSUI") ]]; then
#    url4="http://ccrc-nprd-docker-build:8080/job/${module}Landing-main-Dev-CAE/buildWithParameters?token=${moduleLower}landing-main&Version=$version&ReleaseNo=$buildNo"
#    echo "CAE Job: $url4"
#    curl -f --user "$hdr" "$url4"
#fi
