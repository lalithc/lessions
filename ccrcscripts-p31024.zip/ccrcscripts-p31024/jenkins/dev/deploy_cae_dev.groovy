node('master') {
    try {
        def module = "${MODULE}"
        def servicename = "${SERVICENAME}"
        def env = "${ENV}"
        def version = "${Version}"
        def buildNo = "${ReleaseNo}"
        def ext = "${EXT}"
        def buildsrvr = "${BUILD_SRVR}"
        def deploysrver = "${DOCKER_NPRD_SRVR}"
        def automationsrvr = "${AUTOMATION_SRVR}"

        String generated_dir = "/apps/ccrckubernetes_generated"
        stage 'Stage 0'

        checkout scm
        def api = load("jenkins/api.groovy")
        def envObj = api.getEnvs(env,automationsrvr)
        def deployerNode = api.getDeployer(automationsrvr,"5000",env)
        def data = api.getModuleData(module,automationsrvr)
        def build_image = load("jenkins/util/build_image_cae.groovy")
        def deployer = load("jenkins/util/deploy_cae.groovy")
        String versionFull = build_image(generated_dir, module, servicename, env, version, buildNo, ext, buildsrvr)
        def replicas = data['envs'][env]['replicas']

        String bgtype
        if(data['bg_enabled'] == 'N') {
            bgtype = "cyan"
        } else {
            bgtype = envObj['blue_green']
        }

        node("$deployerNode") {
            checkout scm
            deployer(module, 'dev-main', versionFull, servicename, bgtype, replicas,automationsrvr)
        }

        def update_version = load("jenkins/util/update_version.groovy")
        update_version(module, env, versionFull,automationsrvr)
		jenkinsToken='691b0016b910b43b123dc75daff05e9b'
        if (module == "CCRCCommonUX") {
            job_url = "$buildsrvr:8080/job/ViewUIUnitTesting-Master/build?token=viewuitesting"
            stage "trigger ViewUIUnitTesting-Master"
            result = ['bash', '-c', "curl -u jenkinsapi:'$jenkinsToken' -f '$job_url'"].execute().text
            print(result)
        } else {
            def moduleLower = module.toLowerCase()
            stage "Trigger Stage Promotion"
            job_url = "$buildsrvr:8080/job/Promote_$module-MAIN/build?token=$moduleLower"
            result = ['bash', '-c', "curl -u jenkinsapi:'$jenkinsToken' -f '$job_url'"].execute().text
            print(result)
        }
    } catch (Exception e) {
        sparkSend credentialsId: 'a3240800-4aba-48b0-888b-e5db5997633a',
                message: '[$JOB_NAME]\n$BUILD_URL\nERROR: ' + e.getMessage(),
                messageType: 'text',
                spaceList: [[spaceId: 'Y2lzY29zcGFyazovL3VzL1JPT00vMDA1MWM5NTAtOTMzMS0xMWU3LTg5ZjQtZGZjYmUxMDlhMjI0',
                             spaceName: 'CCRC Jenkins Deployments']]

        throw e
    }
}
