node('master') {
    try {
        String src = ""

        def target = "CCRC_DEV"
        def module = "${MODULE}"
        def env = "${ENV}"
        def ext = "${EXT}"
        def version = "${Version}"
        def buildNo = "${ReleaseNo}"
        def hosts = "${HOSTS}"
        def repoServer = "ccrc-build-docker-04:5000"

        String main = ""
        String release = ""
        String versionFull = ""
        String target2 = ""

        if(env == "dev-main") {
            main = "-main"
            versionFull = "$version-$buildNo"
            target2 = "CCRC_ABT"
        } else if(env == "dev-rel") {
            release = "-ps"
            versionFull = "$version-R$buildNo"
        }

        def buildArg = "$module$main"
        if(ext == "war") {
            buildArg = module
        }

        stage 'Stage 0'
        def moduleLower = module.toLowerCase()
        def docker_dir = "/apps/automated-dockerfiles/generatedmodules/os/"

        sh """
           #!/bin/bash
    
            rm -rf $docker_dir$module$main$release/$module$main.$ext
            if [ -d $docker_dir$module$main$release/$module$main ]; then
              rm -rf $docker_dir$module$main$release/$module$main
            fi
    
            if [ -d $docker_dir$module$main$release/configs/$module$main$release ]; then
              rm -rf $docker_dir$module$main$release/configs/$module$main$release
            fi
    
            wget --output-document=$docker_dir$module$main$release/$module$main.$ext http://ccrc-build-7.cisco.com/repodata/repo/$module/$module$main.$ext
        
            docker build --build-arg moduleName=$buildArg -t $repoServer/$moduleLower:$versionFull --pull=true $docker_dir$module$main$release/
            docker push $repoServer/$moduleLower:$versionFull
    
            docker rmi $repoServer/$moduleLower:$versionFull
            rm -rf $docker_dir$module$main$release/$module$main.$ext
    
            exit 0
        """

        stage 'Stage 0.1'
        checkout scm
        def relMgr = load("jenkins/rel_mgr.groovy")
        relMgr(module,src,target,env,versionFull)
        relMgr(module,src,target2,env,versionFull)

        stage 'Stage 0.2'
        def hostList = hosts.split(",")

        def puppet = load("jenkins/puppet_apply.groovy")
        for(i = 0; i < hostList.size(); i++) {
            def host = hostList[i]

            stage "Stage $host"
            puppet(host, moduleLower, "ccrc-build-5.cisco.com", "ccrc_dev", "ccrccloudop")
        }

        if (module == "CCRCCommonUX") {
            job_url = "ccrc-build-7.cisco.com:8080/jenkins/job/ViewUIUnitTesting-Master/build?token=viewuitesting"
            stage "trigger ViewUIUnitTesting-Master"
            result = ['bash', '-c', "curl -f '$job_url'"].execute().text
            print(result)
        } else {
            stage "Trigger Stage Promotion"
            sleep(40 as long)
            job_url = "ccrc-build-7.cisco.com:8080/jenkins/job/Promote_$module-MAIN/build?token=$moduleLower"
            result = ['bash', '-c', "curl -f '$job_url'"].execute().text
            print(result)
        }
    } catch (Exception e) {
        sparkSend credentialsId: 'a3240800-4aba-48b0-888b-e5db5997633a',
                message: '[$JOB_NAME]\n$BUILD_URL\nERROR: ' + e.getMessage(),
                messageType: 'text',
                spaceList: [[spaceId: 'Y2lzY29zcGFyazovL3VzL1JPT00vMDA1MWM5NTAtOTMzMS0xMWU3LTg5ZjQtZGZjYmUxMDlhMjI0',
                             spaceName: 'CCRC Jenkins Deployments']]

        throw e
    }
}