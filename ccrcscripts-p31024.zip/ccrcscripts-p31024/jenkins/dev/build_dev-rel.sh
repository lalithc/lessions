#!/bin/bash

if [ $# -ne 4 ]; then
  echo "Not enough arguments! Required: [module] [env] [ext] [version] [buildNo]"
  exit 1
fi

module=$1
ext=$2
version=$3
buildNo=$4

deployServer="ccrc-prd-docker-build.cisco.com"

moduleLower=$(echo "$module" | tr '[:upper:]' '[:lower:]')
moduleEnv="$module-rel"
moduleEnvLower="$moduleLower-rel"

package="/var/jenkins_home/workspace/${moduleEnv}/target/${module}.${ext}"
target="/a/repo/${module}/${module}.${ext}"

if [ ! -f ${package} ]; then
    echo "Build target package does not exist! ${package}"
    echo "Failing build!"
    exit 1
else
    if [ ! -d ${target} ]; then
        mkdir -p /a/repo/${module}
    fi

    echo "Copying ${package} to ${target}"
    scp ${package} ${target}

    echo "Running chmod 755 on ${target}"
    chmod 755 ${target}
    #if [[ ${module} == "CCRCDownload" ]]; then
    #    target2=/a/repo/CCRCDownloadNginx/CCRCDownloadNginx.${ext}
    #    if [ ! -d ${target2} ]; then
    #        mkdir -p /a/repo/CCRCDownloadNginx
    #    fi
    #    scp ${package} ${target2}
    #    chmod 755 ${target2}
    #fi
fi

echo "Triggering build jobs for module $moduleEnv with version ${version}-${buildNo} on server $deployServer"

url1="http://$deployServer:8080/job/$module-rel-Dev/buildWithParameters?token=$moduleEnvLower&Version=$version&ReleaseNo=$buildNo"
echo "OpenStack Job: $url1"
curl -f "$url1"

url2="http://$deployServer:8080/job/$module-rel-Dev-CAE/buildWithParameters?token=$moduleEnvLower&Version=$version&ReleaseNo=$buildNo"
echo "CAE Job: $url2"
curl -f "$url2"

if [[ ${module} == "CCRCDownload" ]]; then
#    url3="http://$deployServer:8080/job/CCRCDownloadNginx-rel-Dev/buildWithParameters?token=ccrcdownloadnginx-ps&Version=$version&ReleaseNo=$buildNo"
#    echo "OpenStack Job: $url3"
#    curl -f "$url3"

    url4="http://$deployServer:8080/job/CCRCDownloadNginx-rel-Dev-CAE/buildWithParameters?token=ccrcdownloadnginx-rel&Version=$version&ReleaseNo=$buildNo"
    echo "CAE Job: $url2"
    curl -f "$url4"
fi
