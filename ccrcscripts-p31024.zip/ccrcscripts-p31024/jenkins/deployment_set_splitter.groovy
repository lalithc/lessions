class DeploymentSetSplitter implements Serializable {
    static def map_module_host_maps(modules, env, exclusion_list) {
        def host_modules = [:]
        def module_hosts = [:]

        for (kv in mapToList(modules)) {
            def m = kv[0].toString()
            def module = kv[1]

            // Skip any modules on the exclusion list
            if (exclusion_list.contains(m.toLowerCase()) || module['envs'][env]['hosts'] == null) {
                continue
            }

            String[] hosts = module['envs'][env]['hosts']
            for (int i = 0; i < hosts.size(); i++) {
                def h = hosts[i].toString()
                addToMapList(host_modules, h, m)
                addToMapList(module_hosts, m, h)
            }
        }

        def maps = [:]
        maps["module_hosts"] = module_hosts
        maps["host_modules"] = host_modules

        return maps
    }

    static def split_into_sets(def module_hosts, def host_modules) {
        def allocated_modules_map = [:]
        def allocated_hosts_map = [:]

        def unallocated_modules_map = [:]
        def unallocated_hosts_map = [:]

        def missing_modules = []

        for ( kv in mapToList (module_hosts) ) {
            def m = kv[0].toString()
            def module_per_vm_limit = getModuleFirstPassLimit(module_hosts[m].size())
            String[] hosts = kv[1]

            for (int i = 0; i < hosts.size(); i++) {
                def h = hosts[i]
                def first_pass_size = getFirstPassSize(host_modules[h].size())

                if (!allocated_modules_map.containsKey(m) || allocated_modules_map[m].size() < module_per_vm_limit) {
                    if (!allocated_hosts_map.containsKey(h)) {
                        allocated_hosts_map[h] = [m]
                        addToMapList(allocated_modules_map, m, h)
                        continue
                    } else if (allocated_hosts_map[h].size() < first_pass_size) {
                        allocated_hosts_map[h].add(m)
                        addToMapList(allocated_modules_map, m, h)
                        continue
                    }
                }

                addToMapList(unallocated_hosts_map, h, m)
                addToMapList(unallocated_modules_map, m, h)
            }

            if (!allocated_modules_map.containsKey(m)) {
                missing_modules.add(m)
            }
        }

        for (int i = 0; i < missing_modules.size(); i++) {
            def m = missing_modules[i].toString()
            String[] available_hosts = unallocated_modules_map[m]

            def min_allocated_host = available_hosts[0].toString()
            def min_allocated_value = 99

            for (int x = 0; x < available_hosts.size(); x++) {
                def h = available_hosts[x]
                def second_pass_host_size = getSecondPassSize(host_modules[h].size())
                def second_pass_modules_count = getSecondPassSize(module_hosts[m].size())
                def allocated_hosts_count = allocated_hosts_map[h].size()
                if (allocated_hosts_count < second_pass_host_size &&
                        (!allocated_modules_map.containsKey(m) || allocated_modules_map[m].size() < second_pass_modules_count)) {
                    addToMapList(allocated_modules_map, m, h)
                    allocated_hosts_map[h].add(m)
                    unallocated_modules_map[m].removeElement(h)
                    unallocated_hosts_map[h].removeElement(m)
                } else {
                    if (min_allocated_value > allocated_hosts_count) {
                        min_allocated_value = allocated_hosts_count
                        min_allocated_host = h
                    }
                }

                if (x + 1 == available_hosts.size() && !allocated_modules_map.containsKey(m)) {
                    allocated_hosts_map[min_allocated_host].add(m)
                    addToMapList(allocated_modules_map, m, min_allocated_host)
                    unallocated_modules_map[m].removeElement(min_allocated_host)
                    unallocated_hosts_map[min_allocated_host].removeElement(m)
                }
            }
        }

        def sets = [:]
        sets["1"] = allocated_hosts_map
        sets["2"] = unallocated_hosts_map

        return sets
    }

    static def getFirstPassSize(def num_modules_on_host) {
        return (num_modules_on_host / 2 as double).round() - 1
    }

    static def getSecondPassSize(def num_modules_on_host) {
        return (num_modules_on_host / 2 as double).round()
    }

    static def getModuleFirstPassLimit(def num_modules_in_env) {
        return (num_modules_in_env / 2 as double).round()
    }

    static def addToMapList(def map, def key, def value) {
        if (map.containsKey(key)) {
            map[key].add(value)
        } else {
            map[key] = [value]
        }
    }

    static List<List<?>> mapToList(Map map) {
        return map.collect { it ->
            [it.key, it.value]
        }
    }
}

return new DeploymentSetSplitter()
