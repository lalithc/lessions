def call(String host) {
    sh """
    #!/bin/bash
        ssh -t -t -t ccrccloudop@${host} <<EOF
        docker kill -s HUP haproxy
        exit 0
EOF
    exit 0
    """
}

return this