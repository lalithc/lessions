def call(String env) {
    String reltype

    switch (env) {
        case ~/^.+-main$/:
            reltype = "main"
            break
        case ~/^.*(-rel|prd\d*)$/:
            reltype = "rel"
            break
        default:
            reltype = ""
    }

    return reltype
}

return this