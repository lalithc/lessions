def env = "${ENV}"

node('master') {
    stage 'Stage Checkout'
    checkout scm

    def api = load("jenkins/api.groovy")
    def hotfix_enable_disable = load("jenkins/util/hotfix_enable_disable.groovy")
    current_hotfix_flag = api.getEnvs(env)['hotfix_enabled']

    String desired_hotfix_flag
    if(current_hotfix_flag == "Y") {
        desired_hotfix_flag = "N"
    } else {
        desired_hotfix_flag = "Y"
    }
    stage "Hotfix enabled $desired_hotfix_flag env $env"
    hotfix_enable_disable(env, desired_hotfix_flag)
}


