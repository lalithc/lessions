import groovy.json.JsonOutput

def call(String module, String sourceEnv, String targetEnv,String automationsrvr) {
    def body = [:]
    body.put("module", module)
    body.put("source_env", sourceEnv)
    body.put("target_env", targetEnv)
    def json = JsonOutput.toJson(body)

    String result = ['bash', '-c', "curl -X PUT '$automationsrvr:5000/module/promote_version' -d '$json'"].execute().text

    print("Promote Version result: $result")

    //def rel_mgr = load("jenkins/rel_mgr.groovy")
    //rel_mgr(module, resolveNewToOldEnv(sourceEnv), resolveNewToOldEnv(targetEnv), targetEnv, null)

    return result
}

def resolveNewToOldEnv(String newEnv) {
    switch(newEnv) {
        case 'lt-main':
            return "CCRC_LT"
        case ~/dev.+/:
            return "CCRC_DEV"
        case ~/stg.+/:
            return "CCRC_STAGE"
        case ~/.+prd.+/:
            return "CCRC_PROD"
    }
}

return this
