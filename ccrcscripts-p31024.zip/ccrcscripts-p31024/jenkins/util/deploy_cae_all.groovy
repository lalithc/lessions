def call(def modules, String taskNode, String env, String bgtype, String automationsrvr) {
    def deploys = [:]
    def deployer = load("jenkins/util/deploy_cae.groovy")

    for(kv in mapToList(modules)) {
        envObj = kv[1]['envs'][env]
        if(envObj != null && envObj['version'] != null) {
            def module = kv[0].toString()
            def service_name = kv[1]['service_name']
            def version = envObj['version']

            // initially deploy at 2/3 capacity
            def replicas = (envObj['replicas'].toString().toInteger() * 0.667 as double).round()
            if(kv[1]['bg_enabled'] == "Y") {
                deploys["${module}"] = {
                    node("${taskNode}") {
                        checkout scm
                        deployer(module, env, version, service_name, bgtype, replicas,automationsrvr)
                    }
                }
            }
        }
    }

    return deploys
}

static List<List<?>> mapToList(Map map) {
    return map.collect { it ->
        [it.key, it.value]
    }
}

return this
