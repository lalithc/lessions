node("${NODE}") {
    env = "${ENV}"
    project = "${PROJECT}"
    time = "${TIMEOUT_TIME}"

    checkout scm
    api = load("jenkins/api.groovy")
    modules = api.getCAEModules(env, "")

    for(kv in mapToList(modules)) {
        serviceName = kv[1]['service_name']

        try {
            sh """
                oc annotate route bg$serviceName -n $project --overwrite haproxy.router.openshift.io/timeout=$time
            """
        } catch(Exception e) {
            print("Error annotating service $serviceName: $e")
        }
    }
}

static List<List<?>> mapToList(Map map) {
    return map.collect { it ->
        [it.key, it.value]
    }
}