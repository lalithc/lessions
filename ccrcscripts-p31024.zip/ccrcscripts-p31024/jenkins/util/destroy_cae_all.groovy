def call(def modules, String taskNode, String env, String bgtype, count = 0) {
    def destroys = [:]
    def destroyer = load("jenkins/util/destroy_cae.groovy")

    for(kv in mapToList(modules)) {
        envObj = kv[1]['envs'][env]
        if(envObj != null && envObj['version'] != null) {
            def module = kv[0].toString()
            def service_name = kv[1]['service_name']

            if(kv[1]['bg_enabled'] == "Y") {
                destroys["${module}"] = {
                    node("${taskNode}") {
                        destroyer(module, service_name, env, bgtype, count)
                    }
                }
            }
        }
    }


    return destroys
}

static List<List<?>> mapToList(Map map) {
    return map.collect { it ->
        [it.key, it.value]
    }
}

return this
