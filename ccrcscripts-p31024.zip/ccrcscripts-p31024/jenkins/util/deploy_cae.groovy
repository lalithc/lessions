def call(String module, String env, String version, String servicename, String bgtype, def replicas,String automationsrvr) {
    def main_or_rel = load("jenkins/util/main_or_rel.groovy")

    try {
        String base_envs = "/apps/environments"
        String generated_dir = "/apps/ccrckubernetes_generated"
        String namespace = getNamespace(env)
        String normalized_env = getNormalizedEnv(env)
        String normalized_cae_env = getCAEEnv(normalized_env)
        String cae_env = getCAEEnv(env)
        String versionFolder = "$base_envs/$normalized_cae_env"
        String main_rel = main_or_rel(env)

        String bgflag
        String bgstring
        String ccrchost

        if(bgtype == 'blue') {
            bgflag = 'b'
            bgstring = '-blue'
            ccrchost = "b${normalized_cae_env}haproxy"
        } else if(bgtype == 'green') {
            bgflag = 'g'
            bgstring = '-green'
            ccrchost = "g${normalized_cae_env}haproxy"
        } else {
            bgflag = ''
            bgstring = ''
            ccrchost = ''
        }

        String deploy_config = "deployconfig${bgstring}-${cae_env}"

        // Copy generated config to environments folder and set version to be latest
        sh """
        #!/bin/bash
        
        mkdir -p ${versionFolder}/${module}
        rm -f ${versionFolder}/${module}/deployconfig${bgstring}.yaml
        rm -f ${versionFolder}/${module}/${deploy_config}.yaml
        sed -e "s/serviceversion/${version}/" -e "s/ccrchost/${ccrchost}/" -e "s/svcreplica/${replicas}/" $generated_dir/${module}-${main_rel}/deployconfig-template-${cae_env}${bgstring}.yaml >> ${versionFolder}/${module}/${deploy_config}.yaml
        
        if ! oc get deploymentconfig $bgflag$servicename -n ${namespace} ; then
            oc create -f ${versionFolder}/${module}/${deploy_config}.yaml -n ${namespace}
        else
            oc replace -f ${versionFolder}/${module}/${deploy_config}.yaml -n ${namespace}
        fi
        """

        // Force deployment even if image did not change
        try {
            sh """ 
            oc rollout latest dc/$bgflag$servicename -n ${namespace} 
            oc rollout latest dc/$bgflag$servicename -n ${namespace} 
            oc rollout latest dc/$bgflag$servicename -n ${namespace} 
            oc rollout latest dc/$bgflag$servicename -n ${namespace} 
            oc rollout latest dc/$bgflag$servicename -n ${namespace} 
            oc rollout latest dc/$bgflag$servicename -n ${namespace} 
            """
        } catch(Exception ignored) {
            // Ignore error
        }

        // Check status of deployment and wait until complete
        //sh """
        //sleep 2s
        //oc rollout status dc/$bgflag$servicename -n ${namespace}
        //"""
        int count = 0
        while(true) {
         try {
          	sh """
        	sleep 2s
        	oc rollout status dc/$bgflag$servicename -n ${namespace}
        	"""
            break;
    	} catch(hudson.AbortException ex) {
           println(ex)
           if(count++ == 4){
             throw ex
           }
         }
      	}

        if(replicas != null) {
            if(bgtype == "blue") {
                setBlueReplicas(module, env, replicas,automationsrvr)
            } else {
                setGreenReplicas(module, env, replicas,automationsrvr)
            }
        }

        if(normalized_cae_env == "prd") {
            print(pushToCDA(module, version))
        }
   } catch(Exception e) {
        sparkSend credentialsId: '0c60e710-d3ee-4e5b-aac0-9d48100ad45f',
                message: '[$JOB_NAME]\n$BUILD_URL\nERROR: ' + bgtype + ' deployment of module ' + module +
                ' with version ' + version + ' has failed! ' + e.getMessage(),
                messageType: 'text',
                spaceList: [[spaceId: 'Y2lzY29zcGFyazovL3VzL1JPT00vM2U3YjMyNTAtYTBiNy0xMWU3LTkxZmQtMTE2Nzc2Njg4MWU0',
                             spaceName: 'CCRC Jenkins Release Deployments']]

        throw e
    }
}

static def getNamespace(String env) {
    switch(env) {
        case "stg2-rel":
            return "ccwr-stage-rel"
        case "stg1-rel":
            return "ccwr-stage-rel"
        case "stg2-main":
            return "ccwr-stage"
        case "stg1-main":
            return "ccwr-stage"
        case "dev-main":
            return "ccwr-dev"
        case "dev-rel":
            return "ccwr-dev-rel"
        case "lt-main":
            return "ccwr-lt"
        case ~/^pre-prd\d$/:
            return "ccwr-prepd"
        case ~/^prd\d$/:
            return "ccwr-prod"
    }
}

static def getCAEEnv(String env) {
    return env.replace("-", "")
}

static def getNormalizedEnv(String env) {
    return env.replaceFirst(/[1-9]/, "")
}

static def setGreenReplicas(String module, String env, def green_replicas,String automationsrvr) {
    print(setReplicas(module, env, null, green_replicas,automationsrvr))
}

static def setBlueReplicas(String module, String env, def blue_replicas,String automationsrvr) {
    print(setReplicas(module, env, blue_replicas, null,automationsrvr))
}

static def pushToCDA(String module, String versionFull) {
    String url = "https://dftapi.cisco.com/code/cda/event-proxy/v2/software/custom-deployment-event"
    String moduleLower = module.toLowerCase()
    String baseVersion = versionFull.replaceFirst(/-\d+$/,"")
    String branch = "ccrc-$baseVersion"
    String git_url = "https://git@gitscm.cisco.com/scm/ccwren/${moduleLower}.git"
    String json = "{\"scmUrl\": \"$git_url\", \"scmBranch\": \"$branch\",\"environmentName\": \"prod\",\"releaseName\":\"$baseVersion\",\"version\":\"$versionFull\"}"

    def text = ['bash', '-c', "curl -X POST '$url' -d '$json' -H 'Content-Type: application/json'"].execute().text
    return text
}

static def setReplicas(String module, String env, def blue_replicas, def green_replicas,String automationsrvr) {
    String replicas_json = blue_replicas != null ? "\"blue\":\"$blue_replicas\"" : "\"green\":\"$green_replicas\""

    def text = ['bash', '-c', "curl -X PUT '$automationsrvr:5000/cae/update_replicas' -d '{\"module\":\"$module\", \"env\":\"$env\", $replicas_json}'"].execute().text
    return text
}

return this
