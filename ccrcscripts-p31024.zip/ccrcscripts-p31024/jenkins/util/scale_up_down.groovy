try {
    def env = "${ENV}"
    def deploy_node = "${NODE}"
    def deploysrver = "${DOCKER_NPRD_SRVR}"

    node("${deploy_node}") {
        stage 'Stage Checkout'
        checkout scm

        def api = load("jenkins/api.groovy")
        def scale_all = load("jenkins/util/scale_all_replica.groovy")
        def modules = api.getCAEModules(env,"")
        String bgtype = api.getEnvs(env)['blue_green']

        String non_bg
        if(bgtype == "blue") {
            non_bg = "green"
        } else {
            non_bg = "blue"
        }
        // Scale down
        scale_down = scale_all(modules, deploy_node, env, non_bg, false,deploysrver)
        parallel scale_down

        // Scale up
        scale_up = scale_all(modules, deploy_node, env, bgtype, true,deploysrver)
        parallel scale_up
    }

} catch(Exception e) {
    sparkSend credentialsId: '0c60e710-d3ee-4e5b-aac0-9d48100ad45f',
            message: '[$JOB_NAME]\n$BUILD_URL\nERROR: ' + e.getMessage(),
            messageType: 'text',
            spaceList: [[spaceId: 'Y2lzY29zcGFyazovL3VzL1JPT00vM2U3YjMyNTAtYTBiNy0xMWU3LTkxZmQtMTE2Nzc2Njg4MWU0',
                         spaceName: 'CCRC Jenkins Release Deployments']]

    throw e
}
