def call(String route_name, String haproxy_name, String env, String bgtype, String deploysrver) {
    String namespace = getNamespace(env)

    if (bgtype == "blue") {
        sh """
        oc set route-backends $route_name b$haproxy_name=100 g$haproxy_name=0 -n $namespace
        """
    } else if(bgtype == "green") {
        sh """
        oc set route-backends $route_name b$haproxy_name=0 g$haproxy_name=100 -n $namespace
        """
    } else {
        throw new Exception("Invalid input!")
    }

    def cmd = setCCRCAPIRoute(namespace, bgtype)
    sh """
    $cmd
    """

    def cmd2 = setNginxRoute(namespace, bgtype)
    sh """
    $cmd2
    """

    def cmd3 = setGSLBRoute(namespace, bgtype)
    sh """
    $cmd3
    """

    def cmd4 = setSaaSWebRoute(namespace, bgtype)
    sh """
    $cmd4
    """

    def cmd5 = setSaaSSvcRoute(namespace, bgtype)
    sh """
    $cmd5
    """

    setBlueGreen(env, bgtype,deploysrver)
}

static def setBlueGreen(String env, String blue_green, String deploysrver) {
    def text = ['bash', '-c', "curl -X PUT '$deploysrver:5000/env/$env' -d '{\"blue_green\":\"$blue_green\",\"hotfix_enabled\":\"Y\"}'"].execute().text
    return text
}

static def getNamespace(String env) {
    switch(env) {
        case "stg2-rel":
            return "ccrc-stgrel"
        case "stg1-rel":
            return "ccrc-stgrel1"
        case "stg2-main":
            return "ccrc-stage"
        case "lt-main":
            return "ccrc-lt"
        case ~/pre-prd\d/:
            return "ccrc-prepd"
        case ~/prd\d/:
            return "ccrc-prod"
    }
}

static def setCCRCAPIRoute(String namespace, String bgtype) {
    String gweight = "0"
    String bweight = "0"
    if(bgtype == "green") {
        gweight = "100"
    } else {
        bweight = "100"
    }

    String route_name
    switch (namespace) {
        case "ccrc-prod":
            route_name = "bgccrcapi"
            break
        case ~/ccrc-stgrel\d*/:
            route_name = "bgccrcapi"
            break
        default:
            route_name = "bgccrcapi"
    }

    return "oc set route-backends $route_name gccrcapihaproxy=$gweight bccrcapihaproxy=$bweight -n $namespace"
    //print(['bash', '-c', "$cmd"].execute().text)
}

static def setNginxRoute(String namespace, String bgtype) {
    String gweight = "0"
    String bweight = "0"
    if(bgtype == "green") {
        gweight = "100"
    } else {
        bweight = "100"
    }

    String route_name
    String b_haproxy
    String g_haproxy
    switch (namespace) {
        case "ccrc-prepd":
            route_name = "bgui"
            b_haproxy = "bwebpreprdhaproxy"
            g_haproxy = "gwebpreprdhaproxy"
            break
        case "ccrc-prod":
            route_name = "bgweb"
            b_haproxy = "bwebprdhaproxy"
            g_haproxy = "gwebprdhaproxy"
            break
        case "ccrc-stgrel1":
            route_name = "stgrelwebhaproxy"
            b_haproxy = "bhaproxyweb"
            g_haproxy = "ghaproxyweb"
            break
        case "ccrc-stgrel":
            route_name = "bgui"
            b_haproxy = "bhaproxyweb"
            g_haproxy = "ghaproxyweb"
            break
        default:
            route_name = ""
            b_haproxy = ""
            g_haproxy = ""
    }

    return "oc set route-backends $route_name $g_haproxy=$gweight $b_haproxy=$bweight -n $namespace"
}

static def setGSLBRoute(String namespace, String bgtype) {
    String gweight = "0"
    String bweight = "0"
    if(bgtype == "green") {
        gweight = "100"
    } else {
        bweight = "100"
    }

    String route_name
    String b_nginx
    String g_nginx
    switch (namespace) {
        case "ccrc-prepd":
            route_name = "ccrcnginxrt"
            b_nginx = "bccrcnginxsvc"
            g_nginx = "gccrcnginxsvc"
            break
        case "ccrc-prod":
            route_name = "ccrcnginxrt"
            b_nginx = "bccrcnginxsvc"
            g_nginx = "gccrcnginxsvc"
            break
        case "ccrc-stgrel1":
            route_name = "stgrelwebhaproxy"
            b_nginx = "bhaproxyweb"
            g_nginx = "ghaproxyweb"
            break
        case "ccrc-stgrel":
            namespace = "ccrc-stage"
            route_name = "ccrcnginxrt"
            b_nginx = "bccrcnginxsvc"
            g_nginx = "gccrcnginxsvc"
            break
        case "ccrc-lt":
            route_name = "ccrcnginxrt"
            b_nginx = "bccrcnginxsvc"
            g_nginx = "gccrcnginxsvc"
            break
        default:
            route_name = ""
            b_nginx = ""
            g_nginx = ""
    }

    return "oc set route-backends $route_name $g_nginx=$gweight $b_nginx=$bweight -n $namespace"
}

static def setSaaSSvcRoute(String namespace, String bgtype) {
    String gweight = "0"
    String bweight = "0"
    if(bgtype == "green") {
        gweight = "100"
    } else {
        bweight = "100"
    }

    String route_name = "bgsaassvc"
    String b_haproxysvc = "bsaashaproxysvc"
    String g_haproxysvc = "gsaashaproxysvc"

    return "oc set route-backends $route_name $g_haproxysvc=$gweight $b_haproxysvc=$bweight -n $namespace"
}

static def setSaaSWebRoute(String namespace, String bgtype) {
    String gweight = "0"
    String bweight = "0"
    if(bgtype == "green") {
        gweight = "100"
    } else {
        bweight = "100"
    }

    String route_name = "bgsaasweb"
    String b_haproxyweb = "bsaashaproxyweb"
    String g_haproxyweb = "gsaashaproxyweb"

    return "oc set route-backends $route_name $g_haproxyweb=$gweight $b_haproxyweb=$bweight -n $namespace"
}

return this