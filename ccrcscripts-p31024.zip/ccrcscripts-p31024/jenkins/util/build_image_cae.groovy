def call(String generated_dir, String module, String servicename, String env, String version, String buildNo, String ext,String buildsrvr) {
    def main_or_rel = load("jenkins/util/main_or_rel.groovy")
    String main_rel = main_or_rel(env)

    String dash_main = ""
    String versionFull = ""
    String imagename = ""
    String reltype = ""
    String pullFlag = "--pull=true"
    String multiStageModules = "CCRCRtrIO,CCRCRtrRenp,CCRCRtrSearch"

    if( multiStageModules.contains(module)){
        pullFlag = ""
    }

    switch(main_rel) {
        case 'main':
            dash_main = "-main"
            versionFull = "$version-$buildNo"
            imagename = "${servicename}main"
            reltype = "-main"
            break
        case 'rel':
            dash_main = ""
            versionFull = "$version-R$buildNo"
            imagename = "${servicename}rel"
            reltype = "-rel"
            break
    }

    sh """
    #!/bin/bash

    rm -rf ${generated_dir}/${module}${reltype}/${module}${dash_main}.${ext}
    scp ccrc-build:/a/jenkins/data/workspace/${module}${reltype}/target/${module}${dash_main}.${ext} ${generated_dir}/${module}${reltype}
    docker build --no-cache=true --build-arg moduleName=$module -t containers.cisco.com/ccw_renewal/$imagename:$versionFull ${pullFlag} ${generated_dir}/${module}${reltype}/
    docker push containers.cisco.com/ccw_renewal/$imagename:$versionFull
    docker rmi containers.cisco.com/ccw_renewal/$imagename:$versionFull
    """

    return versionFull
}

return this
