def call(def modules, String taskNode, String env, String bgtype, def scale_up = true, String deploysrver) {
    def scales = [:]
    def scaler = load("jenkins/util/scale_replica.groovy")

    for(kv in mapToList(modules)) {
        envObj = kv[1]['envs'][env]
        if(envObj != null && envObj['version'] != null) {
            def module = kv[0].toString()
            def service_name = kv[1]['service_name']
            def count

            if(scale_up) {
                count = envObj['replicas']
            } else {
                if(env == "stg1-rel" || env == "stg2-rel") {
                    count = 0
                } else if((env == "prd1" || env == "prd2") && kv[1]['pre_prd_enabled'] == 'N') {
                    count = 0
                } else {
                    count = 1
                }
            }

            if(kv[1]['bg_enabled'] == "Y") {
                scales["${module}"] = {
                    node("${taskNode}") {
                        scaler(module, service_name, env, bgtype, count,deploysrver)
                    }
                }
            }
        }
    }

    return scales
}

static List<List<?>> mapToList(Map map) {
    return map.collect { it ->
        [it.key, it.value]
    }
}

return this
