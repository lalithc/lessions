import groovy.json.JsonOutput

def call(String module, String env, String version,String automationsrvr) {
    def body = [:]
    body.put("module", module)
    body.put("env", env)
    body.put("version", version)
    def json = JsonOutput.toJson(body)

    String result = ['bash', '-c', "curl -X PUT '$automationsrvr:5000/module/update_version' -d '$json'"].execute().text

    print("Update Version result: $result")
}

return this