import groovy.json.JsonOutput

def call(String module, String sourceEnv, String targetEnv,String deploysrver) {
    def body = [:]
    body.put("module", module)
    body.put("source_env", sourceEnv)
    body.put("target_env", targetEnv)
    def json = JsonOutput.toJson(body)

    String result = ['bash', '-c', "curl -X PUT '$deploysrver:5000/module/promote_version_dc3' -d '$json'"].execute().text

    print("Promote Version result: $result")

    return result
}

return this
