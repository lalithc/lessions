def call(String env, String hotfixEnabled, String deploysrver) {
    setHotfixDisabled(env, hotfixEnabled,deploysrver)
}

static def setHotfixDisabled(String env, String hotfixEnabled, String deploysrver) {
    def text = ['bash', '-c', "curl -X PUT '$deploysrver:5000/env/$env' -d '{\"hotfix_enabled\":\"$hotfixEnabled\"}'"].execute().text
    return text
}

return this

