def call(String module, String servicename, String env, String bgtype, def count, String deploysrver) {
    try {
        String namespace = getNamespace(env)

        String bgflag
        if(bgtype == 'blue') {
            bgflag = 'b'
        } else if(bgtype == 'green') {
            bgflag = 'g'
        } else {
            bgflag = ''
        }

        sh """
        #!/bin/bash
        
        oc project
        if oc get deploymentconfig ${bgflag}${servicename} -n ${namespace} ; then
            oc scale dc/${bgflag}${servicename} -n $namespace --replicas=$count
        fi
        """

        if(bgtype == 'blue') {
            setBlueReplicas(module, env, count,deploysrver)
        } else {
            setGreenReplicas(module, env, count,deploysrver)
        }

   } catch(Exception e) {
        sparkSend credentialsId: '0c60e710-d3ee-4e5b-aac0-9d48100ad45f',
                message: '[$JOB_NAME]\n$BUILD_URL\nERROR: ' + bgtype + ' scale of module ' + module +
                ' to count ' + count + ' replicas has failed! ' + e.getMessage(),
                messageType: 'text',
                spaceList: [[spaceId: 'Y2lzY29zcGFyazovL3VzL1JPT00vM2U3YjMyNTAtYTBiNy0xMWU3LTkxZmQtMTE2Nzc2Njg4MWU0',
                             spaceName: 'CCRC Jenkins Release Deployments']]

        throw e
    }
}

static def getNamespace(String env) {
    switch(env) {
        case "stg2-rel":
            return "ccwr-stage-rel"
        case "stg1-rel":
            return "ccwr-stage-rel"
        case "stg2-main":
            return "ccwr-stage"
        case "stg1-main":
            return "ccwr-stage"
        case "dev-main":
            return "ccwr-dev"
        case "dev-rel":
            return "ccwr-dev-rel"
        case "lt-main":
            return "ccwr-lt"
        case ~/^pre-prd\d$/:
            return "ccwr-prepd"
        case ~/^prd\d$/:
            return "ccwr-prod"
    }
}

static def setGreenReplicas(String module, String env, def green_replicas, String deploysrver) {
    print(setReplicas(module, env, null, green_replicas,deploysrver))
}

static def setBlueReplicas(String module, String env, def blue_replicas, String deploysrver) {
    print(setReplicas(module, env, blue_replicas, null,deploysrver))
}

static def setReplicas(String module, String env, def blue_replicas, def green_replicas, String deploysrver) {
    String replicas_json = blue_replicas != null ? "\"blue\":\"$blue_replicas\"" : "\"green\":\"$green_replicas\""

    def text = ['bash', '-c', "curl -X PUT '$deploysrver:5000/cae/update_replicas' -d '{\"module\":\"$module\", \"env\":\"$env\", $replicas_json}'"].execute().text
    return text
}

return this