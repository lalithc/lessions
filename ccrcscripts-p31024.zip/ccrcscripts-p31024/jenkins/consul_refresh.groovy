def call(String host, String template_file) {
    sh """
    #!/bin/bash
        ssh -t -t -t ccrccloudop@${host} <<EOF
        pkill -9 'consul-template'
        /users/ccrccloudop/consul-template -config ${template_file} &
        exit 0
EOF
    exit 0
    """
}

return this