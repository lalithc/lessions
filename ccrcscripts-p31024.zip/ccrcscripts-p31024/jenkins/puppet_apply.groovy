def call(String host, String moduleLower, String server, String env, String user="ccrccloudop") {
    sh """
    #!/bin/bash
    
    ssh ${user}@${host} << EOF
    for i in {1..10}; do if ! [ -f ~/.puppet/var/state/agent_catalog_run.lock ]; then \
        echo "Executing puppet" && break; else echo "agent_catalog_run.lock exists! Retrying in 30s ... "; sleep 30; \
    fi \
    done
    
    if [ -f ~/.puppet/var/state/agent_catalog_run.lock ]; then \
        echo "Too many retries! Giving up!"; exit 1; \
    fi

    export FACTER_task='$moduleLower'
    puppet agent -t --server=$server --environment=$env
    echo "Puppet apply complete"
EOF

    exit 0
    """
}

return this