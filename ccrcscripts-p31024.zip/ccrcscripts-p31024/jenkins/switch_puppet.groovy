node("${NODE}") {
    def envs = "${ENVS}"
    def upgrade_server = "${SERVER}"

    stage 'Stage 1'
    String[] envList = envs.split(",")

    checkout scm
    def api = load("jenkins/api.groovy")
    def hostList = api.getHostList(envList)

    for (i = 0; i < hostList.size(); i++) {
        def host = hostList.get(i)
        stage "Stage $host"

        sh """
        #!/bin/bash
        
        ssh ccrccloudop@${host} << EOF
        echo "Switching over puppet master to $upgrade_server on host:"
        cat /etc/hostname
        if [ -d ~/.puppet/ssl ]; then
            if [ ! -d ~/ssl_bak ]; then
                echo "Making backup of .puppet/ssl ..."
                cp -r ~/.puppet/ssl ~/ssl_bak
            fi
            rm -rf ~/.puppet/ssl
        else
            if [ ! -d ~/ssl_bak ]; then
                echo "Making backup..."
                cp -r /var/lib/puppet/ssl ~/ssl_bak
            fi
            rm -rf /var/lib/puppet/ssl
        fi
        puppet agent -t --server $upgrade_server --waitforcert 10
        echo "Puppet cert on $host is now pointing to $upgrade_server!"
EOF

        """
    }
}