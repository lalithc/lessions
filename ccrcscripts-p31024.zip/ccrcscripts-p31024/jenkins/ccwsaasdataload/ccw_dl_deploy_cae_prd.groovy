node("${NODE}") {
    try {
        def module = "${MODULE}"
        def servicename = "${SERVICENAME}"
        def env = "${ENV}"
        def dc="${DC}"
        def jobDesc= "${JOBNAME}"
        def bgenable= "${bgenable}"
			
        stage 'Stage 0'
        checkout scm
        def promote_version = load("jenkins/util/promote_version.groovy")
        promote_version(module, "stg-rel", "pre-prd")
        promote_version(module, "pre-prd", "prd")

        def api = load("jenkins/api.groovy")
        String versionFull = api.getVersion(module, env)
        def data = api.getModuleData(module)
        def envObj = api.getEnvs(env)

        def deployer = load("jenkins/ccwsaasdataload/ccw_dl_deploy_cae.groovy")

        def dl_data
        if(jobDesc == 'all'){
          dl_data=api.getAllJobsConfigsDataFromES(module)
        }else{
          dl_data=api.getJobConfigsDataFromES(module, jobDesc)
        }

        dl_data.each { jobData ->
                    if(jobData._source[dc]=='Y')
                    	print(jobData._source['job_name'])
                    	deployer(module, env, versionFull, jobData._source['job_name'], jobData._source['min_heap'], jobData._source['max_heap'], jobData._source['cpu_limit'], jobData._source['cpu_req'], jobData._source['mem_limit'], jobData._source['mem_req'], jobData._source['consumer_type'], bgenable)
           }
    } catch (Exception e) {
        sparkSend credentialsId: 'a3240800-4aba-48b0-888b-e5db5997633a',
                message: '[$JOB_NAME]\n$BUILD_URL\nERROR: ' + e.getMessage(),
                messageType: 'text',
                spaceList: [[spaceId: 'Y2lzY29zcGFyazovL3VzL1JPT00vMDA1MWM5NTAtOTMzMS0xMWU3LTg5ZjQtZGZjYmUxMDlhMjI0',
                             spaceName: 'CCRC Jenkins Deployments']]

        throw e
    }
}
