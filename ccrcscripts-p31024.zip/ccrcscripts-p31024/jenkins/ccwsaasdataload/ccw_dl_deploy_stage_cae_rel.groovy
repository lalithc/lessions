node('cae-rtp') {
    try {
        def module = "${MODULE}"
        def servicename = "${SERVICENAME}"
        def env = "${ENV}"
        def jobDesc= "${JOBNAME}"
        def bgenable= "${bgenable}"

        stage 'Stage 0'
        checkout scm
        def promote_version = load("jenkins/util/promote_version.groovy")
        promote_version(module, "dev-rel", "stg-rel")

        def api = load("jenkins/api.groovy")
        String versionFull = api.getVersion(module, 'stg1-rel')
        def envObjs = api.getEnvs(env)
        def dl_data
        if(jobDesc == 'all'){
          dl_data=api.getAllJobsConfigsDataFromES(module)
        }else{
          dl_data=api.getJobConfigsDataFromES(module, jobDesc)
        }
        
        def deployer = load("jenkins/ccwsaasdataload/ccw_dl_deploy_cae.groovy")

        deploys = [:]
        deploys["${module}-stg1-rel"] = {
            node("cae-rtp") {
            	dl_data.each { jobData ->
                	if(jobData._source['dc1']=='Y')
          			deployer(module, 'stg1-rel', versionFull, jobData._source['job_name'], jobData._source['min_heap'], jobData._source['max_heap'], jobData._source['cpu_limit'], jobData._source['cpu_req'], jobData._source['mem_limit'], jobData._source['mem_req'], jobData._source['consumer_type'],bgenable)
           }
            }
        }
        deploys["${module}-stg2-rel"] = {
            node("cae-rtp") {
                dl_data.each { jobData ->
                	if(jobData._source['dc2']=='Y')
          			deployer(module, 'stg2-rel', versionFull, jobData._source['job_name'], jobData._source['min_heap'], jobData._source['max_heap'], jobData._source['cpu_limit'], jobData._source['cpu_req'], jobData._source['mem_limit'], jobData._source['mem_req'])
           }
            }
        }

        parallel deploys

    } catch (Exception e) {
        sparkSend credentialsId: 'a3240800-4aba-48b0-888b-e5db5997633a',
                message: '[$JOB_NAME]\n$BUILD_URL\nERROR: ' + e.getMessage(),
                messageType: 'text',
                spaceList: [[spaceId: 'Y2lzY29zcGFyazovL3VzL1JPT00vMDA1MWM5NTAtOTMzMS0xMWU3LTg5ZjQtZGZjYmUxMDlhMjI0',
                             spaceName: 'CCRC Jenkins Deployments']]

        throw e
    }
}