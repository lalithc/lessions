node('Deployer') {
    try {
        def env = "${ENV}"
        def cmd = "${CMD_ARGS}"

        def puppet_server = "ccrc-build-4.cisco.com"

        switch (env) {
            case 'ccrc_dev':
                host = "ccrc-msrv-stg1-12"
                break
            case 'ccrc_stage':
                host = "ccrc-msrv-stg1-12"
                break
            case 'ccrc_prod':
                host = "ccrc-msrv-stg1-12"
                break
            default:
                host = "ccrc-msrv-stg1-12"
                env = "ccrc_dev"
        }

        stage "$host"
        sh """
        #!/bin/bash
    
        ssh ccrccloudop@${host} << EOF
        export FACTER_task='pdf'
        export FACTER_cmdargs='$cmd'
        puppet agent -t --environment=$env --server=$puppet_server
        echo "Puppet Apply Complete!"
EOF
        exit 0
        """

        print("PDF Execution complete!")
    } catch (Exception e) {
        sparkSend credentialsId: '0c60e710-d3ee-4e5b-aac0-9d48100ad45f',
                message: '[$JOB_NAME]\n$BUILD_URL\nERROR: ' + e.getMessage(),
                messageType: 'text',
                spaceList: [[spaceId: 'Y2lzY29zcGFyazovL3VzL1JPT00vMDA1MWM5NTAtOTMzMS0xMWU3LTg5ZjQtZGZjYmUxMDlhMjI0',
                             spaceName: 'CCRC Jenkins Deployments']]

        throw e
    }
}