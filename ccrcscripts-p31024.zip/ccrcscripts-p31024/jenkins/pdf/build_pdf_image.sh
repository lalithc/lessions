#!/bin/sh

repoServer='ccrc-build-docker-04:5000'
docker_dir='/apps/pdf/'
version=$1

cp /a/jenkins/jobs/Build_PDF/workspace/target/CCRCSupportServices.jar ${docker_dir}

docker build --build-arg moduleName=CCRCSupportServices -t ${repoServer}/ccrcsupportservices:${version} --pull=true ${docker_dir}
docker push ${repoServer}/ccrcsupportservices:${version}

docker images ${repoServer}/ccrcsupportservices -q | xargs -r docker rmi -f
rm -f ${docker_dir}CCRCSupportServices.jar

url="http://ccrc-build-4.cisco.com:8080/RelMngr-1.0/installModuleByBuildTypeDocker?versionNumber=$version&noOfDockers=5&newEnv=CCRC_DEV&module=pdf"
echo "Executing RelMngr URL: ${url}"
curl -f "${url}"