node('Deployer') {
    try {
    
    stage 'Stage 0'    
    sh """
    #!/bin/bash
    

    ssh ccrccloudop@ccrc-haproxy-stg2-01 << EOF
        docker stop haproxy
EOF
	ssh ccrccloudop@ccrc-haproxy-stg2-02 << EOF
        docker stop haproxy
EOF
        exit 0
    """

        print("PDF Execution complete!")
    } catch (Exception e) {
        sparkSend credentialsId: '0c60e710-d3ee-4e5b-aac0-9d48100ad45f',
                message: '[$JOB_NAME]\n$BUILD_URL\nERROR: ' + e.getMessage(),
                messageType: 'text',
                spaceList: [[spaceId: 'Y2lzY29zcGFyazovL3VzL1JPT00vMDA1MWM5NTAtOTMzMS0xMWU3LTg5ZjQtZGZjYmUxMDlhMjI0',
                             spaceName: 'CCRC Jenkins Deployments']]

        throw e
    }
}