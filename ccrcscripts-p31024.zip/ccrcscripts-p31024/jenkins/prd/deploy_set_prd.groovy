try {
    def tasks = [:]
    def env = "${ENV}"
    def set = ("${SET}")
    def project = "${PROJECT}"

    // make exclusions lowercase and remove spaces to avoid user error
    def exclusions = "${EXCLUDED_MODULES}".toLowerCase().replace(" ", "")

    // these modules do not deploy during full prod deployment
    def exclusion_list_default = ['ccrcdataloader','disticcodataloader','ccwsaasdataloader','ccrcdashboard','ccrcconfig','edwreports','quotelinesdataload','ccrcappdataload','ccrcqotnonstd','ccrcdataservices']
    def exclusion_list = exclusions.split(",") + exclusion_list_default

    print("Excluding these modules: $exclusion_list")

    node('Deployer') {
        stage 'Stage 1'
        checkout scm

        def api = load("jenkins/api.groovy")
        def splitter = load("jenkins/deployment_set_splitter.groovy")

        stage 'Module Data'
        def modules = api.getModuleDataByEnv(env, project)

        stage 'Sets Mapping'
        def maps = splitter.map_module_host_maps(modules, env, exclusion_list)
        def sets = splitter.split_into_sets(maps['module_hosts'], maps['host_modules'])
        def set_map = sets[set]
        print "Set Allocation Complete:\n"
        print set_map

        stage 'Task setup'
        def puppet = load("jenkins/puppet_apply.groovy")

        for (kv in mapToList(set_map)) {
            def host = kv[0]
            def moduleString = kv[1].join(",").toLowerCase()

            if (moduleString != "") {
                tasks["${host}"] = {
                    node ('Deployer') {
                        puppet(host, moduleString, "ccrc-build-6.cisco.com", "ccrc_prod", "ccrccloudop")
                    }
                }
            }
        }
    }

    stage 'Task Execution'
    parallel tasks
} catch (Exception e) {
    sparkSend credentialsId: '0c60e710-d3ee-4e5b-aac0-9d48100ad45f',
            message: '[$JOB_NAME]\n$BUILD_URL\nERROR: ' + e.getMessage(),
            messageType: 'text',
            spaceList: [[spaceId: 'Y2lzY29zcGFyazovL3VzL1JPT00vM2U3YjMyNTAtYTBiNy0xMWU3LTkxZmQtMTE2Nzc2Njg4MWU0',
                         spaceName: 'CCRC Jenkins Release Deployments']]

    throw e
}

// Required due to JENKINS-27421
@NonCPS
static List<List<?>> mapToList(Map map) {
    return map.collect { it ->
        [it.key, it.value]
    }
}
