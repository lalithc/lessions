try {
    def env = "${ENV}"

    node('Deployer') {
        stage 'Stage Setup'
        checkout scm
        def rel_mgr = load("jenkins/rel_mgr.groovy")
        rel_mgr("all", "CCRC_STAGE", "CCRC_PROD", env, null, "subscriptions")

        def dc
        if (env == "prd1") {
            dc = "DC2"
        } else {
            dc = "DC1"
        }

        stage "Stage Deploy SaaS $dc Set 1"
        build job: "Deploy-SaaS-Prod-$dc-Set1"

        stage "Stage Deploy SaaS $dc Set 2"
        build job: "Deploy-SaaS-Prod-$dc-Set2"
    }
} catch (Exception e) {
    sparkSend credentialsId: '0c60e710-d3ee-4e5b-aac0-9d48100ad45f',
            message: '[$JOB_NAME]\n$BUILD_URL\nERROR: ' + e.getMessage(),
            messageType: 'text',
            spaceList: [[spaceId: 'Y2lzY29zcGFyazovL3VzL1JPT00vM2U3YjMyNTAtYTBiNy0xMWU3LTkxZmQtMTE2Nzc2Njg4MWU0',
                         spaceName: 'CCRC Jenkins Release Deployments']]

    throw e
}