try {
    def env = "${ENV}"
    def deploy_node = "${NODE}"
    def deploys = [:]
    def switch_bg = [:]
    def disable_hotfix = [:]
    def scale_up = [:]
    def scale_down = [:]
    String bg
    String bgtype

    node("${deploy_node}") {
        stage 'Stage Checkout'
        checkout scm

        stage 'Promote Versions'
        def promote_version = load("jenkins/util/promote_version.groovy")
        promote_version("all", "stg-rel", "pre-prd")

        stage 'Module Version Data'
        def api = load("jenkins/api.groovy")
        def modules = api.getCAEModules(env,"")

        stage 'Task setup'
        def deploy_all = load("jenkins/util/deploy_cae_all.groovy")
        def blue_green_switch = load("jenkins/util/blue_green_switch.groovy")
        def scale_all = load("jenkins/util/scale_all_replica.groovy")
        def enable_disable_hotfix = load("jenkins/util/hotfix_enable_disable.groovy")
        bg = api.getEnvs(env)['blue_green']

        if(bg == "blue") {
            bgtype = "green"
        } else {
            bgtype = "blue"
        }
        disable_hotfix["Disable Hotfixes"] = {
            node("${deploy_node}") {
                enable_disable_hotfix(env, "N")
            }
        }
        deploys = deploy_all(modules, deploy_node, env, bgtype)
        switch_bg["Switch_To_${bgtype}_${env}"] = {
            node("${deploy_node}") {
                blue_green_switch("prd2haproxy", "preprdhaproxy", env, bgtype)
            }
        }
        scale_down = scale_all(modules, deploy_node, env, bg, false)
        scale_up = scale_all(modules, deploy_node, env, bgtype, true)
    }

    def exceptions = []

    wrapParallel(deploys, "Deploy $bgtype Versions", exceptions)
    wrapParallel(disable_hotfix, "Disable hotfixes for $env", exceptions)
    wrapParallel(switch_bg, "Switch to $bgtype", exceptions)
    wrapParallel(scale_down, "Scale down $bg Versions", exceptions)
    wrapParallel(scale_up, "Scale up $bgtype Versions", exceptions)

    if (!exceptions.isEmpty()) {
        throw exceptions[0]
    }
} catch(Exception e) {
    sparkSend credentialsId: '0c60e710-d3ee-4e5b-aac0-9d48100ad45f',
            message: '[$JOB_NAME]\n$BUILD_URL\nERROR: ' + e.getMessage(),
            messageType: 'text',
            spaceList: [[spaceId: 'Y2lzY29zcGFyazovL3VzL1JPT00vM2U3YjMyNTAtYTBiNy0xMWU3LTkxZmQtMTE2Nzc2Njg4MWU0',
                         spaceName: 'CCRC Jenkins Release Deployments']]

    throw e
}

void wrapParallel(map, stageMessage, exceptionList) {
    try {
        stage "$stageMessage"
        parallel map
    } catch (Exception e) {
        exceptionList.add(e)
    }
}