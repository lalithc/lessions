try {
    def module = "${MODULE}"
    def hosts = "${HOSTS}"
    def tasks1 = [:]
    def tasks2 = [:]
    def puppet_server = "ccrc-build-6.cisco.com"

    node('Deployer') {

        stage 'Stage 1'
        checkout scm

        def rel_mgr = load("jenkins/rel_mgr.groovy")
        rel_mgr(module, "CCRC_STAGE", "CCRC_PROD", "prd", null)

        def moduleLower = module.toLowerCase()

        stage 'Stage 2'
        def hostList = hosts.split(",")
        def puppet = load("jenkins/puppet_apply.groovy")

        def sleepIndex = (hostList.size() / 2 as double).round()

        for (i = 0; i < hostList.size(); i++) {
            def host = hostList[i]
            stage "Stage $host"

            // If we are past the half way point, sleep to allow services on other nodes to come up
            if (i == sleepIndex) {
                tasks2["${host}"] = {
                    node('Deployer') {
                        puppet(host, moduleLower, puppet_server, "ccrc_prod", "ccrccloudop")
                    }
                }
            } else {
                tasks1["${host}"] = {
                    node('Deployer') {
                        puppet(host, moduleLower, puppet_server, "ccrc_prod", "ccrccloudop")
                    }
                }
            }
        }
    }

    stage 'Set 1'
    parallel tasks1

    stage 'Sleep'
    print("Sleeping 10s to allow boot-up of ccrcconfig")
    sleep(10 as long)

    stage 'Set 2'
    parallel tasks2

    print("Prod Deployment for module $module complete!")
} catch(Exception e) {
    sparkSend credentialsId: '0c60e710-d3ee-4e5b-aac0-9d48100ad45f',
            message: '[$JOB_NAME]\n$BUILD_URL\nERROR: ' + e.getMessage(),
            messageType: 'text',
            spaceList: [[spaceId: 'Y2lzY29zcGFyazovL3VzL1JPT00vM2U3YjMyNTAtYTBiNy0xMWU3LTkxZmQtMTE2Nzc2Njg4MWU0',
                         spaceName: 'CCRC Jenkins Release Deployments']]

    throw e
}