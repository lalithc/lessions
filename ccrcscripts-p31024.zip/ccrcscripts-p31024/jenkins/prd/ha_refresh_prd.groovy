try {
    def env = "${ENV}"
    def tasks = [:]

    node('Deployer') {
        stage 'Stage Setup'
        checkout scm
        def api = load("jenkins/api.groovy")
        String[] envList = env.split(",")
        String[] hosts = api.getHostList(envList)

        def ha_refresh = load("jenkins/ha_refresh.groovy")

        for (i = 0; i < hosts.size(); i++) {
            def host = hosts[i]
            tasks["${host}"] = {
                node('Deployer') {
                    ha_refresh(host)
                }
            }
        }

        stage 'Stage Execution'
    }

    parallel tasks
} catch(Exception e) {
    sparkSend credentialsId: '0c60e710-d3ee-4e5b-aac0-9d48100ad45f',
            message: '[$JOB_NAME]\n$BUILD_URL\nERROR: ' + e.getMessage(),
            messageType: 'text',
            spaceList: [[spaceId: 'Y2lzY29zcGFyazovL3VzL1JPT00vM2U3YjMyNTAtYTBiNy0xMWU3LTkxZmQtMTE2Nzc2Njg4MWU0',
                         spaceName: 'CCRC Jenkins Release Deployments']]

    throw e
}