try {
    def env = "${ENV}"
    def deploy_node = "${NODE}"
    def deploys = [:]
    def disable_hotfix = [:]
    String bg
    String bgtype = ""

    node("${deploy_node}") {
        stage 'Stage Checkout'
        checkout scm

        stage 'Promote Versions'
        def promote_version = load("jenkins/util/promote_version.groovy")
        promote_version("all", "pre-prd", "prd")

        stage 'Module Version Data'
        def api = load("jenkins/api.groovy")
        def modules = api.getCAEModules(env,"ServiceContract")

        stage 'Task setup'
        def deploy_all = load("jenkins/util/deploy_cae_all.groovy")
        def enable_disable_hotfix = load("jenkins/util/hotfix_enable_disable.groovy")
        bg = api.getEnvs(env)['blue_green']

        if(bg == "blue") {
            bgtype = "green"
        } else {
            bgtype = "blue"
        }
        deploys = deploy_all(modules, deploy_node, env, bgtype)
        disable_hotfix["Disable Hotfixes"] = {
            node("${deploy_node}") {
                enable_disable_hotfix(env, "N")
            }
        }

    }

    stage "Disable hotfixes"
    parallel disable_hotfix
    stage "Deploy New $bgtype Versions"
    parallel deploys
} catch(Exception e) {
    sparkSend credentialsId: '0c60e710-d3ee-4e5b-aac0-9d48100ad45f',
            message: '[$JOB_NAME]\n$BUILD_URL\nERROR: ' + e.getMessage(),
            messageType: 'text',
            spaceList: [[spaceId: 'Y2lzY29zcGFyazovL3VzL1JPT00vM2U3YjMyNTAtYTBiNy0xMWU3LTkxZmQtMTE2Nzc2Njg4MWU0',
                         spaceName: 'CCRC Jenkins Release Deployments']]

    throw e
}