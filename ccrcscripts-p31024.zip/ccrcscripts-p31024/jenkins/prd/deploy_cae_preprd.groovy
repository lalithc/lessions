node("${NODE}") {
    try {
        def module = "${MODULE}"
        def servicename = "${SERVICENAME}"
        def env = "${ENV}"

        stage 'Stage 0'
        checkout scm
        def promote_version = load("jenkins/util/promote_version.groovy")
        promote_version(module, "stg-rel", "pre-prd")

        def api = load("jenkins/api.groovy")
        String versionFull = api.getVersion(module, env)
        def data = api.getModuleData(module)
        def envObj = api.getEnvs(env)
        def replicas = data['envs'][env]['replicas']
        def deployer = load("jenkins/util/deploy_cae.groovy")

        def bgtype
        if(data['bg_enabled'] == 'N') {
            bgtype = "cyan"
        } else {
            if(envObj['hotfix_enabled'] == 'Y') {
                bgtype = envObj['blue_green']
            } else {
                current_bg = envObj['blue_green']
                if(current_bg == "blue") {
                    bgtype = "green"
                } else {
                    bgtype = "blue"
                }
            }
        }

        deployer(module, env, versionFull, servicename, bgtype, replicas)

    } catch (Exception e) {
        sparkSend credentialsId: 'a3240800-4aba-48b0-888b-e5db5997633a',
                message: '[$JOB_NAME]\n$BUILD_URL\nERROR: ' + e.getMessage(),
                messageType: 'text',
                spaceList: [[spaceId: 'Y2lzY29zcGFyazovL3VzL1JPT00vMDA1MWM5NTAtOTMzMS0xMWU3LTg5ZjQtZGZjYmUxMDlhMjI0',
                             spaceName: 'CCRC Jenkins Deployments']]

        throw e
    }
}