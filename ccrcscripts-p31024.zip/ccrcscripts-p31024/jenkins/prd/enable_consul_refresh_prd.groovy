try {
    def env = "${ENV}"
    def tasks = [:]

    node('Deployer') {
        stage 'Stage Setup'
        checkout scm
        def api = load("jenkins/api.groovy")
        String[] envList = env.split(",")
        String[] hosts = api.getHostList(envList)

        def consul_refresh = load("jenkins/consul_refresh.groovy")

        for (i = 0; i < hosts.size(); i++) {
            def host = hosts[i]
            tasks["${host}"] = {
                node('Deployer') {
                    consul_refresh(host,"haproxy.hcl")
                }
            }
        }

        /*String[] nginx_hosts = [
                "ccrc-haproxy-${env}-01",
                "ccrc-haproxy-${env}-02",
                "ccrc-haproxy-${env}-03",
                "ccrc-haproxy-${env}-04"
        ]

        for (i = 0; i < nginx_hosts.size(); i++) {
            def host = nginx_hosts[i]
            tasks["${host}"] = {
                node('Deployer') {
                    consul_refresh(host,"/apps/nginx/conf/ngx.conf")
                }
            }
        }*/

        stage 'Stage Execution'
    }

    parallel tasks
} catch(Exception e) {
    sparkSend credentialsId: '0c60e710-d3ee-4e5b-aac0-9d48100ad45f',
            message: '[$JOB_NAME]\n$BUILD_URL\nERROR: ' + e.getMessage(),
            messageType: 'text',
            spaceList: [[spaceId: 'Y2lzY29zcGFyazovL3VzL1JPT00vM2U3YjMyNTAtYTBiNy0xMWU3LTkxZmQtMTE2Nzc2Njg4MWU0',
                         spaceName: 'CCRC Jenkins Release Deployments']]

    throw e
}