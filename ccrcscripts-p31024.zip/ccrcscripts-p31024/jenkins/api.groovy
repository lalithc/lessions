import groovy.json.JsonSlurperClassic


class ServiceAPI implements Serializable {
	//def deploysrver = "ccrc-nprd-docker-build"

	def getHostListByModule(String env, String module,String automationsrvr) {
		def jsonSlurper = new JsonSlurperClassic()

		def text = [
			'bash',
			'-c',
			"curl '$automationsrvr:5000/modules?env=$env&module=$module'"
		].execute().text
		def result = jsonSlurper.parseText(text)

		if(result.toString() == "{}") {
			return []
		}

		def moduleObj = jsonSlurper.parseText(text).get(module)

		if (moduleObj == null){
			return []
		}

		def hosts = moduleObj.envs.get(env).hosts

		def hostList = []
		for(host in hosts) {
			hostList << host
		}

		return hostList
	}

	def getExt(String module) {
		def data = getModuleData(module)

		return data['ext'].toString()
	}


	def getEnvs(String env = "",String automationsrvr) {
		def jsonSlurper = new JsonSlurperClassic()

		String envStr = env
		if (env != "") {
			envStr = "?env=$env"
		}

		def text = [
			'bash',
			'-c',
			"curl '$automationsrvr:5000/envs$envStr'"
		].execute().text
		def result = jsonSlurper.parseText(text)

		if (result.toString() == "{}") {
			throw new Exception("Invalid env [$env] supplied!")
		}

		if(result.containsKey(env)) {
			return result[env]
		} else {
			return result
		}
	}


	def getModuleData(String module,String automationsrvr) {
		def jsonSlurper = new JsonSlurperClassic()

		def text = [
			'bash',
			'-c',
			"curl '$automationsrvr:5000/modules?module=$module'"
		].execute().text
		def result = jsonSlurper.parseText(text)

		if (result.toString() == "{}") {
			throw new Exception("Invalid module [$module] supplied!")
		}

		return result[module]
	}

	def getCAEModules(String env, String project,String automationsrvr) {
		def jsonSlurper = new JsonSlurperClassic()

		def projectParam = ""
		if(project != "") {
			projectParam = "&project=$project"
		}
		def prePrd = ""
		def lt = ""
		switch (env) {
			case ~/pre-prd\d*/:
				prePrd = "&pre_prd_enabled=Y"
				break
			case ~/lt-main/:
				lt = "&lt_enabled=Y"
				break
			default:
				lt = ""
				prePrd = ""
		}
		def text = [
			'bash',
			'-c',
			"curl '$automationsrvr:5000/modules?cae_enabled=Y&env=$env$projectParam$prePrd$lt'"
		].execute().text
		def result = jsonSlurper.parseText(text)

		if (result.toString() == "{}") {
			throw new Exception("Invalid env [$env] supplied!")
		}

		return result
	}

	def getModuleDataByEnv(String env, String project,String automationsrvr) {
		def jsonSlurper = new JsonSlurperClassic()

		def projectParam = ""
		if(project != "") {
			projectParam = "&project=$project"
		}
		def text = [
			'bash',
			'-c',
			"curl '$automationsrvr:5000/modules?env=$env$projectParam'"
		].execute().text
		def result = jsonSlurper.parseText(text)

		if (result.toString() == "{}") {
			throw new Exception("Invalid env [$env] supplied!")
		}

		return result
	}

	def getHostList(String[] envs,String automationsrvr) {
		def jsonSlurper = new JsonSlurperClassic()
		def text = [
			'bash',
			'-c',
			"curl '$automationsrvr:5000/hosts'"
		].execute().text
		def data = jsonSlurper.parseText(text)

		def hosts = []
		for(String env in envs) {
			for (host in data[env.trim()]) {
				hosts << host
			}
		}

		return hosts
	}

	def getModuleList(String host,String automationsrvr) {
		def jsonSlurper = new JsonSlurperClassic()

		def text = [
			'bash',
			'-c',
			"curl '$automationsrvr:5000/modules?host=$host'"
		].execute().text
		def modules = jsonSlurper.parseText(text)

		def moduleList = []
		for(String module in modules.keySet()) {
			moduleList << module
		}

		return moduleList
	}

	def getNginxModuleList(String host,String automationsrvr) {
		def jsonSlurper = new JsonSlurperClassic()

		def text = [
			'bash',
			'-c',
			"curl '$automationsrvr:5000/modules?host=$host&type=nginx'"
		].execute().text
		def modules = jsonSlurper.parseText(text)

		def moduleList = []
		if (modules.toString() == "{}") {
			return moduleList
		}

		for(String module in modules.keySet()) {
			moduleList << module
		}

		return moduleList
	}

	def getJobConfigsDataFromES(String moduleName, String jobName) {
		def jsonSlurper = new JsonSlurperClassic()
		def text = [
			'bash',
			'-c',
			"curl 'esreadonly:esdev123@csssrch-stg-02:9220/deployconfigsp3/_search?q=module_name:$moduleName&q=job_desc:$jobName'"
		].execute().text
		def result = jsonSlurper.parseText(text)

		if (result.toString() == "{}") {
			throw new Exception("Invalid jobname $jobName supplied!")
		}

		if(result.hits.total>0){
			return result.hits.hits
		}else{
			throw new Exception("Invalid jobname $jobName supplied! OR config data not exists")
		}
	}

	def getAllJobsConfigsDataFromES(String moduleName) {
		def jsonSlurper = new JsonSlurperClassic()
		def text = [
			'bash',
			'-c',
			"curl 'esreadonly:esdev123@csssrch-stg-01:9220/deployconfigsp3/_search?q=module_name:$moduleName&size=30'"
		].execute().text
		def result = jsonSlurper.parseText(text)

		if (result.toString() == "{}") {
			throw new Exception("Invalid moduleName $moduleName supplied!")
		}

		if(result.hits.total>0){
			return result.hits.hits
		}else{
			throw new Exception("Invalid moduleName $moduleName supplied! OR config data not exists")
		}
	}

	static def getVersion(String module, String env,String automationsrvr) {
		def jsonSlurper = new JsonSlurperClassic()

		def text = [
			'bash',
			'-c',
			"curl -f '$automationsrvr:5000/module/versions?module=$module&env=$env'"
		].execute().text
		def result = jsonSlurper.parseText(text)

		if (result.toString() == "{}") {
			throw new Exception("Module [$module] has no env versions!")
		}

		return result[module]['envs'][env]['version']
	}

	static def getVersions(String env = "",String automationsrvr) {
		def jsonSlurper = new JsonSlurperClassic()

		def filter = "?env=$env"
		if (env == "") {
			filter = ""
		}

		def text = [
			'bash',
			'-c',
			"curl -f '$automationsrvr:5000/module/versions$filter'"
		].execute().text
		def result = jsonSlurper.parseText(text)

		if (result.toString() == "{}") {
			throw new Exception("Env [$env] has no env versions!")
		}

		return result
	}

	static def getDeployer(String host, String port, String env){

		String result = [
			'bash',
			'-c',
			"curl -X GET '$host:$port/deployer?env=$env'"
		].execute().text
		print ("deployer server: $result")
		return result
	}

	static def getDC(String host, String port, String env){

		String result = [
			'bash',
			'-c',
			"curl -X GET '$host:$port/config?key=envDC&env=$env'"
		].execute().text
		print ("env DC: $result")
		return result
	}

	static def getNamespace(String host, String port, String env){

		String result = [
			'bash',
			'-c',
			"curl -X GET '$host:$port/config?key=namespace&env=$env'"
		].execute().text
		print ("env namespace: $result")
		return result
	}
}

return new ServiceAPI()
