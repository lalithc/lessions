node('master') {
	try {
		def env = "${ENV}"
		def subtype = "${SUBTYPE}"
		def app = "${APP}"

		stage 'Stage 0'

		checkout scm
		def main_or_rel = load("jenkins/util/main_or_rel.groovy")
		String main_rel = main_or_rel(env)
		def api = load("jenkins/api.groovy")
		def deployer = api.getDeployer("ccrc-nprd-docker-build","5000","$env")
		def dc = api.getDC("ccrc-nprd-docker-build","5000","$env")
		def namespace = api.getNamespace("ccrc-nprd-docker-build","5000","$env")
		String kube_dir = "/apps/ccrckubernetes/"
		println deployer
		println dc
		println namespace
		
		if (main_rel == 'main') {
			life=env.replaceAll("-main","")
		}
		else {
			life=env.replaceAll("-rel","")
		}
		
		node("$deployer") {
			checkout scm
			
			sh """
				#!/bin/bash
				
				if [ "${subtype}" != "None" ] ; then
					genpath=$main_rel/$app-cae/$subtype
					dcname=$subtype
				else
					genpath=$main_rel/$app-cae
					dcname=$app
				fi
				echo \$genpath
				finalpath=$kube_dir\$genpath
				echo \$finalpath
				
				if [ -f \$finalpath/configmap-${dc}.yaml ]; then
					oc replace -f \$finalpath/configmap-${dc}.yaml -n $namespace
				elif [ -f \$finalpath/configmap-${life}.yaml ]; then
					oc replace -f \$finalpath/configmap-${life}.yaml -n $namespace
				else
					oc replace -f \$finalpath/configmap.yaml -n $namespace
				fi

				oc deploy --latest dc/\$dcname -n $namespace
			
			"""
		}
	} catch (Exception e) {
		sparkSend credentialsId: 'a3240800-4aba-48b0-888b-e5db5997633a',
		message: '[$JOB_NAME]\n$BUILD_URL\nERROR: ' + e.getMessage(),
		messageType: 'text',
		spaceList: [
			[spaceId: 'Y2lzY29zcGFyazovL3VzL1JPT00vMDA1MWM5NTAtOTMzMS0xMWU3LTg5ZjQtZGZjYmUxMDlhMjI0',
				spaceName: 'CCRC Jenkins Deployments']
		]

		throw e
	}
}
