def call(String host, String env, mounts, server) {

    sh """
    #!/bin/bash

    ssh ccrccloudop@${host} << EOF
    export FACTER_mounts='$mounts'
    export FACTER_task='purge'
    puppet agent -t --server=$server --environment=$env
    echo "Puppet apply complete"
EOF
    
    exit 0
    """
}

return this


