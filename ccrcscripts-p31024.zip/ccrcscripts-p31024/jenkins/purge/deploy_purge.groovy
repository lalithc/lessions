node("${NODE}") {
    try {
        stage '0.1'

        def server = "${SERVER}"
        def envs = "${ENVS}"
        def env = "${ENV}"

        String[] envList = envs.split(",")

        checkout scm
        def api = load("jenkins/api.groovy")
        String[] hosts = api.getHostList(envList)

        def puppet_apply_purge = load("jenkins/purge/puppet_apply_purge.groovy")

        for (int i = 0; i < hosts.size(); i++) {
            String host = hosts[i]
            stage "Stage $host"

            def modules = api.getNginxModuleList(host)

            def mounts = "-v /apps/logs:/apps/logs -v /apps/haproxy:/apps/haproxy"
            for (module in modules) {
                def dir = "/apps/" + module.toString().toLowerCase()
                mounts = mounts + " -v $dir:$dir"
            }

            puppet_apply_purge(host, env, mounts, server)
        }
    } catch (Exception e) {
        sparkSend credentialsId: 'a3240800-4aba-48b0-888b-e5db5997633a',
                message: '[$JOB_NAME]\n$BUILD_URL\nERROR: ' + e.getMessage(),
                messageType: 'text',
                spaceList: [[spaceId: 'Y2lzY29zcGFyazovL3VzL1JPT00vMDA1MWM5NTAtOTMzMS0xMWU3LTg5ZjQtZGZjYmUxMDlhMjI0',
                             spaceName: 'CCRC Jenkins Deployments']]

        throw e
    }
}