#!/bin/sh

if [ $# -ne 2 ]; then
  echo "Not enough arguments! Required: [module] [version] [buildNo]"
  exit 1
fi

module=$1
buildNo=$2
pom_dir=/a/jenkins/jobs/Build_Dependency_Branch_LT/workspace/
version=`xmlstarlet sel -N s=http://maven.apache.org/POM/4.0.0 -t -v "/s:project/s:version" ${pom_dir}pom.xml`
newVersion=`echo ${version} | sed "s/-/LT-/"`
xmlstarlet ed -N s=http://maven.apache.org/POM/4.0.0 -u "/s:project/s:version" -v "${newVersion}" ${pom_dir}pom.xml > ${pom_dir}pom2.xml
xmlstarlet ed -N s=http://maven.apache.org/POM/4.0.0 -u "/s:project/s:dependencies/s:dependency [s:groupId = \"CCRCCommon\"]/s:version" -v "${version}" ${pom_dir}pom2.xml > ${pom_dir}pom3.xml
xmlstarlet ed -N s=http://maven.apache.org/POM/4.0.0 -u "/s:project/s:dependencies/s:dependency [s:groupId = \"UCEPersistent\"]/s:version" -v "${version}" ${pom_dir}pom3.xml > ${pom_dir}pom4.xml
mv -f ${pom_dir}pom4.xml ${pom_dir}pom.xml
rm -f ${pom_dir}pom2.xml
rm -f ${pom_dir}pom3.xml