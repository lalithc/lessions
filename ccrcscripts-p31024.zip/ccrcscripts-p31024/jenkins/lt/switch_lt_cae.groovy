try {
    def env = "lt-main"
    def deploy_node = "cae-rtp"
    String bg

    node("${deploy_node}") {
        stage 'Stage Checkout'
        checkout scm

        def api = load("jenkins/api.groovy")
        def blue_green_switch = load("jenkins/util/blue_green_switch.groovy")
        bg = api.getEnvs(env)['blue_green']

        String bgtype
        if(bg == "blue") {
            bgtype = "green"
        } else {
            bgtype = "blue"
        }
        blue_green_switch("stagehaproxy", "ltmainhaproxy", env, bgtype)
    }

} catch(Exception e) {
    sparkSend credentialsId: '0c60e710-d3ee-4e5b-aac0-9d48100ad45f',
            message: '[$JOB_NAME]\n$BUILD_URL\nERROR: ' + e.getMessage(),
            messageType: 'text',
            spaceList: [[spaceId: 'Y2lzY29zcGFyazovL3VzL1JPT00vM2U3YjMyNTAtYTBiNy0xMWU3LTkxZmQtMTE2Nzc2Njg4MWU0',
                         spaceName: 'CCRC Jenkins Release Deployments']]

    throw e
}
