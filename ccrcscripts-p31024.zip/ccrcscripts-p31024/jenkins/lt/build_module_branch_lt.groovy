node('master') {
    try {
        stage 'Stage 1'
        def module = "${MODULE}"
        def version = "${VERSION}"

        def moduleMain = "$module-main"
        def repoServer = "ccrc-build-docker-04:5000"
        def deployServer = "${DOCKER_NPRD_SRVR}"

        checkout scm
        api = load("jenkins/api.groovy")
        String ext = api.getExt(module)

        def buildArg = moduleMain
        if(ext == "war") {
            buildArg = module
        }

        def moduleLower = module.toLowerCase()
        def docker_dir = "/apps/automated-dockerfiles/generatedmodules/os/"
        def url = "http://$deployServer:8080/jenkins/job/Deploy_Module_Branch_LT/buildWithParameters?token=ltlargequotes&MODULE=$module&VERSION=$version"

        sh """
           #!/bin/bash
    
            rm -rf $docker_dir$moduleMain/$moduleMain.$ext
            if [ -d $docker_dir$moduleMain/$moduleMain ]; then
              rm -rf $docker_dir$moduleMain/$moduleMain
            fi
    
            if [ -d $docker_dir$moduleMain/configs/$moduleMain ]; then
              rm -rf $docker_dir$moduleMain/configs/$moduleMain
            fi
    
            cp /a/jenkins/jobs/Promote_Module_Branch_LT/workspace/target/$moduleMain.$ext $docker_dir$moduleMain/.
        
            docker build --build-arg moduleName=$buildArg -t $repoServer/$moduleLower:$version --pull=true $docker_dir$moduleMain/
            docker push $repoServer/$moduleLower:$version
    
            docker images $repoServer/$moduleLower -q | xargs -r docker rmi -f
            rm -rf $docker_dir$moduleMain/$moduleMain.$ext

            echo "Triggering job: $url"
            curl -f "$url"
    
            exit 0
        """

    } catch(Exception e) {
        sparkSend credentialsId: 'a3240800-4aba-48b0-888b-e5db5997633a',
                message: '[$JOB_NAME]\n$BUILD_URL\nERROR: ' + e.getMessage(),
                messageType: 'text',
                spaceList: [[spaceId: 'Y2lzY29zcGFyazovL3VzL1JPT00vMDA1MWM5NTAtOTMzMS0xMWU3LTg5ZjQtZGZjYmUxMDlhMjI0',
                             spaceName: 'CCRC Jenkins Deployments']]

        throw e
    }
}