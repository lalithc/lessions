node('Deployer') {
    try {
        def module = "${MODULE}"
        def version = "${VERSION}"
        def deploysrver = "${DOCKER_NPRD_SRVR}"
        stage 'Stage 1'
        checkout scm

        def api = load("jenkins/api.groovy")
        String[] hosts = api.getHostListByModule("lt-main", module)
        if (hosts.size() <= 0) {
            throw new Exception("Module $module is not supported in LT! Please ensure capitalization is correct!")
        }

        def rel_mgr = load("jenkins/rel_mgr.groovy")
        rel_mgr(module, "", "CCRC_LT", "lt-branch", version)
        sleep(10 as long)

        stage 'Stage 2'
        def puppet = load("jenkins/puppet_apply.groovy")

        def moduleLower = module.toLowerCase()
        for(i = 0; i < hosts.size(); i++) {
            def host = hosts[i]
            stage "Stage $host"

            puppet(host, moduleLower, deploysrver, "ccrc_lt", "ccrccloudop")
        }

        print("LT Main Deployment for module $module complete!")
    } catch(Exception e) {
        sparkSend credentialsId: 'a3240800-4aba-48b0-888b-e5db5997633a',
                message: '[$JOB_NAME]\n$BUILD_URL\nERROR: ' + e.getMessage(),
                messageType: 'text',
                spaceList: [[spaceId: 'Y2lzY29zcGFyazovL3VzL1JPT00vMDA1MWM5NTAtOTMzMS0xMWU3LTg5ZjQtZGZjYmUxMDlhMjI0',
                             spaceName: 'CCRC Jenkins Deployments']]

        throw e
    }
}