node('master') {
	try {
	    def env = "lt-main"
	    /* def deploys = [:]
	    def switch_bg = [:]
	    def disable_hotfix = [:]
	    def scale_up = [:]
	    def scale_down = [:]
	    String bgtype
	    String bg */
 	    def automationsrvr = "${AUTOMATION_SRVR}"
 	    def bgtype = "blue"
 	    
	    stage '0'
	    checkout scm
	    
	    stage 'Promote Versions'
	    def promote_version = load("jenkins/util/promote_version.groovy")
	    promote_version("all", "stg-main", "lt-main",automationsrvr)
	
	    stage 'Module Version Data'
	    def api = load("jenkins/api.groovy")
	    def modules = api.getCAEModules(env,"",automationsrvr)
	    def deployerNode = api.getDeployer(automationsrvr,"5000",env)
	
	    node("$deployerNode") {
	        stage 'Stage Checkout'
	        checkout scm
	
	        //stage 'Task setup'
	        def deploy_all = load("jenkins/util/deploy_cae_all.groovy")
	        def scale_all = load("jenkins/util/scale_all_replica.groovy")
	        
	        /* def blue_green_switch = load("jenkins/util/blue_green_switch.groovy")
	        //def scale_all = load("jenkins/util/scale_all_replica.groovy")
	        //def enable_disable_hotfix = load("jenkins/util/hotfix_enable_disable.groovy")
	        bg = api.getEnvs(env)['blue_green']
	
	        if(bg == "blue") {
	            bgtype = "green"
	        } else {
	            bgtype = "blue"
	        }
	        disable_hotfix["Disable Hotfixes"] = {
	            node("$deployerNode") {
	                enable_disable_hotfix(env, "N")
	            }
	        } */
	        

	        stage "Deploy modules"
	        deploys = deploy_all(modules, deployerNode, env, bgtype, automationsrvr)
	        scale_up = scale_all(modules, deployerNode, env, bgtype, true, deployerNode)
	        
	        //parallel deploys
	        /* switch_bg["Switch_To_$bgtype"] = {
	            node("$deployerNode") {
	                blue_green_switch("stagehaproxy", "ltmainhaproxy", env, bgtype)
	            }
	        } */
	        //scale_down = scale_all(modules, deployerNode, env, bg, false)
	        
	    }
	
	    def exceptions = []
	
	    wrapParallel(deploys, "Deploy Blue Versions", exceptions)
	    //wrapParallel(disable_hotfix, "Disable hotfixes for $env", exceptions)
	    //wrapParallel(switch_bg, "Switch to $bgtype", exceptions)
	    //wrapParallel(scale_down, "Scale down $bg Versions", exceptions)
	    wrapParallel(scale_up, "Scale up Blue Versions", exceptions)
	
	    if (!exceptions.isEmpty()) {
	        throw exceptions[0]
	    } 
	} catch(Exception e) {
	    sparkSend credentialsId: '0c60e710-d3ee-4e5b-aac0-9d48100ad45f',
	            message: '[$JOB_NAME]\n$BUILD_URL\nERROR: ' + e.getMessage(),
	            messageType: 'text',
	            spaceList: [[spaceId: 'Y2lzY29zcGFyazovL3VzL1JPT00vM2U3YjMyNTAtYTBiNy0xMWU3LTkxZmQtMTE2Nzc2Njg4MWU0',
	                         spaceName: 'CCRC Jenkins Release Deployments']]
	
	    throw e
	}
}	

void wrapParallel(map, stageMessage, exceptionList) {
    try {
        stage "$stageMessage"
        parallel map
    } catch (Exception e) {
        exceptionList.add(e)
    }
}
