#!/bin/sh

if [ $# -ne 2 ]; then
  echo "Not enough arguments! Required: [module] [version] [buildNo]"
  exit 1
fi

module=$1
buildNo=$2
version=`xmlstarlet sel -N s=http://maven.apache.org/POM/4.0.0 -t -v "/s:project/s:version" /a/jenkins/jobs/Promote_Module_Branch_LT/workspace/pom.xml`

versionFull="${version}-LT${buildNo}"

deployServer="ccrc-build-5.cisco.com"

echo "Triggering deploy job for module $module with version ${versionFull} on server $deployServer"

url1="http://$deployServer:8080/jenkins/job/Deploy_Module_Branch_LT-CAE/buildWithParameters?token=ltlargequotes&MODULE=$module&VERSION=$versionFull"
echo "OpenStack Job: $url1"
curl -f "$url1"