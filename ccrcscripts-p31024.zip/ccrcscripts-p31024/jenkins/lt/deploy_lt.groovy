try {
    def tasks1 = [:]
    def tasks2 = [:]
    def deploysrver = "${DOCKER_NPRD_SRVR}"

    node('Deployer') {
        stage 'Stage Checkout'
        checkout scm

        def rel_mgr = load("jenkins/rel_mgr.groovy")
        rel_mgr("all", "CCRC_STAGE", "CCRC_LT", "lt-main", null,deploysrver)
        sleep(10 as long)

        stage 'Rel Mgr'
        def api = load("jenkins/api.groovy")
        def splitter = load("jenkins/deployment_set_splitter.groovy")

        def env = "lt-main"
        def exclusion_list = []
        exclusion_list.add("ccrcauthproxy")
        exclusion_list.add("ccrcdataservices")

        stage 'Module Data'
        def modules = api.getModuleDataByEnv(env, "")

        stage 'Sets Mapping'
        def maps = splitter.map_module_host_maps(modules, env, exclusion_list)
        def sets = splitter.split_into_sets(maps['module_hosts'], maps['host_modules'])
        print "Set Allocation Complete:\n"
        print sets

        def set_1 = sets['1']
        def set_2 = sets['2']

        stage 'Task setup'
        def puppet = load("jenkins/puppet_apply.groovy")

        for (kv in splitter.mapToList(set_1)) {
            def host = kv[0].toString()
            def moduleList = kv[1].join(",").toLowerCase()

            if (moduleList != "") {
                tasks1["${host}"] = {
                    node('Deployer') {
                        puppet(host, moduleList, deploysrver, "ccrc_lt", "ccrccloudop")
                    }
                }
            }
        }

        for (kv in splitter.mapToList(set_2)) {
            def host = kv[0].toString()
            def moduleList = kv[1].join(",").toLowerCase()

            if (moduleList != "") {
                tasks2["${host}"] = {
                    node('Deployer') {
                        puppet(host, moduleList, deploysrver, "ccrc_lt", "ccrccloudop")
                    }
                }
            }
        }
    }

    stage 'Set 1'
    parallel tasks1

    stage 'Sleep'
    sleep(30)

    stage 'Set 2'
    parallel tasks2
} catch (Exception e) {
    sparkSend credentialsId: 'a3240800-4aba-48b0-888b-e5db5997633a',
            message: '[$JOB_NAME]\n$BUILD_URL\nERROR: ' + e.getMessage(),
            messageType: 'text',
            spaceList: [[spaceId: 'Y2lzY29zcGFyazovL3VzL1JPT00vMDA1MWM5NTAtOTMzMS0xMWU3LTg5ZjQtZGZjYmUxMDlhMjI0',
                         spaceName: 'CCRC Jenkins Deployments']]

    throw e
}