node('master') {
    try {
        def module = "${MODULE}"
        def versionFull = "${VERSION}"
        def env = "lt-main"
        String generated_dir = "/apps/ccrckubernetes_generated"
        def automationsrvr = "${AUTOMATION_SRVR}"

        stage 'Stage 0'
        checkout scm

        def api = load("jenkins/api.groovy")
        def data = api.getModuleData(module,automationsrvr)
        def servicename = data['service_name']
        def ext = data['ext']
        def imagename = "${servicename}main"

        sh """
        #!/bin/bash
    
        rm -rf ${generated_dir}/${module}-main/${module}-main.${ext}
        cp /a/jenkins/jobs/Promote_Module_Branch_LT/workspace/target/${module}-main.$ext $generated_dir/${module}-main/.
        docker build --no-cache=true --build-arg moduleName=$module -t containers.cisco.com/ccw_renewal/$imagename:$versionFull --pull=true ${generated_dir}/${module}-main/
        docker push containers.cisco.com/ccw_renewal/$imagename:$versionFull
        docker rmi containers.cisco.com/ccw_renewal/$imagename:$versionFull
        """

        def envObj = api.getEnvs(env,automationsrvr)
        def replicas = data['envs'][env]['replicas']
        def deployer = load("jenkins/util/deploy_cae.groovy")
		def deployerNode = api.getDeployer(automationsrvr,"5000",env)
        
        def bgtype
        if(data['bg_enabled'] == 'N') {
            bgtype = "cyan"
        } else {
            /*if(envObj['hotfix_enabled'] == 'Y') {
                bgtype = envObj['blue_green']
            } else {
                current_bg = envObj['blue_green']
                if(current_bg == "blue") {
                    bgtype = "green"
                } else {*/
                    bgtype = "blue"
                //}
            //}
        }

        node("$deployerNode") {
            checkout scm
            deployer(module, env, versionFull, servicename, bgtype, replicas,automationsrvr)
        }

        def update_version = load("jenkins/util/update_version.groovy")
        update_version(module, env, versionFull,automationsrvr)
    } catch (Exception e) {
        sparkSend credentialsId: 'a3240800-4aba-48b0-888b-e5db5997633a',
                message: '[$JOB_NAME]\n$BUILD_URL\nERROR: ' + e.getMessage(),
                messageType: 'text',
                spaceList: [[spaceId: 'Y2lzY29zcGFyazovL3VzL1JPT00vMDA1MWM5NTAtOTMzMS0xMWU3LTg5ZjQtZGZjYmUxMDlhMjI0',
                             spaceName: 'CCRC Jenkins Deployments']]

        throw e
    }
}