import groovy.json.JsonSlurper

def call(String moduleInput, String sourceEnv, String targetEnv, String env, String version, String project="", String deploysrver) {
    if(targetEnv == "") {
        return
    }

    def modules = moduleInput

    if(moduleInput == "all") {
        def jsonSlurper = new JsonSlurper()

        def p = project != "" ? "&project=$project" : ""
        def text = ['bash', '-c', "curl '$deploysrver:5000/modules?env=$env$p'"].execute().text
        def moduleMap = jsonSlurper.parseText(text)

        def moduleList = []
        for(module in moduleMap) {
            moduleList.add(module.key)
        }

        modules = moduleList.join(",")
    }


    def buildServers = ['ccrc-build-4.cisco.com',deploysrver,'ccrc-build-6.cisco.com']

    if(sourceEnv == "") {
        print "Executing RelMgr for ${env} to ${targetEnv} for the following modules: ${modules}\n"
    } else {
        print "Executing RelMgr for ${env} from ${sourceEnv} to ${targetEnv} for the following modules: ${modules}\n"
    }

    def uri
    switch (env) {
        case 'lt-branch':
            uri = "installModuleByBuildTypeDocker?versionNumber=${version}&noOfDockers=5&"
            break
        case 'dev-main':
            uri = "installModuleByBuildTypeDocker?versionNumber=${version}&noOfDockers=5&"
            break
        case 'dev-rel':
            uri = "installModuleByBuildTypeDockerPS?versionNumber=${version}&noOfDockers=5&"
            break
        case ~/stg\d*-main/:
            uri = "deployAllStageModulesByBuildTypeDocker?env=${sourceEnv}&buildType=RS&"
            break
        case ~/(stg\d*-rel)|((pre-)*prd\d*)/:
            uri = "deployAllStageModulesByBuildTypeDocker?env=${sourceEnv}&buildType=PS&"
            break
        case 'lt-main':
            uri = "deployAllStageModulesByBuildTypeDocker?env=${sourceEnv}&buildType=RS&"
            break
    }

    def module
    if(moduleInput != "all" && (env == "dev-main" || env == "dev-rel" || env == "lt-branch")) {
        module = "&module=${modules}"
    } else {
        module = "&modules=${modules}"
    }

    for(server in buildServers) {
        String url = "http://${server}:8080/RelMngr-1.0/${uri}newEnv=$targetEnv$module"
        print "Hitting RelMngr URL: $url\n"
        String response = ["curl", "${url}"].execute().text

        if(response) {
            print("$response\n")
            throw new Exception("Error executing RelMngr! " + response)
        }
    }

    print "RelMngr Requests complete\n"
}

return this