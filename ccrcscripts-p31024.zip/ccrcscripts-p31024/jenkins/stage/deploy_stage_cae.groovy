node('master') {
    try {
        def module = "${MODULE}"
        def servicename = "${SERVICENAME}"
        def env = "${ENV}"
        def buildsrvr = "${BUILD_SRVR}"
        def deploysrver = "${DOCKER_NPRD_SRVR}"
        def automationsrvr = "${AUTOMATION_SRVR}"

        stage 'Stage 0'
        checkout scm
        def promote_version = load("jenkins/util/promote_version.groovy")
        promote_version(module, "dev-main", "stg-main",automationsrvr)

        def api = load("jenkins/api.groovy")
        String versionFull = api.getVersion(module, 'stg1-main',automationsrvr)
        def data = api.getModuleData(module,automationsrvr)
        def envObjs = api.getEnvs(env,automationsrvr)
        def stg1_replicas = data['envs']['stg1-main']['replicas']
        def stg2_replicas = data['envs']['stg2-main']['replicas']
        def deployer = load("jenkins/util/deploy_cae.groovy")
		def deployerNodedc1 = api.getDeployer(automationsrvr,"5000","stg1-main")
		def deployerNodedc2 = api.getDeployer(automationsrvr,"5000","stg2-main")

        def stg1_bgtype
        def stg2_bgtype
        if(data['bg_enabled'] == 'N') {
            stg1_bgtype = "cyan"
            stg2_bgtype = "cyan"
        } else {
            stg1_bgtype = envObjs['stg1-main']['blue_green']
            stg2_bgtype = envObjs['stg2-main']['blue_green']
        }


        deploys = [:]
        deploys["${module}-stg1-main"] = {
            node("$deployerNodedc1") {
                checkout scm
                deployer(module, 'stg1-main', versionFull, servicename, stg1_bgtype, stg1_replicas,automationsrvr)
            }
        }
		
        deploys["${module}-stg2-main"] = {
            node("$deployerNodedc2") {
                checkout scm
                deployer(module, 'stg2-main', versionFull, servicename, stg2_bgtype, stg2_replicas,automationsrvr)
           }
        }

        parallel deploys
    } catch (Exception e) {
        sparkSend credentialsId: 'a3240800-4aba-48b0-888b-e5db5997633a',
                message: '[$JOB_NAME]\n$BUILD_URL\nERROR: ' + e.getMessage(),
                messageType: 'text',
                spaceList: [[spaceId: 'Y2lzY29zcGFyazovL3VzL1JPT00vMDA1MWM5NTAtOTMzMS0xMWU3LTg5ZjQtZGZjYmUxMDlhMjI0',
                             spaceName: 'CCRC Jenkins Deployments']]

        throw e
    }
}
