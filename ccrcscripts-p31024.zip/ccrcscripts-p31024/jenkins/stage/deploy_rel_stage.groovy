node('Deployer') {
    try {
        def module = "${MODULE}"
        def hosts = "${HOSTS}"

        stage 'Stage 1'
        checkout scm

        def rel_mgr = load("jenkins/rel_mgr.groovy")
        rel_mgr(module, "CCRC_DEV", "CCRC_STAGE", "stg1-rel", null)
        rel_mgr(module, "CCRC_DEV", "CCRC_STAGE", "stg2-rel", null)

        def moduleLower = module.toLowerCase()

        stage 'Stage 2'
        def hostList = hosts.split(",")
        def puppet = load("jenkins/puppet_apply.groovy")

        for(i = 0; i < hostList.size(); i++) {
            def host = hostList[i]
            stage "Stage $host"

            puppet(host, moduleLower, "ccrc-build-6.cisco.com", "ccrc_stage", "ccrccloudop")
        }

        print("STG Rel Deployment for module $module complete!")
    } catch (Exception e) {
        sparkSend credentialsId: '0c60e710-d3ee-4e5b-aac0-9d48100ad45f',
                message: '[$JOB_NAME]\n$BUILD_URL\nERROR: ' + e.getMessage(),
                messageType: 'text',
                spaceList: [[spaceId: 'Y2lzY29zcGFyazovL3VzL1JPT00vM2U3YjMyNTAtYTBiNy0xMWU3LTkxZmQtMTE2Nzc2Njg4MWU0',
                             spaceName: 'CCRC Jenkins Release Deployments']]

        throw e
    }
}