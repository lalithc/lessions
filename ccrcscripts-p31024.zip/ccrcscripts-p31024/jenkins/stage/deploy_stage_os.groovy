node('Deployer') {
    try {
        def module = "${MODULE}"
        def hosts = "${HOSTS}"
        def deploysrver = "${DOCKER_NPRD_SRVR}"

        stage 'Stage 1'
        checkout scm

        def rel_mgr = load("jenkins/rel_mgr.groovy")
        rel_mgr(module, "CCRC_DEV", "CCRC_STAGE", "stg1-main", null)

        def moduleLower = module.toLowerCase()

        stage 'Stage 2'
        def hostList = hosts.split(",")
        def puppet = load("jenkins/puppet_apply.groovy")

        for(i = 0; i < hostList.size(); i++) {
            def host = hostList[i]
            stage "Stage $host"

            puppet(host, moduleLower, "$deploysrver", "ccrc_stage", "ccrccloudop")
        }

        print("STG Main Deployment for module $module complete!")
    } catch (Exception e) {
        sparkSend credentialsId: 'a3240800-4aba-48b0-888b-e5db5997633a',
                message: '[$JOB_NAME]\n$BUILD_URL\nERROR: ' + e.getMessage(),
                messageType: 'text',
                spaceList: [[spaceId: 'Y2lzY29zcGFyazovL3VzL1JPT00vMDA1MWM5NTAtOTMzMS0xMWU3LTg5ZjQtZGZjYmUxMDlhMjI0',
                             spaceName: 'CCRC Jenkins Deployments']]

        throw e
    }
}