node('master') {
    try {
        def module = "${MODULE}"
        def servicename = "${SERVICENAME}"
        def env = "${ENV}"
        def buildsrvr = "${BUILD_SRVR}"
        def deploysrver = "${DOCKER_NPRD_SRVR}"
        def automationsrvr = "${AUTOMATION_SRVR}"

        stage 'Stage 0'
        checkout scm
        def promote_version = load("jenkins/util/promote_version.groovy")
        promote_version(module, "dev-rel", "stg-rel",automationsrvr)

        def api = load("jenkins/api.groovy")
        String versionFull = api.getVersion(module, 'stg1-rel',automationsrvr)
        def data = api.getModuleData(module,automationsrvr)
        def envObjs = api.getEnvs(env,automationsrvr)
        def stg1_replicas = data['envs']['stg1-rel']['replicas']
        def stg2_replicas = data['envs']['stg2-rel']['replicas']
        
        def deployer = load("jenkins/util/deploy_cae.groovy")
        def deployerNodedc1 = api.getDeployer(automationsrvr,"5000","stg1-rel")
		def deployerNodedc2 = api.getDeployer(automationsrvr,"5000","stg2-rel")

        def stg1_bgtype = get_bgtype(envObjs['stg1-rel'], data['bg_enabled'])
        def stg2_bgtype = get_bgtype(envObjs['stg2-rel'], data['bg_enabled'])

        deploys = [:]
        deploys["${module}-stg1-rel"] = {
            node("$deployerNodedc1") {
                checkout scm
                deployer(module, 'stg1-rel', versionFull, servicename, stg1_bgtype, stg1_replicas,automationsrvr)
            }
        }
       deploys["${module}-stg2-rel"] = {
            node("$deployerNodedc2") {
                checkout scm
                deployer(module, 'stg2-rel', versionFull, servicename, stg2_bgtype, stg2_replicas,automationsrvr)
            }
        }

        parallel deploys

    } catch (Exception e) {
        sparkSend credentialsId: 'a3240800-4aba-48b0-888b-e5db5997633a',
                message: '[$JOB_NAME]\n$BUILD_URL\nERROR: ' + e.getMessage(),
                messageType: 'text',
                spaceList: [[spaceId: 'Y2lzY29zcGFyazovL3VzL1JPT00vMDA1MWM5NTAtOTMzMS0xMWU3LTg5ZjQtZGZjYmUxMDlhMjI0',
                             spaceName: 'CCRC Jenkins Deployments']]

        throw e
    }
}

static String get_bgtype(def envObj, String bg_enabled) {
    String bgtype
    if(bg_enabled == 'N') {
        bgtype = "cyan"
    } else {
        if(envObj['hotfix_enabled'] == 'Y') {
            bgtype = envObj['blue_green']
        } else {
            def current_bg = envObj['blue_green']
            if(current_bg == "blue") {
                bgtype = "green"
            } else {
                bgtype = "blue"
            }
        }
    }

    return bgtype
}