try {
    def tasks1 = [:]
    def tasks2 = [:]
    def puppet_server = "ccrc-build-6.cisco.com"

    node('Deployer') {
        stage 'Stage Checkout'
        checkout scm

        def rel_mgr = load("jenkins/rel_mgr.groovy")
        rel_mgr("all", "CCRC_DEV", "CCRC_STAGE", "stg1-rel", null)
        sleep(10 as long)

        stage 'Rel Mgr'
        def api = load("jenkins/api.groovy")

        def env = "stg1-rel"
        def exclusion_list = []

        stage 'Module Data'
        def modules = api.getModuleDataByEnv(env, "")

        stage 'Sets Mapping'
        def splitter = load("jenkins/deployment_set_splitter.groovy")
        def maps = splitter.map_module_host_maps(modules, env, exclusion_list)
        def sets = splitter.split_into_sets(maps['module_hosts'], maps['host_modules'])
        print "Set Allocation Complete:\n"
        print sets

        def set_1 = sets["1"]
        def set_2 = sets["2"]

        stage 'Task setup'
        def puppet = load("jenkins/puppet_apply.groovy")

        for (kv in splitter.mapToList(set_1)) {
            def host = kv[0].toString()
            def moduleList = kv[1].join(",").toLowerCase()

            if (moduleList != "") {
                tasks1["${host}"] = {
                    node('Deployer') {
                        puppet(host, moduleList, puppet_server, "ccrc_stage", "ccrccloudop")
                    }
                }
            }
        }

        for (kv in splitter.mapToList(set_2)) {
            def host = kv[0].toString()
            def moduleList = kv[1].join(",").toLowerCase()

            if (moduleList != "") {
                tasks2["${host}"] = {
                    node('Deployer') {
                        puppet(host, moduleList, puppet_server, "ccrc_stage", "ccrccloudop")
                    }
                }
            }
        }
    }

    stage 'Set 1'
    parallel tasks1

    stage 'Set 2'
    parallel tasks2
} catch(Exception e) {
    sparkSend credentialsId: '0c60e710-d3ee-4e5b-aac0-9d48100ad45f',
            message: '[$JOB_NAME]\n$BUILD_URL\nERROR: ' + e.getMessage(),
            messageType: 'text',
            spaceList: [[spaceId: 'Y2lzY29zcGFyazovL3VzL1JPT00vM2U3YjMyNTAtYTBiNy0xMWU3LTkxZmQtMTE2Nzc2Njg4MWU0',
                         spaceName: 'CCRC Jenkins Release Deployments']]

    throw e
}