#!/bin/bash

if [ $# -ne 3 ]; then
  echo "Not enough arguments! Required: [module] [project] [env]"
  exit 1
fi

module=$1
project=$2
env=$3

deployServer="ccrc-nprd-docker-build"


moduleLower=$(echo "$module" | tr '[:upper:]' '[:lower:]')
success=`curl http://ccrc-sc-dev.cisco.com/${project}-main/${moduleLower}/ping`

if [[ "$success" != "SUCCESS" ]]; then
    echo "/ping validation failed! Instead of SUCCESS, got: ${success}"
    #exit 1
else
    echo "/ping validation passed! Proceeding with deployment!"
fi

job_name=""
job_name_cae=""
job_name2_cae=""
if [[ ${env} == *"-main"* ]]; then
    job_name="${module}-main-Stg"
    job_name_cae="${module}_CAE-main-Stg"
    job_name2="CCRCDownloadNginx_CAE-main-Stg"
    job_name2_cae="CCRCDownloadNginx_CAE-main-Stg"
else
    job_name="${module}-Stg"
    job_name2="CCRCDownloadNginx-Stg"
fi

token="${moduleLower}deploy"
token_cae="${moduleLower}-cae"
token2="ccrcdownloadnginxdeploy"
token2_cae="ccrcdownloadnginx-cae"

hdr="jenkinsapi:a485dabedf0743de305098ea5f963cd8"
url="http://$deployServer:8080/job/${job_name}/buildWithParameters?token=${token}"
echo "Triggering deploy job $job_name on server $deployServer: $url"

curl -f --user "$hdr" ${url}

if [[ ${job_name_cae} != "" ]]; then
    urlcae="http://$deployServer:8080/job/${job_name_cae}/buildWithParameters?token=${token_cae}"
    echo "Triggering deploy job $job_name_cae on server $deployServer: $urlcae"

    curl -f --user "$hdr" ${urlcae}
fi


if [[ ${module} == "CCRCDownload" ]]; then
    # sleep to prevent download and download nginx running at same time
    sleep 60
    url2="http://$deployServer:8080/job/${job_name2}/buildWithParameters?token=${token2}"
    echo "Triggering deploy job $job_name2 on server $deployServer: $url2"

    curl -f --user "$hdr" ${url2}

    if [[ ${job_name2_cae} != "" ]]; then
        urlcae2="http://$deployServer:8080/job/${job_name2_cae}/buildWithParameters?token=${token2_cae}"
        echo "Triggering deploy job $job_name2_cae on server $deployServer: $urlcae2"

        curl -f --user "$hdr" ${urlcae2}
    fi
fi
