try {
    def tasks = [:]
    def env = "${ENV}"
    def cisco_life = "${CISCO_LIFE}"
    def deploysrver = "${DOCKER_NPRD_SRVR}"

    node('Deployer') {
        stage 'Stage Setup'
        checkout scm

        def rel_mgr = load("jenkins/rel_mgr.groovy")
        def puppet_server
        // def build5 = deploysrver
        def build6 = "ccrc-build-6.cisco.com"
        switch (env) {
            case 'dev-main':
                rel_mgr("all", "", "CCRC_DEV", env, null)
                puppet_server = deploysrver
                break
            case ~/stg\d-main/:
                rel_mgr("all", "CCRC_DEV", "CCRC_STAGE", env, null)
                puppet_server = deploysrver
                break
            case 'lt-main':
                rel_mgr("all", "CCRC_STAGE", "CCRC_LT", env, null)
                puppet_server = deploysrver
                break
            default:
                puppet_server = build6
                break
        }

        def api = load("jenkins/api.groovy")
        String[] envList = env.split(",")
        String[] hosts = api.getHostList(envList)

        def puppet = load("jenkins/puppet_apply.groovy")

        for (i = 0; i < hosts.size(); i++) {
            def host = hosts[i]
            tasks["${host}"] = {
                node('Deployer') {
                    puppet(host, 'pull_image', puppet_server, cisco_life, "ccrccloudop")
                }
            }
        }

        stage 'Stage Execution'
    }

    parallel tasks
} catch(Exception e) {
    sparkSend credentialsId: '0c60e710-d3ee-4e5b-aac0-9d48100ad45f',
            message: '[$JOB_NAME]\n$BUILD_URL\nERROR: ' + e.getMessage(),
            messageType: 'text',
            spaceList: [[spaceId: 'Y2lzY29zcGFyazovL3VzL1JPT00vM2U3YjMyNTAtYTBiNy0xMWU3LTkxZmQtMTE2Nzc2Njg4MWU0',
                         spaceName: 'CCRC Jenkins Release Deployments']]

    throw e
}