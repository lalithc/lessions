node('master') {
    try {
        def module = "${MODULE}"
        def servicename = "${SERVICENAME}"
        def env = "${ENV}"
        def jobDesc= "${JOBNAME}"
        def buildsrvr = "${BUILD_SRVR}"
        def deploysrver = "${DOCKER_PRD_SRVR}"
        def automationsrvr = "${AUTOMATION_SRVR}"


        stage 'Stage 0'
        checkout scm
        def api = load("jenkins/api.groovy")
        def deployerNode = api.getDeployer(automationsrvr,"5000",env)
        String versionFull = api.getVersion(module, env,automationsrvr)
        def dl_data
        if(jobDesc == 'all'){
          dl_data=api.getAllJobsConfigsDataFromES(module)
        }else{
          dl_data=api.getJobConfigsDataFromES(module, jobDesc)
        }
        print dl_data
        
       def deployer = load("jenkins/dataload/dl_deploy_cae.groovy")
        node("$deployerNode") {
            dl_data.each { jobData ->
                if (jobData._source['dc1'] == 'Y')
                    deployer(module, env, versionFull, jobData._source['job_name'], jobData._source['min_heap'], jobData._source['max_heap'], jobData._source['cpu_limit'], jobData._source['cpu_req'], jobData._source['mem_limit'], jobData._source['mem_req'])
            }
        }

    } catch (Exception e) {
        sparkSend credentialsId: 'a3240800-4aba-48b0-888b-e5db5997633a',
                message: '[$JOB_NAME]\n$BUILD_URL\nERROR: ' + e.getMessage(),
                messageType: 'text',
                spaceList: [[spaceId: 'Y2lzY29zcGFyazovL3VzL1JPT00vMDA1MWM5NTAtOTMzMS0xMWU3LTg5ZjQtZGZjYmUxMDlhMjI0',
                             spaceName: 'CCRC Jenkins Deployments']]

        throw e
    }
}