def call(String module, String env, String version, String jobname, String minheap, String maxheap, String cpulimit, String cpureq, String memlimit, String memreq) {
    // def main_or_rel = load("jenkins/util/main_or_rel.groovy")

    try {
        String base_envs = "/apps/environments"
        String generated_dir = "/apps/dataloader"
        String namespace = getNamespace(env)
        String normalized_env = getNormalizedEnv(env)
        String normalized_cae_env = getCAEEnv(normalized_env)
        String cae_env = getCAEEnv(env)
        String versionFolder = "$base_envs/$normalized_cae_env"
        String main_rel = getmain_or_rel(env)
        print ("env main_rel: $main_rel")
        
        String deploy_config = "deployconfig-${cae_env}"
        // Copy generated config to environments folder and set version to be latest
        sh """
        #!/bin/bash
        
        mkdir -p ${versionFolder}/${module}
        rm -f ${versionFolder}/${module}/deployconfig-${module}.yaml
        rm -f ${versionFolder}/${module}/${deploy_config}.yaml
        rm -f ${versionFolder}/${module}/${jobname}-${deploy_config}.yaml
        sed -e "s/serviceversion/${version}/" -e "s/jobname/${jobname}/" -e "s/svcreplica/1/" -e "s/minheap/${minheap}/" -e "s/maxheap/${maxheap}/" -e "s/cpulimit/${cpulimit}/" -e "s/cpureq/${cpureq}/" -e "s/memlimit/${memlimit}/" -e "s/memreq/${memreq}/" $generated_dir/${module}-${main_rel}/deployconfig-template-${cae_env}.yaml >> ${versionFolder}/${module}/${jobname}-${deploy_config}.yaml
       
        if ! oc get deployment $jobname -n ${namespace} ; then
            oc create -f ${versionFolder}/${module}/${jobname}-${deploy_config}.yaml -n ${namespace}
        else
            oc replace -f ${versionFolder}/${module}/${jobname}-${deploy_config}.yaml -n ${namespace}
        fi
        """
        // Force deployment even if image did not change
        try {
            sh """ 
            oc rollout latest deployment/${jobname} -n ${namespace} 
            oc rollout latest deployment/${jobname} -n ${namespace}
            oc rollout latest deployment/${jobname} -n ${namespace}
            oc rollout latest deployment/${jobname} -n ${namespace} 
            oc rollout latest deployment/${jobname} -n ${namespace} 
            oc rollout latest deployment/${jobname} -n ${namespace} 
            """
        } catch(Exception ignored) {
            // Ignore error
        }

        int count = 0
        while(true) {
            try {
                sh """
        	sleep 2s
        	oc rollout status deployment/${jobname} -n ${namespace}
        	"""
                break;
            } catch(hudson.AbortException ex) {
                println(ex)
                if(count++ == 4){
                    throw ex
                }
            }
        }

       // sh """
       // sleep 10s
       // oc rollout status deployment/${jobname} -n ${namespace}
       // """
        if(normalized_cae_env == "prd") {
            print(pushToCDA(module, version))
        }
   } catch(Exception e) {
       // sparkSend credentialsId: '0c60e710-d3ee-4e5b-aac0-9d48100ad45f',
        //        message: '[$JOB_NAME]\n$BUILD_URL\nERROR: deployment of module ' + module + ' job: '+jobname
         //       ' with version ' + version + ' has failed! ' + e.getMessage(),
          //      messageType: 'text',
           //     spaceList: [[spaceId: 'Y2lzY29zcGFyazovL3VzL1JPT00vM2U3YjMyNTAtYTBiNy0xMWU3LTkxZmQtMTE2Nzc2Njg4MWU0',
           //                  spaceName: 'CCRC Jenkins Release Deployments']]

        throw e
    }
}


static def getmain_or_rel(String env) {
    String reltype
    switch (env) {
        case ~/^.+-main$/:
            reltype = "main"
            break
        case ~/^.*(-rel|prd\d*)$/:
            reltype = "rel"
            break
        default:
            reltype = ""
    }
    return reltype
}


static def getNamespace(String env) {
    switch(env) {
        case "stg2-rel":
            return "ccwr-stage-rel"
        case "stg1-rel":
            return "ccwr-stage-rel"
        case "stg2-main":
            return "ccwr-stage"
        case "stg1-main":
            return "ccwr-stage"
        case "dev-main":
            return "ccwr-dev"
        case "dev-rel":
            return "ccwr-dev-rel"
        case "lt-main":
            return "ccwr-lt"
        case ~/^pre-prd\d$/:
            return "ccwr-prepd"
        case ~/^prd\d$/:
            return "ccwr-prod"
    }
}

static def getCAEEnv(String env) {
    return env.replace("-", "")
}

static def getNormalizedEnv(String env) {
    return env.replaceFirst(/[1-9]/, "")
}

static def pushToCDA(String module, String versionFull) {
    String url = "https://dftapi.cisco.com/code/cda/event-proxy/v2/software/custom-deployment-event"
    String moduleLower = module.toLowerCase()
    String baseVersion = versionFull.replaceFirst(/-\d+$/,"")
    String branch = "ccrc-$baseVersion"
    String git_url = "https://git@gitscm.cisco.com/scm/ccwren/${moduleLower}.git"
    String json = "{\"scmUrl\": \"$git_url\", \"scmBranch\": \"$branch\",\"environmentName\": \"prod\",\"releaseName\":\"$baseVersion\",\"version\":\"$versionFull\"}"

    def text = ['bash', '-c', "curl -X POST '$url' -d '$json' -H 'Content-Type: application/json'"].execute().text
    return text
}

return this