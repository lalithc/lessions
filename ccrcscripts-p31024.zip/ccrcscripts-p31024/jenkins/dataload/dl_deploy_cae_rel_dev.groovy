node('master') {
    try {
        def module = "${MODULE}"
        def servicename = "${SERVICENAME}"
        def env = "${ENV}"
        def version = "${Version}"
        def buildNo = "${ReleaseNo}"
        def jobDesc= "${JOBNAME}"
        def ext = "${EXT}"
        def buildsrvr = "${BUILD_SRVR}"
        def deploysrver = "${DOCKER_PRD_SRVR}"
        def automationsrvr = "${AUTOMATION_SRVR}"

        String generated_dir = "/apps/dataloader"
        stage 'Stage 0'
        checkout scm
        def build_image = load("jenkins/util/build_image_cae.groovy")
        String versionFull = build_image(generated_dir, module, servicename, env, version, buildNo, ext, buildsrvr)

        def api = load("jenkins/api.groovy")
        def envObj = api.getEnvs(env,automationsrvr)
        def deployerNode = api.getDeployer(automationsrvr,"5000",env)
        def data = api.getModuleData(module,automationsrvr)
        def deployer = load("jenkins/dataload/dl_deploy_cae.groovy")
        def dl_data
        if(jobDesc == 'all'){
            dl_data=api.getAllJobsConfigsDataFromES(module)
        }else{
            dl_data=api.getJobConfigsDataFromES(module, jobDesc)
        }

        def update_version = load("jenkins/util/update_version.groovy")
        update_version(module, env, versionFull,automationsrvr)
        node("$deployerNode") {
            checkout scm
            dl_data.each { jobData ->
                  if(jobData._source['dc1']=='Y') 
                      deployer(module, env, versionFull, jobData._source['job_name'], jobData._source['min_heap'], jobData._source['max_heap'], jobData._source['cpu_limit'], jobData._source['cpu_req'], jobData._source['mem_limit'], jobData._source['mem_req'])
           }
        }
    } catch (Exception e) {
        sparkSend credentialsId: 'a3240800-4aba-48b0-888b-e5db5997633a',
                message: '[$JOB_NAME]\n$BUILD_URL\nERROR: ' + e.getMessage(),
                messageType: 'text',
                spaceList: [[spaceId: 'Y2lzY29zcGFyazovL3VzL1JPT00vMDA1MWM5NTAtOTMzMS0xMWU3LTg5ZjQtZGZjYmUxMDlhMjI0',
                             spaceName: 'CCRC Jenkins Deployments']]

        throw e
    }
}
