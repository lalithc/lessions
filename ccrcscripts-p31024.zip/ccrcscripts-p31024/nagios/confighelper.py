


import sys
import urllib2
import json



class confighelper:

    def __init__(self):
        """Init the confighelper Class"""
        pass

    def getEnvHostInfo(self,hostsURL,env):
        hostsUrl = urllib2.urlopen(hostsURL)
        print(hostsUrl.getcode())
        if (hostsUrl.getcode() == 200):
          data = hostsUrl.read().decode('utf-8')
          print("<>---"+data)
          hostsData=self.getHostsData(data,env)
          return hostsData
        else:
          print("Received an error from server, cannot retrieve results " + str(hostsUrl.getcode()))

    def getHostsData(self,data, env):
        theHostsJSON = json.loads(data)
        hostArr = theHostsJSON[env]
       # print(hostArr)
        return hostArr

    def getModulesInfo(self, modulesURL,hostsData, env):
        print(hostsData)
        global dicti
        dicti = {}
        for hname in hostsData:
           # print("hname--->" + hname)
           # print("moduleUu--->" + modulesURL+hname)
            moduleUrl = urllib2.urlopen(modulesURL+hname)
            print(moduleUrl.getcode())
            if (moduleUrl.getcode() == 200):
                data = moduleUrl.read().decode('utf-8')
                modulesData = self.getModulesData(data)
                dicti[hname] = modulesData
            else:
                print("Received an error from server, cannot retrieve results " + str(moduleUrl.getcode()))
        #print(json.dumps(dicti))
        return dicti

    def getModulesData(self, moduleData):
        theModuleJSON = json.loads(moduleData)
        return (theModuleJSON.keys())


# urlHostsData = "http://ccrc-nags-prd2-01:5000/hosts?env=dev-main"

# Open the URL and read the data
#  hostsUrl = urllib2.urlopen(urlHostsData)
#  print(hostsUrl.getcode())
#  if (hostsUrl.getcode() == 200):
#     data = hostsUrl.read().decode('utf-8')
#     print(data)
#     hostsData=getHostsData(data,"dev-main")



# else:
#    print("Received an error from server, cannot retrieve results " + str(hostsUrl.getcode()))


# def getHostsData(data,env):
#   theHostsJSON = json.loads(data)
#  hostArr = theHostsJSON[env]
# return hostArr



