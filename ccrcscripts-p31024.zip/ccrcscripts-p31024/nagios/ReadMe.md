## install pynag using pip install
pip install pynag

## Run the following command to generate nagios configurations
python nagiosconfig-generator.py -e dev-main