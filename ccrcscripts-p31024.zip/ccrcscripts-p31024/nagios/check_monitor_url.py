#!/usr/bin/python

# lchennup
#
# Usage: ./check_monitor_url.py -u http://monitor_url

from optparse import OptionParser
import os, sys, urllib2, json
from pprint import pprint
from collections import OrderedDict

UNKNOWN = -1
OK = 0
WARNING = 1
CRITICAL = 2

parser = OptionParser()
parser.add_option('-u', '--url', dest='url')
parser.add_option('-a', '--arg1', dest='arg1')
parser.add_option('-b', '--arg2', dest='arg2')

options, args = parser.parse_args()

if not getattr(options, 'url'):
        print 'CRITICAL - %s not specified' % options.url
        #raise SystemExit, CRITICAL
        sys.exit(CRITICAL)

adres = options.url+"?env="+options.arg1+"&module="+options.arg2

strona = urllib2.urlopen(adres,timeout=30000)


class JSONObject:
    def __init__(self, d):
        self.__dict__ = d


log = strona.read()
jsonstr = json.loads(log,object_hook=JSONObject)
#print jsonstr.status

strona.close()

#print "Result: %s " % jsonstr.description

if jsonstr.status == 'Success':
        print "Ok, Success"
        sys.exit(OK)
elif jsonstr.status == 'Warning':
        print "WARNING, %s " % jsonstr.description
        sys.exit(WARNING)
elif jsonstr.status == 'Failed':
        print "CRITICAL, %s " % jsonstr.description
        sys.exit(CRITICAL)
else:
        print "CRITICAL, --> %s " % jsonstr.description
        sys.exit(CRITICAL)
