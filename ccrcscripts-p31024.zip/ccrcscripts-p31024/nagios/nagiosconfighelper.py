#!/usr/bin/python

import sys
sys.path.insert(1, '/usr/bin/pynag')
from pynag import Model
from pynag.Control import daemon

class nagiosconfighelper:

    def __init__(self):
        """Init the confighelper Class"""
        pass

    def addNewService(self,hostname, servicename,envstr,envgrp,token):
        global envext
        envext = ""
        if (envstr.find('-rel') != -1):
            envext = "_Rel"
        # Create service object
        s = Model.Service()

        # Select filename (optional)
        s.set_filename('/usr/local/nagios/etc/objects/'+hostname+'.cfg')

        # Get a list of all services that fit our search pattern
        search_results = Model.Service.objects.filter(host_name=hostname+'.cisco.com', service_description=servicename+'_Health'+envext)

        if len(search_results) == 0:
            print "no service found for host_name=%s and service_description=%s" % (hostname, servicename+'_Health'+envext)
            # Set some attributes
            s.use = 'common-service'
            s.host_name = hostname+'.cisco.com'
            s.service_description = servicename+'_Health'+envext
            s.check_command = 'check_consul_health_'+str(servicename+envext).lower()+'_'+envstr
            s.set_attribute("_ROOMID",token)
            s.contact_groups = envgrp

            # Save
            s.save()


    def addCommand(self,servicename,envstr,monitorHost):

        global envext
        envext = ""
        if (envstr.find('-rel') != -1):
            envext = "_Rel"
        c = Model.Command()

        # Select filename (optional)
        c.set_filename('/usr/local/nagios/etc/objects/commands.cfg')

        # Get a list of all services that fit our search pattern
        search_results = Model.Command.objects.filter(command_name='check_consul_health_' + str(servicename+envext).lower()+"_"+envstr)

        if len(search_results) == 0:
            print "no command found for host_name=%s and service_description=%s" % (servicename+envext, 'check_consul_health_'+str(servicename+envext).lower()+'_'+envstr)
            # Set some attributes
            c.command_name = 'check_consul_health_'+str(servicename+envext).lower()+'_'+envstr
            c.command_line = '$USER1$/check_monitor_url.py -u http://'+monitorHost+':5000/healthcheck -a '+envstr+' -b '+servicename

            # Save
            c.save()

    def restartNagios(self):
        d = daemon(nagios_bin='/usr/local/nagios/bin',nagios_cfg='/usr/local/nagios/etc/nagios.cfg',nagios_init='/etc/init.d/nagios', sudo=True, shell=None, service_name="nagios", nagios_config=None)
        d.restart()



