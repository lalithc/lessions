#!/usr/bin/python

#  Nagois configuration generator based on the latest modules.
import argparse
import sys
import urllib2
import json
import yaml
from confighelper import confighelper
from nagiosconfighelper import nagiosconfighelper


def main():
     parser = argparse.ArgumentParser(description='Generate Nagios Configuration')
     parser.add_argument('-e', '--env', help='environments - dev-main/dev-rel/stg-main/stg-rel', required=True)

     args = vars(parser.parse_args())
     #args['env'] = "dev-main"
     stream = open("nagios-config.yaml", "r")
     docs = yaml.load(stream)
     #print(docs["nagios_monitor_hosts_"+args['env']])

     cfgHelper = confighelper()
     if args['env'] == 'dev-main':
        urlDevMainHostsData = "http://"+docs["nagios_url_"+args['env']]+"/hosts?env=dev-main"
        urlDevMainModuleURL = "http://"+docs["nagios_url_"+args['env']]+"/modules?env=dev-main&host="
        monitorHosts = docs["nagios_monitor_hosts_"+args['env']]
        print(urlDevMainHostsData)
        # Get Environment Hosts
        devMainHosts = cfgHelper.getEnvHostInfo(urlDevMainHostsData,"dev-main")
        # Get Host and their Modules
        devMainModules = cfgHelper.getModulesInfo(urlDevMainModuleURL,devMainHosts,"dev-main")
        #print("....>"+devMainModules)
        modules = []
        for hostDetails in devMainModules.itervalues():
           modules .extend(hostDetails)
        newmodules = set(modules)
        newmodules = list(newmodules)


        nagioshelper = nagiosconfighelper()
        for monHost in monitorHosts:
            for module in newmodules:
                nagioshelper.addNewService(monHost, module, "dev-main", "CCRCDevAdmins","Y2lzY29zcGFyazovL3VzL1JPT00vZjEwZjkxODAtMWZlNS0xMWU2LTg5NDItNjdhYTk2OWM3NGI4")
                nagioshelper.addCommand(module, "dev-main", docs["nagios_url_"+args['env']])
                nagioshelper.restartNagios()
     elif args['env'] == 'dev-rel':
         urlDevRelHostsData = "http://"+docs["nagios_url_"+args['env']]+"/hosts?env=dev-rel"
         urlDevRelModuleURL = "http://"+docs["nagios_url_"+args['env']]+"/modules?env=dev-rel&host="
         monitorHosts = docs["nagios_monitor_hosts_"+args['env']]
         print(urlDevRelHostsData)
         # Get Environment Hosts
         devRelHosts = cfgHelper.getEnvHostInfo(urlDevRelHostsData, "dev-rel")
         # Get Host and their Modules
         devRelModules = cfgHelper.getModulesInfo(urlDevRelModuleURL, devRelHosts, "dev-rel")
         # print("....>"+devMainModules)
         modules = []
         for hostDetails in devRelModules.itervalues():
             modules.extend(hostDetails)
         newmodules = set(modules)
         newmodules = list(newmodules)

         nagioshelper = nagiosconfighelper()
         for monHost in monitorHosts:
             for module in newmodules:
                 nagioshelper.addNewService(monHost, module, "dev-rel", "CCRCDevAdmins",
                                            "Y2lzY29zcGFyazovL3VzL1JPT00vZjEwZjkxODAtMWZlNS0xMWU2LTg5NDItNjdhYTk2OWM3NGI4")
                 nagioshelper.addCommand(module, "dev-rel", docs["nagios_url_"+args['env']])
                 nagioshelper.restartNagios()
     elif args['env'] == 'stg1-main':
         urlStg1MainHostsData = "http://"+docs["nagios_url_"+args['env']]+"/hosts?env=stg1-main"
         urlStg1MainModuleURL = "http://"+docs["nagios_url_"+args['env']]+"/modules?env=stg1-main&host="
         monitorHosts = docs["nagios_monitor_hosts_"+args['env']]
         print(urlStg1MainHostsData)
         # Get Environment Hosts
         stg1MainHosts = cfgHelper.getEnvHostInfo(urlStg1MainHostsData, "stg1-main")
         # Get Host and their Modules
         stg1MainModules = cfgHelper.getModulesInfo(urlStg1MainModuleURL, stg1MainHosts, "stg1-main")
         # print("....>"+devMainModules)
         modules = []
         for hostDetails in stg1MainModules.itervalues():
             modules.extend(hostDetails)
         newmodules = set(modules)
         newmodules = list(newmodules)

         nagioshelper = nagiosconfighelper()
         for monHost in monitorHosts:
             for module in newmodules:
                 nagioshelper.addNewService(monHost, module, "stg1-main", "CCRCStgAdmins",
                                            "Y2lzY29zcGFyazovL3VzL1JPT00vZjEwZjkxODAtMWZlNS0xMWU2LTg5NDItNjdhYTk2OWM3NGI4")
                 nagioshelper.addCommand(module, "stg1-main", docs["nagios_url_"+args['env']])
                 nagioshelper.restartNagios()
     elif args['env'] == 'stg2-main':
         urlStg1MainHostsData = "http://"+docs["nagios_url_"+args['env']]+"/hosts?env=stg1-main"
         urlStg1MainModuleURL = "http://"+docs["nagios_url_"+args['env']]+"/modules?env=stg1-main&host="
         monitorHosts = docs["nagios_monitor_hosts_"+args['env']]
         print(urlStg1MainHostsData)
         # Get Environment Hosts
         stg1MainHosts = cfgHelper.getEnvHostInfo(urlStg1MainHostsData, "stg1-main")
         # Get Host and their Modules
         stg1MainModules = cfgHelper.getModulesInfo(urlStg1MainModuleURL, stg1MainHosts, "stg1-main")
         # print("....>"+devMainModules)
         modules = []
         for hostDetails in stg1MainModules.itervalues():
             modules.extend(hostDetails)
         newmodules = set(modules)
         newmodules = list(newmodules)

         nagioshelper = nagiosconfighelper()
         for monHost in monitorHosts:
             for module in newmodules:
                 nagioshelper.addNewService(monHost, module, "stg2-main", "CCRCStgAdmins",
                                            "Y2lzY29zcGFyazovL3VzL1JPT00vZjEwZjkxODAtMWZlNS0xMWU2LTg5NDItNjdhYTk2OWM3NGI4")
                 nagioshelper.addCommand(module, "stg2-main", docs["nagios_url_"+args['env']])
                 nagioshelper.restartNagios()
     elif args['env'] == 'stg1-rel':
         urlHostsData = "http://"+docs["nagios_url_"+args['env']]+"/hosts?env=stg1-rel"
         urlModuleURL = "http://"+docs["nagios_url_"+args['env']]+"/modules?env=stg1-rel&host="
         monitorHosts = docs["nagios_monitor_hosts_"+args['env']]
         print(urlHostsData)
         # Get Environment Hosts
         stg1RelHosts = cfgHelper.getEnvHostInfo(urlHostsData, "stg1-rel")
         # Get Host and their Modules
         stg1RelModules = cfgHelper.getModulesInfo(urlModuleURL, stg1RelHosts, "stg1-rel")
         # print("....>"+devMainModules)
         modules = []
         for hostDetails in stg1RelModules.itervalues():
             modules.extend(hostDetails)
         newmodules = set(modules)
         newmodules = list(newmodules)

         nagioshelper = nagiosconfighelper()
         for monHost in monitorHosts:
             for module in newmodules:
                 nagioshelper.addNewService(monHost, module, "stg1-rel", "CCRCStgAdmins",
                                            "Y2lzY29zcGFyazovL3VzL1JPT00vZjEwZjkxODAtMWZlNS0xMWU2LTg5NDItNjdhYTk2OWM3NGI4")
                 nagioshelper.addCommand(module, "stg1-rel", docs["nagios_url_"+args['env']])
                 nagioshelper.restartNagios()
     elif args['env'] == 'stg2-rel':
         urlHostsData = "http://"+docs["nagios_url_"+args['env']]+"/hosts?env=stg2-rel"
         urlModuleURL = "http://"+docs["nagios_url_"+args['env']]+"/modules?env=stg2-rel&host="
         monitorHosts = docs["nagios_monitor_hosts_"+args['env']]
         print(urlHostsData)
         # Get Environment Hosts
         stg1RelHosts = cfgHelper.getEnvHostInfo(urlHostsData, "stg2-rel")
         # Get Host and their Modules
         stg1RelModules = cfgHelper.getModulesInfo(urlModuleURL, stg1RelHosts, "stg2-rel")
         # print("....>"+devMainModules)
         modules = []
         for hostDetails in stg1RelModules.itervalues():
             modules.extend(hostDetails)
         newmodules = set(modules)
         newmodules = list(newmodules)

         nagioshelper = nagiosconfighelper()
         for monHost in monitorHosts:
             for module in newmodules:
                 nagioshelper.addNewService(monHost, module, "stg2-rel", "CCRCStgAdmins",
                                            "Y2lzY29zcGFyazovL3VzL1JPT00vZjEwZjkxODAtMWZlNS0xMWU2LTg5NDItNjdhYTk2OWM3NGI4")
                 nagioshelper.addCommand(module, "stg1-rel", docs["nagios_url_"+args['env']])
                 nagioshelper.restartNagios()
     elif args['env'] == 'lt-main':
         urlHostsData = "http://"+docs["nagios_url_"+args['env']]+"/hosts?env=lt-main"
         urlModuleURL = "http://"+docs["nagios_url_"+args['env']]+"/modules?env=lt-main&host="
         monitorHosts = docs["nagios_monitor_hosts_"+args['env']]
         print(urlHostsData)
         # Get Environment Hosts
         ltMainHosts = cfgHelper.getEnvHostInfo(urlHostsData, "lt-main")
         # Get Host and their Modules
         ltMainModules = cfgHelper.getModulesInfo(urlModuleURL, ltMainHosts, "lt-main")
         # print("....>"+devMainModules)
         modules = []
         for hostDetails in ltMainModules.itervalues():
             modules.extend(hostDetails)
         newmodules = set(modules)
         newmodules = list(newmodules)

         nagioshelper = nagiosconfighelper()
         for monHost in monitorHosts:
             for module in newmodules:
                 nagioshelper.addNewService(monHost, module, "lt-main", "CCRCStgAdmins",
                                            "Y2lzY29zcGFyazovL3VzL1JPT00vZjEwZjkxODAtMWZlNS0xMWU2LTg5NDItNjdhYTk2OWM3NGI4")
                 nagioshelper.addCommand(module, "lt-main", docs["nagios_url_"+args['env']])
                 nagioshelper.restartNagios()
     elif args['env'] == 'pre-prd1':
         urlHostsData = "http://"+docs["nagios_url_"+args['env']]+"/hosts?env=pre-prd1"
         urlModuleURL = "http://"+docs["nagios_url_"+args['env']]+"/modules?env=pre-prd1&host="
         monitorHosts = docs["nagios_monitor_hosts_"+args['env']]
         print(urlHostsData)
         # Get Environment Hosts
         stg1RelHosts = cfgHelper.getEnvHostInfo(urlHostsData, "pre-prd1")
         # Get Host and their Modules
         stg1RelModules = cfgHelper.getModulesInfo(urlModuleURL, stg1RelHosts, "pre-prd1")
         # print("....>"+devMainModules)
         modules = []
         for hostDetails in stg1RelModules.itervalues():
             modules.extend(hostDetails)
         newmodules = set(modules)
         newmodules = list(newmodules)

         nagioshelper = nagiosconfighelper()
         for monHost in monitorHosts:
             for module in newmodules:
                 nagioshelper.addNewService(monHost, module, "pre-prd1", "CCRCPrdAdmins",
                                            "Y2lzY29zcGFyazovL3VzL1JPT00vZWJhMWQ1ZTAtMWNiYy0xMWU2LTgxNTItYTFmYWU1NTgxNWQz")
                 nagioshelper.addCommand(module, "pre-prd1", docs["nagios_url_"+args['env']])
                 nagioshelper.restartNagios()
     elif args['env'] == 'pre-prd2':
         urlHostsData = "http://"+docs["nagios_url_"+args['env']]+"/hosts?env=pre-prd2"
         urlModuleURL = "http://"+docs["nagios_url_"+args['env']]+"/modules?env=pre-prd2&host="
         monitorHosts = docs["nagios_monitor_hosts_"+args['env']]
         print(urlHostsData)
         # Get Environment Hosts
         stg1RelHosts = cfgHelper.getEnvHostInfo(urlHostsData, "pre-prd2")
         # Get Host and their Modules
         stg1RelModules = cfgHelper.getModulesInfo(urlModuleURL, stg1RelHosts, "pre-prd2")
         # print("....>"+devMainModules)
         modules = []
         for hostDetails in stg1RelModules.itervalues():
             modules.extend(hostDetails)
         newmodules = set(modules)
         newmodules = list(newmodules)

         nagioshelper = nagiosconfighelper()
         for monHost in monitorHosts:
             for module in newmodules:
                 nagioshelper.addNewService(monHost, module, "pre-prd2", "CCRCPrdAdmins",
                                            "Y2lzY29zcGFyazovL3VzL1JPT00vZWJhMWQ1ZTAtMWNiYy0xMWU2LTgxNTItYTFmYWU1NTgxNWQz")
                 nagioshelper.addCommand(module, "pre-prd2", docs["nagios_url_"+args['env']])
                 nagioshelper.restartNagios()
     elif args['env'] == 'prd1':
         urlHostsData = "http://"+docs["nagios_url_"+args['env']]+"/hosts?env=prd1"
         urlModuleURL = "http://"+docs["nagios_url_"+args['env']]+"/modules?env=prd1&host="
         monitorHosts = docs["nagios_monitor_hosts_"+args['env']]
         print(urlHostsData)
         # Get Environment Hosts
         stg1RelHosts = cfgHelper.getEnvHostInfo(urlHostsData, "prd1")
         # Get Host and their Modules
         stg1RelModules = cfgHelper.getModulesInfo(urlModuleURL, stg1RelHosts, "prd1")
         # print("....>"+devMainModules)
         modules = []
         for hostDetails in stg1RelModules.itervalues():
             modules.extend(hostDetails)
         newmodules = set(modules)
         newmodules = list(newmodules)

         nagioshelper = nagiosconfighelper()
         for monHost in monitorHosts:
             for module in newmodules:
                 nagioshelper.addNewService(monHost, module, "prd1", "CCRCPrdAdmins",
                                            "Y2lzY29zcGFyazovL3VzL1JPT00vZWJhMWQ1ZTAtMWNiYy0xMWU2LTgxNTItYTFmYWU1NTgxNWQz")
                 nagioshelper.addCommand(module, "prd1", docs["nagios_url_"+args['env']])
                 nagioshelper.restartNagios()
     elif args['env'] == 'prd2':
         urlHostsData = "http://"+docs["nagios_url_"+args['env']]+"/hosts?env=prd2"
         urlModuleURL = "http://"+docs["nagios_url_"+args['env']]+"/modules?env=prd2&host="
         monitorHosts = docs["nagios_monitor_hosts_"+args['env']]
         print(urlHostsData)
         # Get Environment Hosts
         stg1RelHosts = cfgHelper.getEnvHostInfo(urlHostsData, "prd2")
         # Get Host and their Modules
         stg1RelModules = cfgHelper.getModulesInfo(urlModuleURL, stg1RelHosts, "prd2")
         # print("....>"+devMainModules)
         modules = []
         for hostDetails in stg1RelModules.itervalues():
             modules.extend(hostDetails)
         newmodules = set(modules)
         newmodules = list(newmodules)

         nagioshelper = nagiosconfighelper()
         for monHost in monitorHosts:
             for module in newmodules:
                 nagioshelper.addNewService(monHost, module, "prd2", "CCRCPrdAdmins",
                                            "Y2lzY29zcGFyazovL3VzL1JPT00vZWJhMWQ1ZTAtMWNiYy0xMWU2LTgxNTItYTFmYWU1NTgxNWQz")
                 nagioshelper.addCommand(module, "prd2", docs["nagios_url_"+args['env']])
                 nagioshelper.restartNagios()
     elif args['env'] == 'prd3':
         urlHostsData = "http://"+docs["nagios_url_"+args['env']]+"/hosts?env=prd3"
         urlModuleURL = "http://"+docs["nagios_url_"+args['env']]+"/modules?env=prd3&host="
         monitorHosts = docs["nagios_monitor_hosts_"+args['env']]
         print(urlHostsData)
         # Get Environment Hosts
         stg1RelHosts = cfgHelper.getEnvHostInfo(urlHostsData, "prd3")
         # Get Host and their Modules
         stg1RelModules = cfgHelper.getModulesInfo(urlModuleURL, stg1RelHosts, "prd3")
         # print("....>"+devMainModules)
         modules = []
         for hostDetails in stg1RelModules.itervalues():
             modules.extend(hostDetails)
         newmodules = set(modules)
         newmodules = list(newmodules)

         nagioshelper = nagiosconfighelper()
         for monHost in monitorHosts:
             for module in newmodules:
                 nagioshelper.addNewService(monHost, module, "prd3", "CCRCPrdAdmins",
                                            "Y2lzY29zcGFyazovL3VzL1JPT00vZWJhMWQ1ZTAtMWNiYy0xMWU2LTgxNTItYTFmYWU1NTgxNWQz")
                 nagioshelper.addCommand(module, "prd3", docs["nagios_url_"+args['env']])
                 nagioshelper.restartNagios()


if __name__ == "__main__":
   main()
