#!/usr/bin/env python

# lchennup
#
# Usage: ./check_url.py -u http://monitor_url

from optparse import OptionParser
import os, sys, urllib2

UNKNOWN = -1
OK = 0
WARNING = 1
CRITICAL = 2

parser = OptionParser()
parser.add_option('-u', '--url', dest='url')
parser.add_option('-a', '--arg1', dest='arg1')
parser.add_option('-b', '--arg2', dest='arg2')

options, args = parser.parse_args()

if not getattr(options, 'url'):
        print 'CRITICAL - %s not specified' % options.url
        #raise SystemExit, CRITICAL
        sys.exit(CRITICAL)

adres = options.url+"?consulhost="+options.arg1+"&env="+options.arg1+"&module="+options.arg2

strona = urllib2.urlopen(adres,timeout=30000)
log = strona.read()
strona.close()

print "Result: %s " % (log)

if log == 'Success':
        print "Ok, Success"
        sys.exit(OK)
elif log != 'Success, 2/5':
        print "CRITICAL, %s " % (log)
        sys.exit(CRITICAL)
else:
        print "CRITICAL, --> %s " % (log)
        sys.exit(CRITICAL)