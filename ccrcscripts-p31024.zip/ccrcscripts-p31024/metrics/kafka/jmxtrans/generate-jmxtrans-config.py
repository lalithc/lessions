from shutil import copyfile
import os,sys

host = sys.argv[1]
ip = sys.argv[2]
influxip=sys.argv[3]

src='./kafka-influx-template.json'
dst='./conf/kafka-influx-' + str(host) + '.json'
copyfile(src, dst);

with open(dst, 'r') as file:
    content = file.read()
content = content.replace('$hostName', host)
content = content.replace('$hostIP', ip)
content = content.replace('$influxIP', influxip)

with open(dst, 'w') as file:
    file.write(content)
file.close()

