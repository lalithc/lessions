#RUN THIS CMD by passing hostname as an argument

HOSTNAME=$1
IP=$(host $HOSTNAME | awk '{ print $4 }')
INFLUXIP=64.101.23.186

python ./generate-jmxtrans-config.py $HOSTNAME $IP $INFLUXIP
