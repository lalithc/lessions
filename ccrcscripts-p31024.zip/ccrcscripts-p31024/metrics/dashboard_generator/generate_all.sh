for file in dashboard_metrics/*
do
    ./generate_all_environments.sh $1 $file
done
