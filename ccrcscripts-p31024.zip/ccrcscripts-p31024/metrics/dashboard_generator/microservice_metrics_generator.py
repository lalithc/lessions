#!/usr/bin/env python3

import argparse
import json
import requests


def main(pwd, microservice):
    template_config = ''
    with open('metrics-template.json', 'rt') as f:
        template_config = json.load(f)

    influxdb_config = ''
    with open('influxdb-config.json', 'rt') as f:
        influxdb_config = json.load(f)

    inbound_outbound_metrics = ''
    with open('dashboard_metrics/inbound-outbound-metrics.json', 'rt') as f:
        inbound_outbound_metrics = json.load(f)

    host = influxdb_config['host']
    port = ''
    userid = influxdb_config['userid']
    db = influxdb_config['db']

    series = generate_template_series(host, port, userid, pwd, db, 'com.cisco.ccrc.' + microservice)
    panels_inbound = []
    panels_outbound = []
    panels_additional = []

    for items in series:
        series_name = items[0]
        index = series_name.index('com.cisco')
        series_name = series_name[index:]
        series_title = series_name[len('com.cisco.ccrc.' + microservice) + 1:]
        series_item = {}
        series_item['title'] = series_title
        series_item['series'] = series_name

        if series_name in inbound_outbound_metrics['inbound'] :
            panels_inbound.append(series_item)
        elif series_name in inbound_outbound_metrics['outbound'] :
            panels_outbound.append(series_item)
        else :
            panels_additional.append(series_item)

    template_config['metrics'][0]['panels'] = panels_inbound
    template_config['metrics'][1]['panels'] = panels_outbound
    template_config['metrics'][2]['panels'] = panels_additional

    template_config['dashboard_name'] = microservice

    with open(microservice + '-metrics.json', 'wt') as f:
        json.dump(template_config, f, sort_keys = True, indent = 4)


def generate_template_series(host, port, userid, pwd, db, microservice) :
    query = build_query(microservice)
    response = postInfluxDB(host, port, userid, pwd, db, query)
    measurements = json.loads(response.text)
    results = measurements['results'][0]
    if 'series' in results :
        series_values = results['series'][0]['values']
        return series_values
    else :
        return []


def postInfluxDB(host, port, userid, pwd, db, cquery):
    serverURL = 'https://{0}/query'.format(host)
    params={'db':db, 'pretty':'true', '--data-urlencode':None, 'q':cquery}

    response = requests.post(serverURL, params=params, auth=(userid, pwd))
#    print(response)
#    print(response.text)
    return response

def build_query(series):
    query = 'SHOW MEASUREMENTS WITH MEASUREMENT = /{0}/'.format(series)
    return query

def parse_args():
    parser = argparse.ArgumentParser(
        description='Continuous Query generator')
    parser.add_argument('--microservice', type=str, required=True,
                        help='microservice prefix')
    parser.add_argument('--pwd', type=str, required=False,default='root',
                        help='password')


    return parser.parse_args()

if __name__ == '__main__':
    args = parse_args()
    print(args)
    main(args.pwd, args.microservice)
