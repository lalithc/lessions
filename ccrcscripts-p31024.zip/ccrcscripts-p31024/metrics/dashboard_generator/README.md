This project automates grafana dashboard creation for measurements from InfluxDB. The goal of this project is to reduce manual work in creating dashboards, standardize the dashboards, percentiles, and remove human errors in the large manual work involved in creating dashboards, and make it more efficient for micro-service owners to create a dashboard where they can easily track their micro-service usage as well as performance.

There are three parts to this dashboard, the continuous query in InfluxDB to aggregate metrics, grafana dashboard generator, and the metrics file generator.

## Continuous Queries in InfluxDB
The file influxdb_queries contains the continuous queries operating in the InfluxDB server. There are separate databases in the server that contain the raw metrics, the hourly aggregates, and the daily aggregates. For the most part the daily aggregates will be a sufficient mechanism to look at usage and performance. In some cases when recency is more critical the hourly aggregates will provide a good mechanism to evaluate what is happening in the last 24 hours or to evaluate usage and performance trends during the day. The raw metrics will provide by the minute trending and are useful for live monitoring of the system.

The raw data will be deleted more immediately in a day or week, while the hourly and daily aggregates use long term retention policies to hold data for a year or longer.

## Grafana Dashboard Generator
The grafana_dashboard_generator.py script generates a dashboard JSON and posts the dashboard JSON to the target Grafana environment. This requires the user to generate a JSON file to list all their metrics in a standard format which includes rows and panels. See the metrics files posted under the dashboard_metrics folder.

Usage :
python grafana_dashboard_generator.py --pwd=abc

This tool uses a few files named by convention to successfully generate the dashboard. All these are already available in the checkin and can be changed when needed:
1. metrics.json - This file contains the metrics.
2. config.json - This file contains the grafana configuration. i.e. host name, admin user
3. dashboard.json - This file contains the template for the dashboard. The dashboard template contains the templates, annotations, interval selections, data source selection, in the dashboard,
4. panel.json - This file contains the template to generate the panels within the Grafana dashboard. Panels include the metrics, chart style, legend, etc.
5. Environment.json - This file contains difference in the dashboard template between environments. These are typically template variables.

## Grafana Dashboard Generator Utility

Another useful shell script is the generate_all_environments script which includes the code to get the right files from the folders to generate target environment appropriate dashboards. i.e., stage, production DC1, and production DC2 environments.
Usage :
./generate_all_environments.sh abc copyQuote-metrics.json

First parameter is the grafana password. The second parameter is the metrics json file that contains the metrics in the standard json format to generate the Grafana dashboards.

## Grafana All Metrics Dashboard Generator Utility
Why do one metric at a time when we can automate generation of all dashboards. Once you are done with the metric file creation and places in the dashboard_metrics directory you can run this shell script to generate Grafana dashboards for all of the metrics files across all environments. This script internally uses the generate_all_environments.sh script and loops one metric at a time. There is no harm in replacing an existing auto generated dashboard even if there is no change.

Usage:
./generate_all.sh abc

Replace the first parameter abc with the Grafana password. Assumes the same password is used across all the Grafana servers.

## Micro Service Metrics Generator

The other part is the microservices metrics file generator. This generator makes it easier to generate a metrics file from a package prefix. However it is not required to use the generator especially when you are building a dashboard not tied to a single microservice. Howwver, once you generate a metric with the generator do not edit the file manually so you can always in the future rerun the metric generator to create the latest metrics file.

The microservices generated file divides the metrics into three rows with the standards we follow for microservice latency - the inbound REST API time metrics, the outbound microservice time metrics, and additional metrics. All metrics that need to be put into the ibound or outbound time metrics should be put into the inbound_outbound_metrics.json file. All metrics not put into this file will be put into the additional metrics row.

Usage:

python microservice_metrics_generator.py --pwd=abc --microservice=com.cisco.ccrc.copyQuote

## Microservices metrics generator Utility
THis utility generates all the microservices metrics by calling the microservice generator with all the microservices listed in the file microservices_list

Whenever there is a new microservices you just need to add it to the list in the microservices_list file. Then run this utility to regerate all the microservice files.

Usage:
./generate_all_microservice_metrics.sh abc

Replace the first parameter with the Influxdb server password.
