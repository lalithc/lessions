#! /bin/sh

cp $2 metrics.json

cp dashboard_templates/dashboard.json .
cp dashboard_templates/panel.json .

cp dashboard_templates/stage-environment.json environment.json
cp grafana-stage-config.json config.json
python grafana_dashboard_generator.py --pwd=$1
rm environment.json
rm config.json

#cp dashboard_templates/prod1-environment.json environment.json
#cp grafana-prod1-config.json config.json
#python grafana_dashboard_generator.py --pwd=$1
#rm environment.json
#rm config.json

#cp dashboard_templates/prod2-environment.json environment.json
#cp grafana-prod2-config.json config.json
#python grafana_dashboard_generator.py --pwd=$1
#rm environment.json
#rm config.json

rm dashboard.json
rm panel.json
rm metrics.json
