#! /bin/sh

cat microservices_list | \
while read CMD; do
    echo $CMD
    python microservice_metrics_generator.py --pwd=$1 --microservice=$CMD
done

rm ./-metrics.json  # sometimes a blank microservice name causes this file to be generated
mv *metrics.json dashboard_metrics
