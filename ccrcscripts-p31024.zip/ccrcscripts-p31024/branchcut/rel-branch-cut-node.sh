#!/bin/sh

RELBRANCH=$1
MODULE=$2
ARTIFACT=$3
REVIEWER=$4

echo $MODULE
echo $ARTIFACT


#git clone master
    git clone ssh://git@gitscm.cisco.com/ccwren/$MODULE.git
    cd $MODULE

#create rel branch from master and switch to RELBRANCH
    git checkout -b $RELBRANCH

    git push origin $RELBRANCH

#create devops branch from release
    git checkout -b devops-$RELBRANCH $RELBRANCH

#change final buildName
    sed -i -e "s:<finalName>$ARTIFACT-main</finalName>:<finalName>$ARTIFACT</finalName>:g" pom.xml
    sed -i -e 's:<finalName>${project.artifactId}-main</finalName>:<finalName>${project.artifactId}</finalName>:g' pom.xml
    git add pom.xml

#update version
    sed -i -e "s:gitscm.cisco.com/scm/ccwren/ccrcauthnodejs.git#master:gitscm.cisco.com/scm/ccwren/ccrcauthnodejs.git#$RELBRANCH:g" ./package.json
    sed -i -e "s:gitscm.cisco.com/scm/ccwren/ccrccommonnodejs.git#master:gitscm.cisco.com/scm/ccwren/ccrccommonnodejs.git#$RELBRANCH:g" ./package.json
    git add ./package.json
#replace urls in config.json

    if [ -f "./src/server/config/config.json" ];then
        sed -i -e "s:ServiceContract-main:ServiceContract:g; s:$ARTIFACT-main:$ARTIFACT:g" ./src/server/config/config.json
        git add ./src/server/config/config.json
    fi

    #handle ccrcdownload
    if [ -f "./src/server/config/config.js" ];then
        sed -i -e "s:ServiceContract-main:ServiceContract:g; s:$ARTIFACT-main:$ARTIFACT:g" ./src/server/config/config.js
        git add ./src/server/config/config.js
    fi

    #handle ccrcselectall
    if [ -f "./src/server/config/environment-setup.js" ];then
        sed -i -e "s:ServiceContract-main:ServiceContract:g; s:$ARTIFACT-main:$ARTIFACT:g" ./src/server/config/environment-setup.js
        git add ./src/server/config/environment-setup.js
    fi

    #-main.xml
    sed -i -e "s:<outputDirectory>$ARTIFACT-main/</outputDirectory>:<outputDirectory>$ARTIFACT/</outputDirectory>:g" $ARTIFACT-main.xml
    git add $ARTIFACT-main.xml

    #app.js
    if [ -f "./src/server/app.js" ];then
        sed -i -e "s:$ARTIFACT-main:$ARTIFACT:g" ./src/server/app.js
        sed -i -e "s:CCRCLocalization-main:CCRCLocalization:g" ./src/server/app.js
        git add ./src/server/app.js
    fi

    #handle ccrccopyquote
    if [ -f "./app.js" ];then
        sed -i -e "s:$ARTIFACT-main:$ARTIFACT:g" ./app.js
        git add ./app.js
    fi

    #server.js
    sed -i -e "s:/$ARTIFACT-main:/$ARTIFACT:g" server
    git add server

    #commit and push

    git commit -m "Branch-cut-rel: Changed build finalName in rel-version"
    git push origin devops-$RELBRANCH

    cd ..

    rm -rf $MODULE
    #raise pull request
    sh branchcut/raise-pull-request.sh $RELBRANCH release $MODULE node
