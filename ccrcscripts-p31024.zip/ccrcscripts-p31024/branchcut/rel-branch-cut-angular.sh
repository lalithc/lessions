#!/bin/sh

RELBRANCH=$1
REVIEWER=$2

declare -a MODULES=('ccrccommonux' 'servicecontract' 'ccrcsearchux' 'contracts' 'ccrcsaasui')

for MODULE in "${MODULES[@]}"
do
#git clone master
    git clone ssh://git@gitscm.cisco.com/ccwren/$MODULE.git
    cd $MODULE

    #create rel branch from master and switch to RELBRANCH
    git checkout -b $RELBRANCH

    git push origin $RELBRANCH

    #create devops branch from release
    git checkout -b release/devops-$RELBRANCH $RELBRANCH

    if [ "$MODULE" == "ccrccommonux" ];then
     sed -i -e "s:<directory>dest/ServiceContract-main</directory>:<directory>dest/ServiceContract</directory>:g" CCRCCommonUX-main.xml
     sed -i -e "s:<outputDirectory>ServiceContract-main/</outputDirectory>:<outputDirectory>ServiceContract/</outputDirectory>:g" CCRCCommonUX-main.xml
     git add CCRCCommonUX-main.xml

     sed -i -e "s:dest/ServiceContract-main:dest/ServiceContract:g" gulpfile.js
     git add gulpfile.js

     sed -i -e 's:<finalName>${project.artifactId}-main</finalName>:<finalName>${project.artifactId}</finalName>:g' pom_integrated.xml
     git add pom_integrated.xml
    fi

    #change finalName in build
    sed -i -e 's:<finalName>${project.artifactId}-main</finalName>:<finalName>${project.artifactId}</finalName>:g' pom.xml
    git add pom.xml

    #commit and push
    git commit -m "Branch-cut-rel: Changed build finalName in rel-version"
    git push origin release/devops-$RELBRANCH

    cd ..

    rm -rf $MODULE

    BRANCH=$RELBRANCH
    VERSION=release
    REVIEWER='ccrcbbapprover.gen'

    request_body=$(cat <<EOF
    {"fromRef": {"id": "release/devops-$RELBRANCH"},"toRef": {"id": "$RELBRANCH"},"title":"Branch-cut-$VERSION: Changed build finalName in $VERSION-version","reviewers":[{"user":{"name":"$REVIEWER"}}]}
EOF
)

    echo "raising pull-request $request_body"

    #raise pull-request
    id=`curl --request POST --url https://gitscm.cisco.com/rest/api/1.0/projects/CCWREN/repos/$MODULE/pull-requests --header 'authorization: Basic Y2NyY2JpdGJ1Y2tldC5nZW46Y2hhbmdlbWU=' --header 'content-type: application/json' --data "$request_body" | python -c "import sys,json; print json.load(sys.stdin)['id']"`

    #echo "Response $response"
    echo "id $id"

    echo "$MODULE:$id" >> pull-request-list-$VERSION-angular.txt

done
