#!/bin/sh

VERSION=$1
TYPE=$2

if [ $# -ne 2 ]; then
  echo "version or type missing! [version: rel/master] [type: java/node/jar/angular/npm]"
  exit 1
fi

pullrequestid=`cat branchcut/pull-request-list-$VERSION-$TYPE.txt`
echo $pullrequestid

#convert to arr
APPS=($pullrequestid)

#read arr
for app in "${APPS[@]}";do

	#split on colon	
	arr=(${app//:/ })
	MODULE=${arr[0]}
	ID=${arr[1]}

	echo "MODULE$MODULE"
	echo "ID$ID"

    echo "approving pull-request"
	#approve
	curl --request POST --url https://gitscm.cisco.com/rest/api/1.0/projects/CCWREN/repos/$MODULE/pull-requests/$ID/approve --header 'authorization: Basic Y2NyY2JiYXBwcm92ZXIuZ2VuOmNoYW5nZUl0IQ==' --header 'content-type: application/json'
	echo "pull-request approved"

	echo "merging pull-request"
	#merge
	curl --request POST --url https://gitscm.cisco.com/rest/api/1.0/projects/CCWREN/repos/$MODULE/pull-requests/$ID/merge?version=0 --header 'authorization: Basic Y2NyY2JpdGJ1Y2tldC5nZW46Y2hhbmdlbWU=' --header 'content-type: application/json'
	echo "pull-request merged"

done
