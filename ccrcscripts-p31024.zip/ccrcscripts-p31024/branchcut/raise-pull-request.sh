#!/bin/sh

BRANCH=$1
VERSION=$2
MODULE=$3
TYPE=$4
REVIEWER='ccrcbbapprover.gen'

echo "BRANCH $BRANCH"
echo "VERSION $VERSION"
echo "MODULE $MODULE"
echo "TYPE $TYPE"


   #request-body
    request_body=$(cat <<EOF
    {"fromRef": {"id": "devops-$BRANCH"},"toRef": {"id": "$BRANCH"},"title":"Branch-cut-$VERSION: Changed build finalName in $VERSION-version","reviewers":[{"user":{"name":"$REVIEWER"}}]}
EOF
)
	echo "raising pull-request $request_body"

    #raise pull-request

    id=`curl --request POST --url https://gitscm.cisco.com/rest/api/1.0/projects/CCWREN/repos/$MODULE/pull-requests --header 'authorization: Basic Y2NyY2JpdGJ1Y2tldC5nZW46Y2hhbmdlbWU=' --header 'content-type: application/json' --data "$request_body" | python -c "import sys,json; print json.load(sys.stdin)['id']"`

    #response=$(curl --request POST --url https://gitscm.cisco.com/rest/api/1.0/projects/CCWREN/repos/$MODULE/pull-requests --header 'authorization: Basic Y2NyY2JpdGJ1Y2tldC5nZW46Y2hhbmdlbWU=' --header 'content-type: application/json' --data "$request_body")

    #echo "Response $response"
    echo "id $id"

    echo "$MODULE:$id" >> pull-request-list-$VERSION-$TYPE.txt

    exit
