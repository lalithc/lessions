#!/bin/sh

RELVERSION=$1
MODULE=$2

i=1
j=1

git clone ssh://git@gitscm.cisco.com/ccwren/$MODULE.git
cd $MODULE

echo "$i $MODULE deleted"
i=$((i + j))

git push origin --delete devops-master

cd ..

rm -rf $MODULE
