from __future__ import print_function
import sys,requests,subprocess

jenkins_arg = sys.argv[1]

subprocess.check_call(['sh', 'branchcut/test-shell-script.sh', jenkins_arg])