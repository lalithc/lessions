#!/bin/sh

NEWMAINVERSION=$1
CURMAINVERSION=$2
REVIEWER=$3

declare -a MODULES=('ccrccommonux' 'servicecontract' 'ccrcsearchux' 'contracts' 'ccrcsaasui')

for MODULE in "${MODULES[@]}"
do

    #git clone master
    git clone ssh://git@gitscm.cisco.com/ccwren/$MODULE.git
    cd $MODULE

    #create devops branch from master
     git checkout master
     git checkout -b feature/devops-master master

    #change pom version in main
     if [ "$MODULE" == "ccrccommonux" ];then
         sed -i -e "0,/<version>$CURMAINVERSION/s//<version>$NEWMAINVERSION/" pom_integrated.xml
         git add pom_integrated.xml
     fi

    sed -i -e "0,/<version>$CURMAINVERSION/s//<version>$NEWMAINVERSION/" pom.xml
    #add pom.xml
    git add pom.xml

    #commit and raise pull request
     git commit -m "Branch-cut-main: Changed pom version in main-version"
     git push origin feature/devops-master

     BRANCH=master
     VERSION=master
     REVIEWER='ccrcbbapprover.gen'

     #request-body
      request_body=$(cat <<EOF
      {"fromRef": {"id": "feature/devops-$BRANCH"},"toRef": {"id": "$BRANCH"},"title":"Branch-cut-$VERSION: Changed build finalName in $VERSION-version","reviewers":[{"user":{"name":"$REVIEWER"}}]}
EOF
)
  	echo "raising pull-request $request_body"

      #raise pull-request

      id=`curl --request POST --url https://gitscm.cisco.com/rest/api/1.0/projects/CCWREN/repos/$MODULE/pull-requests --header 'authorization: Basic Y2NyY2JpdGJ1Y2tldC5nZW46Y2hhbmdlbWU=' --header 'content-type: application/json' --data "$request_body" | python -c "import sys,json; print json.load(sys.stdin)['id']"`

      #response=$(curl --request POST --url https://gitscm.cisco.com/rest/api/1.0/projects/CCWREN/repos/$MODULE/pull-requests --header 'authorization: Basic Y2NyY2JpdGJ1Y2tldC5nZW46Y2hhbmdlbWU=' --header 'content-type: application/json' --data "$request_body")

      #echo "Response $response"
      echo "id $id"

      cd ..

      rm -rf $MODULE

      echo "$MODULE:$id" >> pull-request-list-$VERSION-angular.txt

done
