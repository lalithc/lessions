from __future__ import print_function
import sys,requests

#get all modules
services = requests.get('http://ccrc-build-5:5000/modules').json()
relversion = sys.argv[1];

for service in services:
    if service != 'CCRCDashBoard':
     url = 'http://ccrc-build-5:5000/status?module='+str(service)+'&env=dev-rel'
     if(requests.get(url) is not None):
      status = requests.get(url).json()
      data = status[str(service)]
     #print (data)
      for key,value in data.items():
       health_check = value['health_check']
       version = value['version']
       print(health_check,version,service)
     #if not ('Success') in health_check :
     #print ('health check down --- ' + str(service) + ' ' + str(value['version']) + ' ' + str(key))
     #if value['version'] is None:
     #print ('version is null --- ' + str(service) + ' ' + str(value['version']) + ' ' + str(key))
     #if not (relversion) in value['version']:
     #print ('wrong version deployed --- ' + str(service) + ' ' + str(value['version']) + ' ' + str(key))
     #elif ('Success') in health_check :
     #print ('module is deployed successfully' + str(service))



#get status
#data = requests.get(url).json()
