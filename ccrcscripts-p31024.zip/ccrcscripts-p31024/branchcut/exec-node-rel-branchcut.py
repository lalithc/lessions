from __future__ import print_function
import sys,requests,subprocess

relBranch = sys.argv[1]
reviewer = sys.argv[2]
moduleType = 'node'

#get all modules
services = requests.get('http://ccrc-build-5:5000/modules').json()

for key,value in services.items():
  for k,v in value.items():
      if(k == 'type'):
          if(moduleType == 'node' and v == 'nodejs'):
             module=str(key).lower()
             print(module)
             print(key)
             subprocess.check_call(['sh', 'branchcut/rel-branch-cut-node.sh', relBranch, module,key, reviewer])
