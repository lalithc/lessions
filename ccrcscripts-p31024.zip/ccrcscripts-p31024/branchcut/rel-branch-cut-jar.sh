#!/bin/sh

MODULE=$1
RELBRANCH=$2
REVIEWER=$3


#git clone master
echo "ssh://git@gitscm.cisco.com/ccwren/$MODULE.git"
git clone ssh://git@gitscm.cisco.com/ccwren/$MODULE.git
cd $MODULE

#create rel branch from master and switch to RELBRANCH
git checkout -b $RELBRANCH

git push origin $RELBRANCH

#create dev branch from release
git checkout -b devops-$RELBRANCH $RELBRANCH

#change active profile
#rel to temp
 sed -i -e 's:<id>release</id>:<id>temp</id>:g' pom.xml
 sed -i -e 's:<release.branch>rel</release.branch>:<release.branch>temp</release.branch>:g' pom.xml
 sed -i -e 's:<release.url></release.url>:<release.url>temp</release.url>:g' pom.xml
 sed -i -e 's:<ucep.release.branch>rel</ucep.release.branch>:<ucep.release.branch>temp</ucep.release.branch>:g' pom.xml
 
 #main to release
 sed -i -e 's:<id>main</id>:<id>release</id>:g' pom.xml
 sed -i -e 's:<release.branch>main</release.branch>:<release.branch>rel</release.branch>:g' pom.xml
 sed -i -e 's:<release.url>-main</release.url>:<release.url></release.url>:g' pom.xml
 sed -i -e 's:<ucep.release.branch>main</ucep.release.branch>:<ucep.release.branch>rel</ucep.release.branch>:g' pom.xml

 #temp to main
 sed -i -e 's:<id>temp</id>:<id>main</id>:g' pom.xml
 sed -i -e 's:<release.branch>temp</release.branch>:<release.branch>main</release.branch>:g' pom.xml
 sed -i -e 's:<release.url>temp</release.url>:<release.url>-main</release.url>:g' pom.xml
 sed -i -e 's:<ucep.release.branch>temp</ucep.release.branch>:<ucep.release.branch>main</ucep.release.branch>:g' pom.xml
 
git add pom.xml
git commit -m "Branch-cut-rel: Changed active profile"
git push origin devops-$RELBRANCH

cd ..
rm -rf $MODULE

#raise pull request
sh branchcut/raise-pull-request.sh $RELBRANCH release $MODULE jar
