from __future__ import print_function
import requests

header={"Authorization":"Basic Y2NyY2JiYXBwcm92ZXIuZ2VuOmNoYW5nZUl0IQ=="}
#get all modules
repos = requests.get('https://gitscm.cisco.com/rest/api/1.0/projects/CCWREN/repos?limit=200',headers=header).json()
i=0;
for key,value in repos.items():
    if ( key == 'values'):
        for repo in value:
            for k,v in repo.items():
                if (k == 'slug'):
                    print(v)
                    url = 'https://gitscm.cisco.com/rest/api/1.0/projects/CCWREN/repos/'+str(v)+'/permissions/groups?name=ccw-renewals-developers&permission=REPO_READ'
                    resp = requests.put(url,headers=header)
                    print(resp)
                    print(i)
                    i=i+1