#!/bin/sh

jenkins_arg=$1

echo $jenkins_arg
echo "cloning git repo activity log"

git clone ssh://git@gitscm.cisco.com/ccwren/ccrcactivitylog.git

cd ccrcactivitylog
ls

echo "exiting.."

cd ..

branchcut/test-script-2.sh

rm -rf ccrcactivitylog
