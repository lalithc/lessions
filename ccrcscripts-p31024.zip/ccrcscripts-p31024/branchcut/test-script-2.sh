#!/bin/sh

echo "inside test2"
