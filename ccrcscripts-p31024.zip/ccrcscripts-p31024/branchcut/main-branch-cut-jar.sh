#!/bin/sh

NEWMAINVERSION=$1
CURMAINVERSION=$2
MODULE=$3
REVIEWER=$4

	git clone ssh://git@gitscm.cisco.com/ccwren/$MODULE.git
    cd $MODULE

    #create dev branch from master
    git checkout master
    git checkout -b devops-master master

    #change pom version in main
    sed -i -e "0,/<version>$CURMAINVERSION/s//<version>$NEWMAINVERSION/" pom.xml

    #commit and raise pull request
    git add pom.xml
    git commit -m "Branch-cut-main: Changed pom version in main-version"
    git push origin devops-master

    cd ..

	rm -rf $MODULE

    #raise pull request
    sh branchcut/raise-pull-request.sh master master $MODULE jar
