from __future__ import print_function
import sys,requests,subprocess

newmain = sys.argv[1]
curmain = sys.argv[2]
reviewer = sys.argv[3]

moduleType = 'node'

if moduleType not in ('java' 'node' 'angular'):
 print('error!! incorrect module type.')
 sys.exit()

#get all modules
services = requests.get('http://ccrc-build-5:5000/modules').json()

for key,value in services.items():
  for k,v in value.items():
      if(k == 'type'):
          if(moduleType == 'node' and v == 'nodejs'):
             module=str(key).lower()
             print(module)
             print(key)
             subprocess.check_call(['sh', 'branchcut/main-node-branch-cut.sh', newmain,curmain,module,key,reviewer])