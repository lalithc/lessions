from __future__ import print_function
import sys,requests,subprocess

newmain = sys.argv[1]
curmain = sys.argv[2]
reviewer = sys.argv[3]
moduleType = 'java'

#get all modules
services = requests.get('http://ccrc-build-5:5000/modules').json()

for key,value in services.items():
  for k,v in value.items():
      if(k == 'type'):
          if(moduleType == 'java' and v == 'tomcat' or v == 'springboot'):
             module=str(key).lower()
             print('cloning',module)
             subprocess.check_call(['sh', 'branchcut/main-branch-cut-java.sh', newmain,curmain,module,reviewer])