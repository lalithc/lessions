#!/bin/sh

RELBRANCH=$1
MODULE=$2
REVIEWER=$3

	  git clone ssh://git@gitscm.cisco.com/ccwren/$MODULE.git
   	cd $MODULE

    #create rel branch from master and switch to RELBRANCH
    git checkout -b $RELBRANCH

    git push origin $RELBRANCH

    #create devops branch from release
    git checkout -b devops-$RELBRANCH $RELBRANCH

    #change finalName in build
    sed -i -e 's:<finalName>${project.artifactId}-main</finalName>:<finalName>${project.artifactId}</finalName>:g' pom.xml

    #commit and push
    git add pom.xml
    git commit -m "Branch-cut-rel: Changed build finalName in rel-version"
    git push origin devops-$RELBRANCH

		cd ..
		rm -rf $MODULE

    #raise pull request
    sh branchcut/raise-pull-request.sh $RELBRANCH release $MODULE java
