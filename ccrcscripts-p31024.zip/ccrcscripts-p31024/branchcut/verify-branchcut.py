from __future__ import print_function
import sys,requests

#get all modules
services = requests.get('http://ccrc-build-5:5000/modules').json()

for service in services:
  #if service == 'QOTService':
    print(service)
    exc = ['CCRCDashboard','CCRCDataLoader']
    if(service not in exc):
     url = 'http://ccrc-build-5:5000/status?module='+str(service)+'&env=dev-main'
     status = requests.get(url).json()
     data = status[str(service)]
    #print (data)
     for key,value in data.items():
      health_check = value['health_check']
      if not ('Success') in health_check :
       print ('health check down --- ' + str(service) + ' ' + str(value['version']) + ' ' + str(key))
      if value['version'] is None:
       print ('version is null --- ' + str(service) + ' ' + str(value['version']) + ' ' + str(key))
      elif not ('1.4.0') in value['version']:
       print ('wrong version deployed --- ' + str(service) + ' ' + str(value['version']) + ' ' + str(key))



#get status
#data = requests.get(url).json()
