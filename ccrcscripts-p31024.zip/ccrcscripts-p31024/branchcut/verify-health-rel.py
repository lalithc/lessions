from __future__ import print_function
import sys,requests

#get all modules
services = requests.get('http://ccrc-build-5:5000/modules').json()

for service in services:
 if not ('SaaS') in service:
    #url = 'http://ccrc-build-5:5000/status?module='+str(service)+'&env=dev-main'
    url = 'https://ccrc-sc-stg.cisco.com/ServiceContract/'+str(service).lower()+'/ping'
    response = requests.get(url)
    status_code = response.status_code
    if 200 != status_code:
     print (str(status_code) +'--'+ str(service)+'--'+str(url))


#get status
#data = requests.get(url).json()
