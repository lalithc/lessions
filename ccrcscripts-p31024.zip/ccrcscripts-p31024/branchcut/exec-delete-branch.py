from __future__ import print_function
import sys,requests,subprocess

#get all modules
services = requests.get('http://ccrc-build-5:5000/modules').json()
branch = sys.argv[1]

for key,value in services.items():
  for k,v in value.items():
      if(k == 'type'):
             module=str(key).lower()
             print(module)
             subprocess.check_call(['sh', 'branchcut/delete-branch.sh', branch, module])
