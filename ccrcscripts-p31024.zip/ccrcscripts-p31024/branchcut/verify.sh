declare -a MODULES=('ccrcb2b' 'ccrcproxy' 'ccrcservices' 'ccrccommonux' 'ccrclocalz' 'ccrclinesdataservice' 'ccrcappdataload' 'ccrcsaasui' 'ccrcdownloadnginx' 'oauthservice' 'ccrcconfigvalidations' 'ccrcupload' 'smartaccountservice' 'ccrcbrandprotection' 'ccrcesservices' 'ccrcqotnonstd' 'ccrcapi' 'ccrcquotesummary' 'jobmanager' 'ccrccopyquote' 'ccrcorderconv' 'ccrcsaasdownload' 'ccrccreditcalculation' 'ccrcselectall' 'ccrcdashboard' 'quotelinesdataload' 'ccrcquotingasync' 'cmservice' 'ccrcdownload' 'cpamservice' 'ccwsaasdataloader' 'ccrcdataservices' 'ccrcquotelineedit' 'ccrcsaasservice' 'edwreports' 'ngvsservice' 'qotservice' 'ccrcsaasesservices' 'ccrcauthproxy' 'ccrcmasserrorresolution' 'ccrcconfig' 'ccrcdataloader' 'upaas' 'disticcodataloader')

for MODULE in "${MODULES[@]}"
do
 requesturl="https://ccrc-sc-stg.cisco.com/ServiceContract/$MODULE/ping"
 response=`curl -s -o /dev/null -w "%{http_code}" $requesturl`;
if [ $response -ne 200 ]; then
 echo $response
 echo $requesturl
fi

done
