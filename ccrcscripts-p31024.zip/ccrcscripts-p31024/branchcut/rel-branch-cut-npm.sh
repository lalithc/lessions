#!/bin/sh

RELBRANCH=$1

declare -a MODULES=('ccrcauthnodejs' 'ccrccommonnodejs')

for MODULE in "${MODULES[@]}"
do
    #git clone
    git clone ssh://git@gitscm.cisco.com/ccwren/$MODULE.git
    cd $MODULE

    #create rel branch from master and switch to RELBRANCH
    git checkout -b $RELBRANCH

    git push origin $RELBRANCH

    cd ..

    rm -rf $MODULE

done
