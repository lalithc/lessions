from __future__ import print_function
import sys, requests, subprocess
import requests
from array import *

env=['dev-main','stg1-main','stg2-main','lt-main']
for e in env:
     get_nonms_url = "http://localhost:5000/nonmicroservices?app=haproxy&env="+str(e)
     print(get_nonms_url)
     result = requests.get(get_nonms_url)
     res = result.json()
     for subtype in res:
         print(subtype)
         
         url = "http://ccrc-build-5.cisco.com:8080/jenkins/job/Create/buildWithParameters?token=nonms-create-main&ENV="+str(e)+"&APP=haproxy&SUBTYPE="+str(subtype)
         print(url)
         response = requests.request("POST", url)
         print(response.json())

