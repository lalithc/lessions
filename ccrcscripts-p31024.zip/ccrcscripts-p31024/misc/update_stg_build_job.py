from __future__ import print_function
import sys,requests,subprocess

#get all modules
services = requests.get('http://ccrc-build-5:5000/modules').json()

for key,value in services.items():
  for k,v in value.items():
      if(k == 'type'):
        module=str(key)
        url = 'http://ccrc-nprd-docker-build:5000/jenkins/update_build_job?env=stg-main&module='+str(module)+'&server=ccrc-build'
        print('creating job for'+str(url))
        payload = ""
        response = requests.request("GET", url, data=payload)
        print(response.text)