from __future__ import print_function
import sys,requests,subprocess,json

#get all modules
services = requests.get('http://ccrc-nprd-docker-build:5000/modules').json()

for key,value in services.items():
  for k,v in value.items():
      if(k == 'type'):
        module=str(key)
        url = 'http://ccrc-nprd-docker-build:5000/setup_module'
        print('setting up module: '+str(module))
        payload = {'module':str(module),'migrate':'Yes','main_rel':'rel'}
        response = requests.request("POST", url, data=json.dumps(payload))
        print(response.text)