/*
This is not a script. It is an example template for running commands to add one or more columns to `modules` table.
Use these commands as tools -- do not blindly execute.
*/


/* create new table as a copy (data only) of the current table */
create table modules2
as select * from modules;

/* add the columns */
alter table modules2 add column request_cpu varchar(45);
alter table modules2 add column request_mem varchar(45);
alter table modules2 add column git_repo varchar(128);
alter table modules2 add column jvm_params varchar(10000);

/* update the data */
update modules2 set request_cpu=container_cpu/2, request_mem=heap_max+512, git_repo=lower(module_name);

/* set the not null constraints now that data is populated */
alter table modules2 modify column request_cpu varchar(45) not null;
alter table modules2 modify column request_mem varchar(45) not null;
alter table modules2 modify column git_repo varchar(128) not null;

/* create the constraints on the new table that were on the old table */
alter table modules2 add primary key (module_name);
alter table modules2 add unique key (http_port);
alter table modules2 add unique key (jmx_port);

/* create the foreign key constraints on the new table */
alter table modules_envs add constraint modules_envs_fk2 foreign key modules_envs_fk2(module_name) references modules2(module_name);
alter table modules_hosts add constraint modules_hosts_fk3 foreign key modules_hosts_fk3(module_name) references modules2(module_name);

/* rename the old table to different name and new table to `modules` without downtime by using a TRANSACTION */
START TRANSACTION;
ALTER TABLE modules rename to modules3;
ALTER TABLE modules2 rename to modules;
COMMIT;

/* cleanup old constraints and old table */
alter table modules_envs drop foreign key modules_envs_fk1;
alter table modules_hosts drop foreign key modules_hosts_fk1;
drop tables modules3;

/* Inspect foreign key constraints */
SELECT 
  TABLE_NAME,COLUMN_NAME,CONSTRAINT_NAME, REFERENCED_TABLE_NAME,REFERENCED_COLUMN_NAME
FROM
  INFORMATION_SCHEMA.KEY_COLUMN_USAGE
WHERE
  REFERENCED_TABLE_SCHEMA = 'ccrc_automation' AND
  REFERENCED_TABLE_NAME = 'modules3';
  
/* Inspect constraints local to a table */
SELECT 
  TABLE_NAME,COLUMN_NAME,CONSTRAINT_NAME, REFERENCED_TABLE_NAME,REFERENCED_COLUMN_NAME
FROM
  INFORMATION_SCHEMA.KEY_COLUMN_USAGE
  WHERE TABLE_NAME='modules3';
  
  