# CCRCScripts Repository
Use this repo to store bash scripts used for various automation tasks. 
Rather than writing a script within Jenkins, the script should be committed
here and referred to within the Jenkins config.