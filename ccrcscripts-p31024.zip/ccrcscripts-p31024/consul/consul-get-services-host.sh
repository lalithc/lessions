#!/bin/sh

#this script can be used to get list of all hosts where the services are running based on env.
#run cmd : ./consul-get-services-host.sh stg rel dc1
#allowed args : env - dev stg lt prod | branch - main rel | dc - dc1 dc2


if [ "$#" -ne 3 ]; then
  echo "Error in arguments. Order of args -- env branch dc'. Allowed args  dc: dc1 dc2  branch: main rel  env: dev stg lt prod \n dev - dc2 lt - dc1"
  exit 1
fi

env=$1
branch=$2
dc=$3

python ./consul-get-services-host.py $env $branch $dc
