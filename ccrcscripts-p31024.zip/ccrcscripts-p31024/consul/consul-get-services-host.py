from __future__ import print_function
import sys,requests

#this script can be used to get list of all hosts where the services are running based on env/branch/dc.
#run cmd : python ./consul-get-services-host.py stg rel dc1
#allowed args : env - dev stg lt prod | branch - main rel | dc - dc1 dc2

env = sys.argv[1]
branch = sys.argv[2]
dc = sys.argv[3]
token = '2c9572d1-e49d-4d9c-834e-a2adece9fa7a'

if env not in ('dev', 'stg', 'lt', 'prod') or branch not in ('rel' 'main') or dc not in ('dc1' 'dc2') :
    print('Error in arguments.\n Order of args -- env branch dc')
    print(' Allowed args --\n  dc : dc1 dc2\n  branch : main rel\n  env : dev stg lt prod. dev - dc2, LT - dc1')
    sys.exit()

requesturl = 'internal/ui/services'

if env == 'dev' or (env == 'stg' and dc == 'dc2'):
    dc = 'stagedc2'
    host = 'http://ccrc-consul-stg-01'
elif (env == 'stg' and dc == 'dc1') or (env == 'lt' and dc == 'dc1'):
    dc = 'stagedc1'
    host = 'http://ccrc-consul-stg2-01'
elif env == 'prod' and dc == 'dc1':
    dc = 'proddc1'
    host = 'http://ccrc-consul-prd2-01'
elif env == 'prod' and dc == 'dc2':
    dc = 'proddc2'
    host = 'http://ccrc-consul-prd1-01'
elif (env == 'dev' and dc == 'dc1') or (env == 'lt' and dc == 'dc2'):
	print ('ERROR!! dev - dc2, lt - dc1')
	sys.exit()
else:
	print ('ERROR!! Incorrect args')
	sys.exit()

url = host + ':8500/v1/' + requesturl +'?token=' + token + '&dc=' + dc
print (url)

data = requests.get(url).json()

service = branch + env + '-8080'
print (service)

for d in data:
    if service in d['Name']:
        print (d['Name'],end=' ')
        for n in d["Nodes"]:
            print (n,end=' ')
        print ('\n')