pwd=`pwd`

cd /users/ccrccloudop

/users/ccrccloudop/consul-template -config haproxy.hcl &> consul-template.log &

cd $pwd

sleep 3s

pid=`ps aux | grep '/consul-template.*haproxy' | grep -v grep | awk '{print $2}'`

echo 'consul-template started with pid' $pid

ps -ef | grep $pid
