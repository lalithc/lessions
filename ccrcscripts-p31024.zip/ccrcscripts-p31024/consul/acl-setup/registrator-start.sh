ip=$(host $HOSTNAME | awk '{ print $4 }')

#use master token below
token=$1
if [ -n "$token" ]; then
 echo "token can not empty. add master token before starting registrator"
 exit 1
 
docker run -d --name agent-registrator -v /var/run/docker.sock:/tmp/docker.sock -e CONSUL_HTTP_TOKEN=$token --restart=always gliderlabs/registrator:latest -ip=$ip consul://$ip:8500

sleep 2s
docker ps -a | grep agent-registrator