pid=`ps aux | grep /apps/consul | grep -v grep | awk '{print $2}'`

ps -ef | grep $pid

echo 'stopping consul-agent with pid' $pid

kill -15 $pid

sleep 5s
echo `ps -ef | grep $pid`
