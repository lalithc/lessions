echo `docker ps -a | grep agent-registrator`
docker stop agent-registrator
sleep 5s
docker rm agent-registrator
echo `docker ps -a | grep agent-registrator`

