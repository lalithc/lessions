ipaddress=$(host $HOSTNAME | awk '{ print $4 }')

/apps/consul/consul agent -bind=$ipaddress -config-dir /apps/consul/consul.d/client &> /apps/consul/logs/consul.log &

sleep 5s
pid=`ps aux | grep /apps/consul | grep -v grep | awk '{print $2}'`

echo 'started consul agent with pid'$pid

ps -ef | grep $pid
