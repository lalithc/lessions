pid=`ps aux | grep '/consul-template.*haproxy' | grep -v grep | awk '{print $2}'`

ps -ef | grep $pid
echo 'stopping consul-template with pid' $pid

kill -9 $pid

sleep 3s
echo `ps -ef | grep $pid`
