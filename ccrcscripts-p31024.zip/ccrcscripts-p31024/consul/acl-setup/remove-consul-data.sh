pwd=`pwd`

cd /apps/consul/data
rm -rf *
cd $pwd
