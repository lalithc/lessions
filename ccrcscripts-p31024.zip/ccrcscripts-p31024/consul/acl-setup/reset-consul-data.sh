#This script can be used when the consul data has to be cleaned uo.
#The scripts to stop/start consul/registrator/template have to be in this specific order

sh ./registrator-stop.sh
sleep 3s
sh ./consul-template-stop.sh
sleep 2s
sh ./consul-agent-stop.sh
sleep 2s
sh ./remove-consul-data.sh
sh ./consul-agent-start.sh
sleep 2s
sh ./registrator-start.sh
sleep 3s
sh ./consul-template-start.sh