from __future__ import print_function
import sys,requests

#this script can be used to get list of all services wfor a specific host.
#run cmd : python ./consul-get-services-by-node.py ccrc-msrv-stg1-01 stg dc1

node=sys.argv[1]
env=sys.argv[2]
dc=sys.argv[3]
port='8080'
token = '2c9572d1-e49d-4d9c-834e-a2adece9fa7a'
print('-----')

if env not in ('dev', 'stg', 'lt', 'prod') or dc not in ('dc1' 'dc2') :
    print('Error in arguments.\n Order of args -- node env dc')
    print(' Allowed args --\n  dc : dc1 dc2\n  env : dev stg lt prod. dev - dc2, LT - dc1')
    sys.exit()

if env == 'dev' or (env == 'stg' and dc == 'dc2'):
    dc = 'stagedc2'
    host = 'http://ccrc-consul-stg-01'
elif (env == 'stg' and dc == 'dc1') or (env == 'lt' and dc == 'dc1'):
    dc = 'stagedc1'
    host = 'http://ccrc-consul-stg2-01'
elif env == 'prod' and dc == 'dc1':
    dc = 'proddc1'
    host = 'http://ccrc-consul-prd2-01'
elif env == 'prod' and dc == 'dc2':
    dc = 'proddc2'
    host = 'http://ccrc-consul-prd1-01'
elif (env == 'dev' and dc == 'dc1') or (env == 'lt' and dc == 'dc2'):
	print ('ERROR!! dev - dc2, lt - dc1')
	sys.exit()
else:
	print ('ERROR!! Incorrect args')
	sys.exit()

url = host+':8500/v1/internal/ui/node/'+node+'?dc='+dc+'&token=' + token;

print(node)
print(url)

data = requests.get(url).json()

for key,value in data.items():
	if key == 'Services':
		print(key)
		for service in value:
			if port in service['Service']:
				print(service['Service'])