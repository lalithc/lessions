path=$1
app=$2
namespace=$3
subtype=$6

oc replace --force -f $path/configmap.yaml -n $namespace
oc replace --force -f $path/$subtype.yaml -n $namespace