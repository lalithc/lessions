path=$1
app=$2
namespace=$3
dc=$4
subtype=$6

oc replace --force -f $path/configmap-$dc.yaml -n $namespace
oc replace --force -f $path/$subtype-$dc.yaml -n $namespace