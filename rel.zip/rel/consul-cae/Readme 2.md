## Consul ## 

Repository for deploying Consul clusters in CAE environment.

#### Usage
To create consul cluster:

```
1. Create a persistent volume claim
$oc create -f "consul-vol.yml" -n "<namespace>"
2. Create service for consul
$oc create -f "consul-service.yml" -n "<namespace>"
3. Create config map for consul
$oc create -f "consul-consig-map-<env-dc>.yml" -n "<namespace>"
4. Create stateful set (cluster) of consul 
$oc create -f "consul_<env>.yml" -n "<namespace>"
```

##### Note: Consul nonprod statefulset depends on volume and configmap for start-up of containers, before creating stateful, both should be present else pods will not come up. 

##### Defaults
- **Persistent Volume**&nbsp;&nbsp;: 5 GBs with read write access to all PODs (shared in Non-Prod) and 10 GBs per pod in PROD
- **Service**&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: Service exposing required consul ports for clustering
- **StatefulSet**&nbsp;&nbsp;&nbsp;		: No. of replicas 3 (cluster of 3 nodes)
- **Resources** &nbsp;&nbsp;        : Requests - 0.1 CPU and 1 Gi memory  & Limit - 0.5 CPU and 1.5 Gi Memory
- **Volume Mount**  : /consul/data
- **Config Map**  : /consul/config

##### Other details
- Official consul image, version 1.0.2 :
- Command line arguments from stateful yaml for clustering
- Config map has master acl token and encrypt with other settings