#!/bin/bash

# Start Schedulers
echo Starting Schedulers
python -u ./CiscoBotAPIs/CiscoBotAPIs/scheduler/Scheduler.py
echo 'Scheduler started Test'
