#!/bin/bash

# Start Gunicorn processes
echo Starting Gunicorn.
cd CiscoBotAPIs/
python -u ./CiscoBotAPIs/classifier/train.py &&
gunicorn CiscoBotAPIs.wsgi:application \
    --bind 0.0.0.0:8000 \
    --workers 7 \
    --worker-class gevent \
    --worker-connections 100 \
    --timeout 60 \
    --graceful-timeout 20 \
    --max-requests 10 \
    --access-logfile=-
echo 'gunicorn started'
cd $pwd