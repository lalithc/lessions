#!/bin/bash

path=$1
app=$2
namespace=$3
dc=$4
env=$7

branch="NonProd-${dc^^}"
if [[ $env == *"prd"* ]]; then
branch="Prod-${dc^^}"
fi

sed -e "s/NAMESPACE/$namespace/" -e "s/BRANCH/$branch/" $path/configmap.yaml > $path/configmap-$dc.yaml

oc create -f $path/configmap-$dc.yaml -n $namespace
oc create -f $path/$app.yaml -n $namespace