path=$1
app=$2
namespace=$3

oc create -f $path/configmap.yaml -n $namespace
oc create -f $path/$app.yaml -n $namespace