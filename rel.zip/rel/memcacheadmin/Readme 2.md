# MEMCACHED-ADMIN
# Build Image
docker build -t containers.cisco.com/ccw_renewal/memcahed-phpadmin:1.3 .

#  Push Image
docker push containers.cisco.com/ccw_renewal/memcahed-phpadmin:1.3

# Create MEMCACHED-ADMIN configmap
oc create configmap memcachedadmin-config --from-file=Memcache.php=Memcache.php

# Create MEMCACHED-ADMIN Objects
oc create -f memcacheadmin.yaml -n <name-space>

# Create MEMCACHED-ADMIN ROUTE'
From UI