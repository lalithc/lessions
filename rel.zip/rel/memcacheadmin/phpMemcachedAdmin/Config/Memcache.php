<?php
return array (
  'stats_api' => 'Server',
  'slabs_api' => 'Server',
  'items_api' => 'Server',
  'get_api' => 'Server',
  'set_api' => 'Server',
  'delete_api' => 'Server',
  'flush_all_api' => 'Server',
  'connection_timeout' => '1',
  'max_item_dump' => '100',
  'refresh_rate' => 2,
  'memory_alert' => '80',
  'hit_rate_alert' => '90',
  'eviction_alert' => '0',
  'file_path' => 'Temp/',
  'servers' => 
  array (
    'DEV_Cluster' => 
    array (
      'ccrc-memcache-101-dev:11211' => 
      array (
        'hostname' => 'ccrc-memcache-101-dev',
        'port' => '11211',
      ),
      'ccrc-memcache-102-dev:11211' => 
      array (
        'hostname' => 'ccrc-memcache-102-dev',
        'port' => '11211',
      ),
    ),
    'PROD_DC1_Cluster' => 
    array (
      'ccrc-mem-prd2-01:11211' => 
      array (
        'hostname' => 'ccrc-mem-prd2-01',
        'port' => '11211',
      ),
      'ccrc-mem-prd2-02:11211' => 
      array (
        'hostname' => 'ccrc-mem-prd2-02',
        'port' => '11211',
      ),
      'ccrc-mem-prd2-03:11211' => 
      array (
        'hostname' => 'ccrc-mem-prd2-03',
        'port' => '11211',
      ),
    ),
    'PROD_DC2_Cluster' => 
    array (
      'ccrc-memcache-prd1-01:11211' => 
      array (
        'hostname' => 'ccrc-mem-prd1-01',
        'port' => '11211',
      ),
      'ccrc-memcache-prd1-02:11211' => 
      array (
        'hostname' => 'ccrc-mem-prd1-02',
        'port' => '11211',
      ),
    ),
    'STAGE_DC1_Cluster' => 
    array (
      'ccrc-mem-stg-01:11211' => 
      array (
        'hostname' => 'ccrc-mem-stg-01',
        'port' => '11211',
      ),
      'ccrc-mem-stg-02:11211' => 
      array (
        'hostname' => 'ccrc-mem-stg-02',
        'port' => '11211',
      ),
    ),
    'STAGE_DC2_Cluster' => 
    array (
      'ccrc-mem-stg2-01:11211' => 
      array (
        'hostname' => 'ccrc-mem-stg2-01',
        'port' => '11211',
      ),
    ),
  ),
);