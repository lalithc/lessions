#!/bin/sh

(
#waiting for rabbit-mq to start
until rabbitmqctl node_health_check; do sleep 1; done;

#adding admin user
rabbitmqctl add_user ccrcrabbitadmin ccrccue123
rabbitmqctl set_permissions -p / ccrcrabbitadmin ".*" ".*" ".*"
rabbitmqctl set_user_tags ccrcrabbitadmin administrator

#addding regular user
rabbitmqctl add_user ccrcrabbituser ccrcrabbit
rabbitmqctl set_permissions -p / ccrcrabbituser "^$" "^$" ".*"
rabbitmqctl set_user_tags ccrcrabbituser monitoring

# deleting guest user
rabbitmqctl delete_user guest

#enabling plugins
rabbitmq-plugins enable rabbitmq_shovel_management
rabbitmq-plugins enable rabbitmq_shovel
rabbitmq-plugins enable rabbitmq_delayed_message_exchange

if [[ "$HOSTNAME" != "grabbitmq-0" && -z "$(rabbitmqctl cluster_status | grep grabbitmq-0)" ]]; then
    rabbitmqctl stop_app;
    rabbitmqctl join_cluster rabbit@grabbit-0.grabbit;
    rabbitmqctl start_app;
fi;

rabbitmqctl set_policy ha-all "^ccrc" '{"ha-mode":"all"}'
) &

exec rabbitmq-server