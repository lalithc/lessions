## RABBITMQ ## 

Repository for deploying RabbitMQ clusters in CAE environment.

### Contents
- blue &nbsp;&nbsp; : config. files for deploying blue rabbitmq replicas
- green &nbsp;: config. files for deploying green rabbitmq replicas

#### Usage
To create green replicas:

```
1. Create a persistent volume claim
$oc create -f "green\grabbit-vol.yml" -n "<namespace>"
2. Create service for green rabbit mq cluster
$oc create -f "green\grabbit-service.yml" -n "<namespace>"
3. Create stateful set (cluster) of green rabbitmq 
$oc create -f "green\grabbitmq.yml" -n "<namespace>"
```

##### Note: RabbitMQ statefulset depend on volumes for start-up of containers, before creating stateful, volume should be present else pods will not come up. 

##### Defaults
- **Persistent Volume**&nbsp;&nbsp;: 10 GBs with read write access to all PODs
- **Service**&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: Service exposing required rabbitmq ports for clustering & management
- **StatefulSet**&nbsp;&nbsp;&nbsp;		: No. of replicas 3 (cluster of 3 nodes)
- **Resources** &nbsp;&nbsp;        : 1 core and 1 GB memory  
- **Volume Mount**  : /var/lib/rabbitmq

##### Docker details
Different images for blue and green rabbitmq replicas. _config.sh_ script does post start-up actions :
- Installing and enabling out of the box plugins
- Creating admin and monitoring users
- Deleting default guest user
- Clustering nodes
- Setting HA policies for cluster
