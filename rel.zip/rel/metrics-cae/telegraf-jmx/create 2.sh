path=$1
app=$2
namespace=$3
subtype=$6

oc create -f $path/configmap.yaml -n $namespace
oc create -f $path/$subtype.yaml -n $namespace