# NGINX
# Build Image
docker build -t containers.cisco.com/ccw_renewal/ccrcnginx:1.3-20 .

#  Push Image
docker push containers.cisco.com/ccw_renewal/ccrcnginx:1.3-20

## RCDN
# Create NGINX configmap for 'ccrc-prepd' 
oc create configmap nginx-config --from-file=nginx.conf=nginx-preprd1.conf --from-file=mime.types=mime.types

# Create NGINX Objects for 'ccrc-prepd'
oc create -f nginx-preprd1.yml -n ccrc-prepd

# Create NGINX configmap for 'ccrc-prod'
oc create configmap nginx-config-blue --from-file=nginx.conf=nginx-prd1-blue.conf --from-file=mime.types=mime.types
oc create configmap nginx-config-green --from-file=nginx.conf=nginx-prd1-green.conf --from-file=mime.types=mime.types

# Create NGINX Objects for 'ccrc-prod'
oc create -f nginx-prd1-blue.yml -n ccrc-prod
oc create -f nginx-prd1-green.yml -n ccrc-prod


## ALLN
# Create NGINX configmap for 'ccrc-prepd' 
oc create configmap nginx-config --from-file=nginx.conf=nginx-preprd2.conf --from-file=mime.types=mime.types

# Create NGINX Objects for 'ccrc-prepd'
oc create -f nginx-preprd2.yml -n ccrc-prepd

# Create NGINX configmap for 'ccrc-prod'
oc create configmap nginx-config-blue --from-file=nginx.conf=nginx-prd2-blue.conf --from-file=mime.types=mime.types
oc create configmap nginx-config-green --from-file=nginx.conf=nginx-prd2-green.conf --from-file=mime.types=mime.types

# Create NGINX Objects for 'ccrc-prod'
oc create -f nginx-prd2-blue.yml -n ccrc-prod
oc create -f nginx-prd2-green.yml -n ccrc-prod

