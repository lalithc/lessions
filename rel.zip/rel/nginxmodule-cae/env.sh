#!/bin/bash

########START OF SCRIPT##################

lifecycle=`echo ${CISCO_LIFE}`

echo "Setting Cisco.life as $lifecycle"

echo "env ={ CISCO_LIFE: '$lifecycle' }"  > /apps/nginx/html/projectname/env.js

exec "$@"

###############END OF SCRIPT##################
