# CCRCAPI Haproxy

### Create services in new env
```
oc create -f service-green.yaml
oc create -f service-blue.yaml
oc create -f deploy-green.yaml
oc create -f deploy-blue.yaml
oc create -f route-green-stats.yaml
oc create -f route-blue-stats.yaml
oc rollout latest dc/bccrcapihaproxy
oc rollout latest dc/gccrcapihaproxy
```

### Build new version
```
docker build -t containers.cisco.com/ccw_renewal/bccrcapihaproxyrel:1.0-1 blue/.
docker build -t containers.cisco.com/ccw_renewal/gccrcapihaproxyrel:1.0-1 green/.
docker push containers.cisco.com/ccw_renewal/bccrcapihaproxyrel:1.0-1
docker push containers.cisco.com/ccw_renewal/gccrcapihaproxyrel:1.0-1
oc rollout latest dc/bccrcapihaproxy
oc rollout latest dc/gccrcapihaproxy
``

### Set route weight
```
oc set route-backends ccrcapi bccrcapihaproxy=100 gccrcapihaproxy=0
```
