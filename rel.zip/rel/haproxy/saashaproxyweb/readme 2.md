oc create configmap saashaproxyweb-blue --from-file=haproxy.cfg=saashaproxyweb-blue.cfg
    
oc create -f saashaproxyweb-blue.yml

oc create configmap saashaproxyweb-green --from-file=haproxy.cfg=saashaproxyweb-green.cfg

oc create -f saashaproxyweb-green.yml